<?php include 'include/header.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
<style>
    
#slide {
    display: inline-block;
    position: relative;

    margin-top:4px
 
}
#slide:after {
    content: '';
    display: block;
     margin-top: 4px;
    height: 2px;
    width: 0px;
    background: transparent;
    transition: width .7s ease, background-color .7s ease;
    
}
#slide:hover:after {
    width: 100%;
     background: -webkit-gradient(linear, 99% 0%, 0% 100%, from(#cc2a2e03), to(#cc2a2e));
} 







body{
    margin:0;
    padding:0;
}


#edit{
     /*background:linear-gradient(to right, #33ccff 6%, #ff99cc 100%);*/
     /*border-radius:9%;*/
     text-align:center;
     letter-spacing:2.5px;
     font-family:bold;
}

@media screen and (max-width: 1000px) {
  #edit{
 text-align:center;
    /*font-size:27px;*/
    font-family:serif;
    
  }
}


#ff{
    font-family:serif;
    text-align:center;
}

#pf{
    font-family:serif;letter-spacing:1px;
}


.slideanim {visibility:hidden;}


 .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    }
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    }
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }


</style>

</head>
<body>
   

    <a href="index.php" class="b-breadcrumbs__link"><b>Home</b></a>
    <span class="b-breadcrumbs__link"><b >Our Services</b></span>
    <span class=""><b>Conjoint</b></span>

  <div class="Container-fluid" >
				
					<img src="img/services-banner.jpg" >
				    
				</div>
         <div class="container slideanim">
            <br>             
            <h2 id="edit" class="page-title page-title margin-0"><hr>Conjoint<hr>
            </h2>
            <p id="pf">Experimental design principles are used to build different choice sets for testing in the survey. The number of conjoint choice sets and the configurations used are carefully controlled to ensure valid statistical estimation of the relative importance of each level of each attribute.
            </p>
<h2 style="color:#b1001e;font-family:bold;letter-spacing:1px;" id="slide">Conjoint Analysis</h2>
<p id="pf"> For any market research to be successful, it must be able to get useful results that communicate into effective strategies. Conjoint analysis is that statistical technique which lets you do exactly that. It provides practical outcomes for managers to understand and execute by determining the best combination of attributes that are the most influential in a respondents’ decision-making. </p>

<p id="pf">The sophisticated survey design of conjoint analysis aims for accuracy and better hypothesis in concrete descriptions, and results in better discrimination among attribute importances. It can also be modified in a conventional way to cover one aspect at a time. Another benefit is it’s capability to extend the idea of side-by-side comparisons. Consider for example two weights – one of 500 gms and another of 700. While you might not be able to tell which one is heavier if the weights are handed to you one by one, holding them side-by-side can do the trick. </p>

<p id="pf">We can design and run conjoint analysis campaigns for your business to get such to-the-point results for product development, competitive positioning or pricing research. You can also use it to measure consumer perception and commercial value of your brand. To know more about how you can uncover real or hidden influencers to which even your respondents might be unaware, contact us today.</p>

<h2 id="slide" style="color:#b1001e;font-family:bold;letter-spacing:1px;">Different types of conjoint that we undertake:</h2>
<ul>
<li>Discrete Choice Based Conjoint</li>
<li>Volumetric Choice Based Conjoint</li>
<li>Adaptive Choice Based Conjoint</li>
<li>Max diff Conjoint</li>
<li>Menu Based Conjoint</li>
<li>Segmentation Analysis</li></ul>

           <h3 id="slide" style="color:#b1001e;font-family:bold;letter-spacing:1px;">Our Conjoint designs are based upon:</h3>
           <p id="pf">Minimum Overlap- Each attribute level is shown as few times as possible in a single task. If an attribute’s number of levels is equal to the number of product concepts in a task, each level is shown exactly once.</p>
           <p id="#pf">Level Balance- Each level of an attribute is shown approximately an equal number of times.</p>
           <p id="pf">Orthogonality- Attribute levels are chosen independent of other attribute levels, so that each attribute level’s effect may be measured independently of all other effects.</p>
           <h3 id="slide" style="color:#b1001e;font-family:bold;letter-spacing:1px;">Randomized Conjoint Designs</h3>
           <p id="pf">Complete Enumeration: For this all possible concepts are considered and also concepts within each task are kept as different as possible.</p>
           <p id="pf">hortcut Method: The “shortcut” strategy makes a much simpler computation. It attempts to build each concept by choosing attribute levels used least frequently in previous concepts for that respondent. While complete enumeration keeps track of co-occurrences of all pairs of attribute levels, it considers all attributes one-at-a-time.</p>
           <p id="pf">Balanced Overlap Method: It permits roughly half as much overlap as the random method. This keeps track of the co-occurrences of all pairs of attribute levels with a relaxed standard relative to the complete enumeration strategy in order to permit level overlap within the same task.</p>
           <p id="pf">Random Method: This method employs random sampling with replacement for choosing concepts. Sampling with replacement permits level overlap within tasks. The random method permits an attribute to have an identical level across all concepts without permitting two identical concepts (on all attributes) to appear within the same task.  </p>
           
           <h3 id="slide" style="color:#b1001e;font-family:bold;letter-spacing:1px;">Conjoint Data & Simulators</h3>
           <p id="pf">We at Decisive Research can provide estimated conjoint utilities which are really useful for data analysis. Raw conjoint data files / counts report can also be shared for data interpretation.</p>
            <p id="pf">Conjoint Simulator is used to convert raw conjoint data into meaningful and insightful simulated market choices. A market segmentation simulator allows checking, what-if scenarios to investigate issues such as new products, design, pricing strategy, etc. The Market Segmentation Simulator is considered one of the most important tools resulting from a conjoint analysis project.</p>
         </div>
<div class="clearfix"></div>
<script>
$(document).ready(function(){
    $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>
<?php include 'include/footer.php'; ?>
</body>
</html>








