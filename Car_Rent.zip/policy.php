<?php include_once 'include/header.php'; ?>
<section class="inner-banner" style="margin-top: 65px;">
		<div class="container text-center">
			<h2><span>Privacy Policy</span></h2>
			
		</div>
</section>
<section class="faq-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="accrodion-grps" >
					<div class="text-center"> <h4>We recognize that the protection of personal information of our customers and all who are concerned with our company is our social responsibility. We are committed to carrying out the following policies in the protection of personal information.</h4></div><br>
					<div class="accrodion ">
						<ul>
							<li><p> We ensure that personal information of a customer at our office is well protected and not disclosed to other parties. We take all protection measure and appropriately manage them.</p></li>

							<li><p>In the case of requesting personal information, we will identify the purpose of use thereof and obtain such information only to the extent necessary for conducting business and through a lawful and reasonable manner and will use and/or provide such information only within the limits of the stated purposes.</p></li>

							<li><p>We will implement safety rules to manage risks concerning all the personal information handled in our company, such as being accessed in an unauthorized manner, being leaked, lost, or maliciously damaged or destroyed, and will take organizational, personnel, physical and technological measures to prevent risks and corrective measures if a problem occurs. </p></li>

							<li><p> In the case of outsourcing some of our operations to other companies handling personal information, we will request and supervise such contractors to handle the relevant personal information in the same proper manner as handled in our company.</p></li>

							<li><p>We will observe laws and ordinances on protection of personal information, governmental guidelines and other social norms, and will endeavour to continually improve the Management System through regular review. </p></li>

							<li><p> In the case where any customer requests our company to disclose and/or correct personal information that has been kept by our company and which belongs to such customer, we will respond appropriately in accordance with laws and ordinances on protection of personal information, and other social norms. We will respond in good faith to any and all complaints or consultation requests regarding personal information that has been kept by our company.</p></li>
						</ul>						
					</div>
				</div>
			</div>
		</div>		
	</div>
</section> <br><br>
<?php include_once 'include/footer.php'; ?>