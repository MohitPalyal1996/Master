<!DOCTYPE html>
<?php session_start(); ?>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php if(basename($_SERVER['SCRIPT_NAME']) == 'index.php'){echo 'Home'; }
elseif(basename($_SERVER['SCRIPT_NAME']) == 'testimonial.php'){echo 'Testimonial'; }
elseif(basename($_SERVER['SCRIPT_NAME']) == 'services.php'){echo 'Profile'; }
elseif(basename($_SERVER['SCRIPT_NAME']) == 'our_cars.php'){echo 'Our Cars'; }
elseif(basename($_SERVER['SCRIPT_NAME']) == 'our_coaches.php'){echo 'Our Coaches'; }
elseif(basename($_SERVER['SCRIPT_NAME']) == 'gallery.php'){echo 'Gallery'; }
elseif(basename($_SERVER['SCRIPT_NAME']) == 'faq.php'){echo 'FAQ'; } 
elseif(basename($_SERVER['SCRIPT_NAME']) == 'contact.php'){echo 'Contact Us'; } ?> </title>
<!-- mobile responsive meta -->
<meta name="viewport" content="width=device-width, initial-scale=1">


<!-- main stylesheet -->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min">
<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min">
<link rel="stylesheet" href="assets/hover">
<link rel="stylesheet" href="assets/animate.min">
<link rel="stylesheet" href="assets/revolution/css/settings">
<link rel="stylesheet" href="assets/owl.carousel-2/assets/owl.carousel">
<link rel="stylesheet" href="assets/owl.carousel-2/assets/owl.theme.default.min">
<link rel="stylesheet" href="assets/Stroke-Gap-Icons-Webfont/style">
<link rel="stylesheet" href="assets/jquery-ui-1.11.4/jquery-ui">
<link rel="stylesheet" href="assets/fancyapps-fancyBox/source/jquery.fancybox">



<script src='https://www.google.com/recaptcha/api.js'></script>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5XPFVFK');</script>
</head>
<body id="body">
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5XPFVFK"
height="0" width="0" style=""></iframe></noscript>
<header class="stricky">
<div class="container">
<div class="logo pull-left">
<a href="index.php" class="logotext">
Adrenture
</a>
</div>
<nav class="mainmenu-holder pull-right">
<div class="nav-header">
<ul class="navigation list-inline">
<li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'index.php'){echo 'active'; }else { echo ''; } ?>"><a href="index.php">Home</a></li>
<li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'services.php'){echo 'active'; }else { echo ''; } ?>"><a href="services.php">Profile</a></li>
<li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'our_cars.php'){echo 'active'; }else { echo ''; } ?>"><a href="our_cars.php">Our Cars</a></li>
<li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'our_coaches.php'){echo 'active'; }else { echo ''; } ?>"><a href="our_coaches.php">Our Coaches</a></li>
<li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'booknow.php'){echo 'active'; }else { echo ''; } ?>"><a href="booknow.php">Book Now</a></li>
<li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'contact.php'){echo 'active'; }else { echo ''; } ?>"><a href="contact.php">Contact Us</a></li>

</ul>
</div>
<div class="nav-footer">
<ul class="list-inline">
<li class="menu-expander hidden-lg hidden-md"><a href="#"><i class="icon icon-List"></i></a></li>
</ul>
</div>
</nav>
</div>
</header>