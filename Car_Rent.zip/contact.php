<?php include_once 'include/header.php'; ?>
<section class="inner-banner" style="margin-top: 65px;">
		<div class="container text-center">
			<h2><span>Contact Us</span></h2>
		</div>
	</section>


	
	<section class="latest-news contact-page section-padding contact-page-two blog-2-col blog-3-col blog-page">
		<div class="container">
			<div class="row">
				<!-- <div class="col-md-3 pull-right">
					<div class="sidebar-widget-wrapper">
						<div class="single-sidebar-widget contact-widget">
							<div class="title">
								<h3><span>Contact Infos</span></h3>
							</div>
							<ul class="contact-infos">
								<li>
									<div class="icon-box">
										<i class="fa fa-map-marker"></i>
									</div>
									<div class="info-text">
										<p>Shop No : 29, Palika Place Annexe ,
Punchkuian Road, New Delhi 110001 (India)</p>
									</div>
								</li>
								<li>
									<div class="icon-box">
										<i class="fa fa-phone"></i>
									</div>
									<div class="info-text">
										<p>Office nos :91-11- 45109999,27357438</p>
									</div>
								</li>
								<li>
									<div class="icon-box">
										<i class="fa fa-phone"></i>
									</div>
									<div class="info-text">
										<p>24 hours Mobile : +91-9910007940 & 9810007940</p>
									</div>
								</li>
								<li>
									<div class="icon-box">
										<i class="fa fa-envelope"></i>
									</div>
									<div class="info-text">
										<p>japmeetholidays@gmail.com, sikhtours@gmail.com</p>
									</div>
								</li>
							</ul>
						</div>
						<div class="single-sidebar-widget latest-post-widget">
							
						</div>
					</div>
				</div> -->
				<div class="col-md-12 pull-left">
					<div class="container-fluid">
            <div class="row">
            <div class="col-lg-12" id="form-content">

            <form class="contact-form js-contact-form" method="POST" id="book"> 
            <fieldset>

            <div class="form-group col-md-4">
            <label >Name <sup>*</sup></label>
            <input type="text" class="form-control" id="name" name="name" required="" placeholder="Enter the Name">
            </div>
            <div class="form-group col-md-4">
            <label >Email-ID <sup>*</sup></label>
            <input type="email" class="form-control" id="email" name="email" required="" placeholder="Enter the Email">
            </div>
            <div class="form-group col-md-4">
            <label >Mobile <sup>*</sup></label>
            <input type="tel" class="form-control" id="mob" name="mob" required="" placeholder="Enter the Mobile No." pattern="[789][0-9]{9}" required="">
            </div>

             <div class="form-group col-md-4">
            <label >Mobile <sup>*</sup></label>
            <input type="tel" class="form-control" id="mob" name="mob" required="" placeholder="Enter the Mobile No." pattern="[789][0-9]{9}" required="">
            </div>

            <div class="form-group col-md-4">
            <label>Other Requirement : </label>
            <textarea class="form-control" rows="4" id="comment" name="comment" placeholder="Additional Information" style="height: 71px;"></textarea>
            </div>



            <div class="form-group col-md-4" style="line-height: 105px;"> 

            <button type="submit" name="submit" id="submit" class="btn btn-warning btn-lg" >Submit</button>
            </div>
            </fieldset>
            </form>
				</div>
			</div>
		</div>
	</section>



	<section class="full-width-google-map">
	<iframe style="width:100%; height:380px; border:none" src="//www.google.com/maps/embed/v1/place?q=Japmeet Holidays,
	&zoom=17
	&key=AIzaSyDW9N4qIukHL_RvEYiXTpdkO40KwZBX7nE">
</iframe>
	</section>

<?php include_once 'include/footer.php'; ?>