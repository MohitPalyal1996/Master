<?php include 'include/header.php'; ?>

<style>

    
.container li {
    display: inline-block;
    position: relative;
  
    margin-top:4px
 
}
.container li:after {
    content: '';
    display: block;
     margin-top: 4px;
    height: 2px;
    width: 0px;
    background: transparent;
    transition: width .7s ease, background-color .7s ease;
    
}
.container li:hover:after {
    width: 100%;
     background: -webkit-gradient(linear, 99% 0%, 0% 100%, from(blue), to(black));
} 

#edit{
     background:linear-gradient(to right, #33ccff 6%, #ff99cc 100%);
     border-radius:9%;
     text-align:center;
     letter-spacing:2.5px;
     font-family:bold;
}

#edit1{
     
     text-align:center;
     letter-spacing:2.5px;
     font-family:bold;
}

@media screen and (max-width: 1000px) {
  #edit1{
    
    font-family:serif;
    
  }
}

#pedit{
    letter-spacing:1px;
    font-family:serif;
  
    
    
}

#liedit{
    font-family:bold;
    font-size:26px;
    color:#b1001e;
}

.slideanim {visibility:hidden;}


 .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    }
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    }
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }


</style>  
 <a href="index.php" class="b-breadcrumbs__link"><b>Home</b></a>
<span class="b-breadcrumbs__link"><b >Our Services</b></span>
<span class=""><b>Programming</b></span>
        <div class="Container-fluid" >
				
				<img src="img/code-banner.jpg" alt="dfw" >
				    
				</div>
         <div class="container slideanim">	
            <br>             
            <h2 id="edit1"class="page-title margin-0"><hr>PROGRAMMING<hr>
            </h2>
            <br> 
            <p id="pedit">We are a team of energetic members, experts in Programming complex and customized surveys. Before going into field each survey goes through a rigorous quality process to ensure data accuracy
            </p>
          <li id="edit" style="font-famiy:bold"> Offline CAPI (Computer Aided Personal Interview)</li>
            
           
    <p id="pedit" class=" slideanim">An offline survey mode to get respondents answer your questionnaire, Computer Assisted Personal Interviewing or CAPI gives the advantage of reaching out to vast audience. With the help of CAPI data collection is done using a Laptop or Tab when it’s not connected to the internet. It is as good as an online survey with respect to functionalities. Data gets stored in Interviewer machine and can be easily transferred to central repository in the form of light weight csv file.We use a series of cleverly designed questions to carry out face-to-face research and give you electronic data in real-time. Our method of doing CAPI on Sawtooth not only reduces the potential manual errors, but also saves huge time, effort and thus money to collect, analyze and use any form of data. Some of the CAPI surveys that we have conducted include opinion surveys, feedback surveys, needs analysis, household Interviews, mall intercepts, etc. 
            </p>
            <hr>
<li id="liedit"> <strong>Online Survey Programming: </strong></li>

<p id="pedit" class=" slideanim">Using our highly capable and experienced programming team, we hold the capability to create and run complex online surveys. We can design the surveys, do the survey programming and run web and mobile surveys as and when required. The two platforms used for it include Sawtooth and Dechiper</p>
<hr>
<li id="liedit"><strong>Sawtooth:</strong></li>
<p id="pedit" class=" slideanim"> For decades, companies have relied on age-old techniques of collecting uncomplicated, effortless data to run their market research campaigns. However, today’s consumers have multiple choices, which has pushed companies to expand their data collection ways. For example, if there are individuals who like to drink milk, a few among them might prefer it to be flavored. A multiple interaction tool can accommodate several modules and scale up the consumer response to get the desired results. </p>

<p id="pedit" class=" slideanim">Sawtooth is a powerful platform that measures qualitative importance and allows you to gain a deeper understanding of your target audience’s likes and dislikes. It works on the principle of layered responses.
As your consultants, we help you to plan, design, gather and scrutinize data to reduce your problem area and reach to a logical conclusion.. Whether you seek to add new features to your product or want to launch a new version in the market, our research allows you to take the decision by judging the data and relevant numbers. With us, nothing is left to chance.</p>
<hr>
<li  id="liedit"><strong>Decipher:</strong> </li>
<p id="pedit" class=" slideanim">Decipher is a survey platform that allows gathering of multiple opinions and their analysis to study market’s reactions to a brand, reduce a product’s failures or inefficiencies or explore new opportunities. </p>

<p id="pedit" class=" slideanim">Using Decipher, we create online surveys and reach your target audience through emails, embedded websites pop-ups or social media surveys. We also help you to analyze results using real-time dashboards, trend analysis, segmentation tools and text analytics.</p>

<p id="pedit" class=" slideanim"> As experts in market research, we can help you to understand the expectations of your customers, measure your product’s performance, do a communications and advertising research, perform customer satisfaction surveys, run employee and staff surveys, brainstorm on start-ups or new business ideas and administer international market entry researches. </p>

<p id="pedit">Please contact us for further information on how we can help you to conduct your next survey or research.</p>

<hr>
           <h2 style="text-align:center">Sawtooth Hosting & Survey Distribution Management</h2>
            <p id="pedit">Our team is trained to make required modifications like templates, incorporation of images, import of conjoint design, uploading passwords, redirects etc in the programming file before hosting and also make changes to your existing Sawtooth files too.</p>
            <p id="pedit">We can even connect Sawtooth file with any other platform like, Confirmit, Dimension etc.</p>
           
         </div>
  <script>
$(document).ready(function(){
    $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>
      <?php include 'include/footer.php'; ?>
