<?php include 'include/header.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
<style>
    
.container h3 {
    display: inline-block;
    position: relative;
    /*margin-left: 10px;*/
    margin-top:4px
 
}
.container h3:after {
    content: '';
    display: block;
     margin-top: 4px;
    height: 2px;
    width: 0px;
    background: transparent;
    transition: width .7s ease, background-color .7s ease;
    
}
.container h3:hover:after {
    width: 100%;
     background: -webkit-gradient(linear, 99% 0%, 0% 100%, from(#cc2a2e03), to(#cc2a2e));
} 


#med{
    
    word-spacing:5px;
     text-transform: uppercase; 
     letter-spacing:3px;
     font-family:bold;
     text-align:center;
     
}



@media screen and (max-width: 1000px) {
  #med{
        word-spacing:2px;
    margin-left: 0px;
     letter-spacing:1px;
    font-family:serif;
    
  }
}


body{
    margin:0;
    padding:0;
}


#ff{
    font-family:serif;
    /*text-align:center;*/
}


 #pan{text-align: center;}
      .top-images{    background: #e4d7af;
    padding: 25px 8px 0;
    position: relative;}
    .top-images img{    width: 60% !important;
    display: block;
    margin: auto;
    padding-bottom: 48px;}
    .top-images h4{    background: #baa157;
    color: white;
    padding: 10px;
    position: absolute;
    bottom: -8px;
    left: 0;
    text-align: center;
    width: 100%;}

#mgtp{
    margin-top:-15px;
}

.slideanim {visibility:hidden;}


 .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    }
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    }
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }


</style>

</head>
<body>
   

    <a href="index.php" class="b-breadcrumbs__link"><b>Home</b></a>
    <span class="b-breadcrumbs__link"><b >Our Services</b></span>
    <span class=""><b>Data Collection</b></span>

<div class="Container-fluid" >
				
					<img src="img/data_analytics.jpg" style="width:100%;" >
				    
				</div>
	
</div>			
				 <div class="container slideanim">
                   
          <hr>  <h2 id="med"  class=" title-heding ">Data Collection</h2><hr>
           <h3 style="color:#b1001e;word-spacing:2px;">Access to Anyone, Anywhere and Anytime</h3>
          <div class="container" id="pan">
           
            <div class="col-md-3">	
              <div class="top-images">
              	<img src="img/consure_icon.png" alt="" style="width:100%;">
              	<h4>Consumer</h4>
              </div>
<p>We at Decisive Research have Consumer Panel which gives you access to deeply profiled consumers for your market research.Our Panel has vast segmented attributes from socio-demographic, life stage, interests, hobbies, shopping habits, purchase intent etc. We can scale up to address your needs.</p>
                          </div>
            
            <div class="col-md-3">	
              <div class="top-images">
              	<img src="img/b2b_icon.png" alt="" style="width:100%">
              	<h4>B2B</h4>
              </div>
              <p>We along with our select sample partners have access to Fast Growing , Global and difficult to reach business professionals.Our panel is segmented on the basis of Industry group, income level, designation ,Company Size and influence on marketing or technology purchases</p>
            </div>
            
            <div class="col-md-3">	
              <div class="top-images">
              	<img src="img/healthcare_icon.png" alt="" style="width:100%">
              	<h4>Healthcare</h4>
              </div>
              <p>Our access to healthcare industry can identify Gender, Medical School , Graduation, place of residency or fellowship, languages, board certification, eligibility, geography etc. with provide reach ~1-2% or any given market with a week, 3-7% within 14 days, and 8–15% within 21 days.</p>
            </div>
            
            <div class="col-md-3">	
              <div class="top-images">
              	<img src="img/hosted_icon.png" alt="" style="width:100%">
              	<h4>Hosted panel</h4>
              </div>
              <p>Growing our panel network continuously with our crowd sourced hosted panel allows you even deeper assess. Our hosted panel leverages are cloud based platform for quick access and incentives for members.</p>
            </div>
            
            
            </div>
<hr>
            <h3>Online & Offline Data Collection</h3>
           <p  id="mgtp">We have cultivated strong expertise in managing online and offline data collection and research partners, and along with strong personnel administration, can provide quality research findings.</p>
           <p  id="mgtp">We at Decisive Research facilitates targeting a large chunk of online panelists through our strategic partners. We are capable of helping you with consumers, professionals and also healthcare specialists.</p>
           <h3>Online</h3>
           <ul class="list-dot" id="mgtp">
              <li>Mobile</li>
              <li>Tablet</li>
              <li>Laptop/Desktop</li>
           </ul>
           
            <h3>Telephonic</h3>
           <ul class="list-dot"  id="mgtp">
              <li>CATI -Computer Aided Telephonic Interviews</li>
           </ul>
           
            <h3>Offline</h3>
           <ul class="list-dot"  id="mgtp">
              <li>Paper & Pencil Interview (PAPI)</li>
              <li>Computer Aided Personal Interview (CAPI) through Tablet or Laptop</li>
              <li>Focus Group Discussions</li>
              <li>In- Depth Interviews</li>
            </ul>
           
            <h3>CLT</h3>
           <ul class="list-dot"  id="mgtp">
              <li>Central Location Test</li>
            </ul>
             
            <h3>IHUT</h3>
           <ul class="list-dot" id="mgtp">
              <li>In-Home User Test</li>
            </ul>
            </div>
          
          
</div>			
				
				<div class="clearfix"></div>

<?php include 'include/footer.php'; ?>
</body>
</html>