<!doctype html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


<!--<link rel='dns-prefetch' href='//fonts.googleapis.com' />-->
<!--<link rel='dns-prefetch' href='//s.w.org' />-->


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/fontawesome-all.css" media="all">
<link rel='stylesheet' id='layerslider-css'  href='css/layerslider.css' type='text/css' media='all' />
<link rel='stylesheet' id='ls-user-css'  href='css/layerslider.custom.css' type='text/css' media='all' />
<link rel='stylesheet' id='interactive_map_builder-meisterbox-styles-css'  href='css/meisterbox.css?ver=2.0' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='css/styles.css' type='text/css' media='all' />
<link rel='stylesheet' id='lawyer-css-css'  href='css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='lawyer-fonts-css'  href='//fonts.googleapis.com/css?family=Gudea%3A400%2C400i%2C700%7CPT+Serif%3A400%2C400i%2C700%2C700i%7CCabin%3A600%7CSlabo+27px%7CGudea%7CCabin&#038;subset=cyrillic%2Ccyrillic-ext%2Clatin%2Clatin-ext&#038;ver=4.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='fonts-awesome-css'  href='css/font-awesome.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='fontello-css'  href='css/fontello.css' type='text/css' media='all' />
<link rel='stylesheet' id='foundation-css'  href='css/foundation.css' type='text/css' media='all' />
<link rel='stylesheet' id='swiper-css'  href='css/swiper.min.css' type='text/css' media='all' />

<link rel='stylesheet' id='responive-margins-css'  href='css/responive-margins.css' type='text/css' media='all' />
<!-- *************************************************************************************************** -->
<link rel='stylesheet' id='lawyer-styles-css'  href='css/customize.css' type='text/css' media='all' />
<!-- **************************************************************************************************** -->

<link rel='stylesheet' id='js_composer_front-css'  href='css/js_composer.min.css' type='text/css' media='all' />

<script type='text/javascript' data-cfasync="false" src='js/greensock.js'></script>
<script type='text/javascript' src='js/jquery.js'></script>
<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
<script type='text/javascript' data-cfasync="false" src='js/layerslider.kreaturamedia.jquery.js'></script>
<script type='text/javascript' data-cfasync="false" src='js/layerslider.transitions.js'></script>

<body class="home page-template-default page page-id-6 wpb-js-composer js-comp-ver-5.3 vc_responsive" style="margin:0;padding:0;">
<!-- HEADER -->
<header class="main-header">
<!-- Site socials -->
<div class="row-fluid row-fluid--socials">
<div class="row align-right">
<div class="columns shrink">
<div class="socials socials--slide-hover">
<a href="https://www.linkedin.com/in/steepbrain-research-and-consultancy">
<i class="icon-hover icon-twitter"></i>
<i class="icon-twitter"></i>
</a>
<a href="#">
<i class="icon-hover icon-facebook"></i>
<i class="icon-facebook"></i>
</a>
<a href="#">
<i class="icon-hover icon-linkedin"></i>
<i class="icon-linkedin"></i>
</a>
<a href="#">
<i class="icon-hover icon-pinterest-4"></i>
<i class="icon-pinterest-4"></i>
</a>
<a href="#">
<i class="icon-hover icon-rss-1"></i>
<i class="icon-rss-1"></i>
</a>
<a href="#">
<i class="icon-hover icon-gplus-1"></i>
<i class="icon-gplus-1"></i>
</a>
</div>
</div>
</div>
</div>

<div class="row-fluid" id="js-menu-sticky-anchor">
<div class="row align-justify align-middle row-logo">
<div class="columns small-12 medium-6">
<!-- Logo section -->
<!--<div class="logo" style="overflow: hidden;">-->
<!--<a href="#" id="#boxtxt" >-->
<!-- <img src="img/logo.png" alt="Lawyer&amp;Co"> -->

<!--                <p id="txtp" >Welcome,We are Upgrading our Website </p>-->

<!--</a>-->
<!--</div>-->
<div class="logo" >
<a href="https://steepbrain.com/">
<img src="img/logoi.png" >
</a>
</div>
</div>
<div class="columns small-12 shrink">
 <div class="contact-phone "><i class="icon-phone-3"></i><span><span style="color:red;"> Consultation</span> <a href="tel:01207961544" style="color:black;"> : 01207961544</a> </span>| 
 <i style="color:green;"  class="fa fa-whatsapp" aria-hidden="true"></i><a style="color:black;" class="whatsapp-text-hvr" href="https://wa.me/9999164802"> 919999164802</a>
</div>
</div>
</div>
</div>
<div class="sticky-container">
<div class="row-fluid row-fluid--menu js-sticky">
<div class="row align-middle main-navigation">

<div class="columns small-order-2 large-order-1 menu-col">
<nav>
<ul class="menu main-menu" style="display:flex ;@media screen and (max-width: 1023px)
.main-menu
{
    display:flex;
}" >
    <li id="menu-item-12" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'index.php')? "menu-item menu-item-type-post_type menu-item-object-page menu-item-home 
    current-menu-item page_item page-item-6 current_page_item 
    current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor  menu-item-12" : "" ?>">
        <a class="active" href="index.php">Home</a>
    </li>
<li id="menu-item-137" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'about.php')? "menu-item menu-item-type-post_type menu-item-object-page menu-item-home 
current-menu-item page_item page-item-6 current_page_item current-menu-ancestor 
current-menu-parent current_page_parent current_page_ancestor  menu-item-12" : "" ?>">
<a href="about.php">About</a></li>

<!-- <li id="menu-item-138" class="
">
<a href="people.php">Our Team</a></li>
 -->

<!-- <li id="menu-item-72" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-72"><a href="news.php">News</a>
 --><!-- <ul class="sub-menu">
<li id="menu-item-624" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-624">
<a href="#">Publications</a></li>
</ul>
 -->


<li id="menu-item-403" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'ourwork.php')? "menu-item menu-item-type-post_type menu-item-object-page menu-item-home
current-menu-item page_item page-item-6 current_page_item current-menu-ancestor 
current-menu-parent current_page_parent current_page_ancestor  menu-item-12" : "" ?>">
<a href="ourservices.php">Our Services</a>





</li>
<!--<li id="menu-item-142"  class="<?php echo (basename($_SERVER['PHP_SELF']) == '#.php')? "menu-item menu-item-type-post_type menu-item-object-page menu-item-home-->
<!--current-menu-item page_item page-item-6 current_page_item current-menu-ancestor -->
<!--current-menu-parent current_page_parent current_page_ancestor  menu-item-12" : "" ?>">-->
<!--                        <a href="#" class="active">Our Team<b ></b></a>                      -->
<!--</li>-->
                       
                           

<!-- <li id="menu-item-141" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-141 mega-menu-wrapper"><a href="location.php">Locations</a>
</li>   
 -->
<li id="menu-item-142" class="<?php echo (basename($_SERVER['PHP_SELF']) == '#.php')? "menu-item menu-item-type-post_type menu-item-object-page menu-item-home
current-menu-item page_item page-item-6 current_page_item current-menu-ancestor 
current-menu-parent current_page_parent current_page_ancestor  menu-item-12" : "" ?>">
    <a href="contact.php">Contact Us</a></li>
</ul>
</nav>
</div>
</div>
</div>
</div>
</header>

<script>
// Dropdown Menu Fade    
jQuery(document).ready(function(){
    $(".dropdown").hover(
        function() { $('.dropdown-menu', this).fadeIn("fast");
        },
        function() { $('.dropdown-menu', this).fadeOut("fast");
    });
});

</script>





