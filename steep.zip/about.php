<?php include 'include/header.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
	#hredit{
		border-width: 1.4px;
		border-color: black;
	}
	#hredit2{
		border-width:1.7px;
		 background-image: linear-gradient(to right, rgba(110,10,110,0.9), rgba(1,0,110,0));
	}

#hredi{



}
#h2edit{
	margin-left: 180px;
	color: white;
}

@media screen and (max-width: 620px) {
  #h2edit{
    margin-left: 10px;
  }
}


#sliding-middle-out {
    display: inline-block;
    position: relative;
 
}
#sliding-middle-out:after {
    content: '';
    display: block;
     margin-top: 4px;
    height: 2px;
    width: 0px;
    background: transparent;
    transition: width .7s ease, background-color .7s ease;
    
}
#sliding-middle-out:hover:after {
    width: 100%;
     background: -webkit-gradient(linear, 99% 0%, 0% 100%, from(#cc2a2e03), to(#cc2a2e));
} 



.slideanim {visibility:hidden;}


 .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    }
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    }
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }

body{
    margin :0;
    padding :0;
}



</style>

	
	
</head>
<body>
  <div class="Container-fluid" >
				
					<img src="img/about_us.jpg" >
				    
				</div>






<div class="vc_row-full-width vc_clearfix"></div>


<!--<div class="vc_row wpb_row vc_row-fluid ">-->
<!--</div>-->



<div class="container" style="padding-top: 20px; text-align: center;">
    
<h2 class="post__title">
<a href="#" id="sliding-middle-out"><b>OUR PROFILE</b></a>
<hr id="hredit2">
</h2>
<div class="post__excerpt slideanim" style="text-align: justify;">
<p><a href="index.php"><img style="margin-left: -8px;" src="img/logoi.png"></a>is a Market Research firm that offers actionable business insights to its clients. Our core competency lies in successfully understanding how individuals behave when choosing a product and what influences their decisions. Our work not only delivers valuable research, but also demonstrates how the results can be turned into strategies to bring tangible profit to your organization..</p>
<hr style="width: 60%">
<h2 class="title-heding" id="sliding-middle-out">Vision</h4>
<p>To become a long-term single point research partner for companies and brands, working with to study their communication, perception and pricing.</p>
<hr style="width: 60%">
<h2 class="title-heding" id="sliding-middle-out">Mission</h4>
<p>At <b>STEEPBRAIN</b>, our mission and values are to help businesses, stakeholders and individuals plan their end-to-end market research with us The company is run by visionary individuals whose collective experience in Market Research makes it a promising startup companies in the research domain.</p>
<hr style="width: 60%">
Your Partners
<div class="vc_row-full-width vc_clearfix"></div>
<hr id="hredit2">

</div>
</div>

<script>
$(document).ready(function(){
    $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>



<?php include 'include/footer.php'; ?>

</body>
</html>