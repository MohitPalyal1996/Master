<?php include 'include/header.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
<style>
    
.container h2 {
    display: inline-block;
    position: relative;
  
    margin-top:4px
 
}
.container h2:after {
    content: '';
    display: block;
     margin-top: 4px;
    height: 2px;
    width: 0px;
    background: transparent;
    transition: width .7s ease, background-color .7s ease;
    
}
.container h2:hover:after {
    width: 100%;
     background: -webkit-gradient(linear, 99% 0%, 0% 100%, from(#cc2a2e03), to(#cc2a2e));
} 


#med{
    margin-left:170px;
    letter-spacing:1px;
    word-spacing:1px;
     text-transform: uppercase; 
     
}



@media screen and (max-width: 1000px) {
  #med{
    margin-left: 0px;
    font-size:27px;
  }
}


body{
    margin:0;
    padding:0;
}


#ff{
    font-family:serif;
   
}

.slideanim {visibility:hidden;}


 .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    }
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    }
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }




</style>

</head>
<body>
   

    <a href="index.php" class="b-breadcrumbs__link"><b>Home</b></a>
    <span class="b-breadcrumbs__link"><b >Our Services</b></span>
    <span class=""><b>Q&QResearch</b></span>

<div class="Container-fluid" >
				
					<img src="img/services1.png" >
				    
				</div>
				<div class="row">

</div>
		 <div class="container slideanim"> <br> 
<hr><h2 id="med" class="page-title" style="color:black;">Research that gets to the heart of your query</h2><hr><br>
<h1 style=" background: linear-gradient(to right, #33ccff 6%, #ff99cc 100%);border-radius:9%;" 
class="page-title margin-0 " >
    Qualitative & Quantitative Research</h1>
<br> 
<h2 ><strong style="color:#b1001e">Qualitative Research</strong></h2>             
<p id="ff" class=" slideanim">Qualitative Research provides an understanding of how and why customers take the decisions they make. There is
usually no set of fix questions, but rather a topic around which a discussion revolves. We find out not just what your
target audience thinks about your product/service/idea but why they think like that.</p> <p id="ff">Our research focuses on
getting them to talk and convey their opinions so we can capture their motivations and feelings, and is useful,
especially in cases where new a product or service needs to be tested in the market to generate user feedback. Instead
of analyzing numerical data, we draw our strength from in-depth interviews, focus groups, ethnography, mystery shopping,
user- interface testing, and consumer diaries to understand language and behavior of the consumer and give a greater
flexibility to our clients.</p><br>
<hr>
<h2><strong style="color:#b1001e">Quantitative Research</strong></h2> <!--<h3>Turn the future in your favor</h3>-->
<p id="ff" class=" slideanim">Clients use our quantitative research service to generate large qualities of data measuring customer
satisfaction, brand positioning, and corporate reputation. It is a number based research that is straight forward and
gives conclusive results. The large number of respondents provide a favorable setting for measuring the effectiveness of
the product or service while determining the market size. Quantitative research also establishes customer profiles and
provides appropriate statistical recommendations.</p> <p id="ff">We create a detailed framework and integrate statistical data
representation at every level to test hypotheses in experiments. It is done by employing automated means of gathering
data such as surveys, face-to-face interviews and examining preferences through two/three-alternative, forced-choice
studies, or investigating error rates on task using competitive standards. We cover communication/message effectiveness;
brand/market positioning, pre/post ad testing, concept test, customer/employee satisfaction survey, and segmentation
study within the scope of our quantitative research service.</p> 
</div> 
<div class="clearfix"></div>
<script>
$(document).ready(function(){
    $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>


<?php include 'include/footer.php'; ?>
</body>
</html>








