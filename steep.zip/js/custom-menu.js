;(function ($, window, document, undefined) {
	"use strict";

	function lawyerChildTitles( action, selector ) {
		$('#menu-to-edit > li.menu-item').each(function(){
			var $this = $(this),
				$parentId = $this.attr('data-parent-id');
			if ( selector == $parentId ) {
				if ( action == 'add' ) {
					$(this).addClass('sub-mega-item-wrapper');
				}
				if ( action == 'remove' ) {
					$(this).removeClass('sub-mega-item-wrapper');
				}
			}
		});
	}

	$('li.menu-item.menu-item-depth-0 .mega-menu').on('click', function() {
		var parent = $(this).closest('li.menu-item.menu-item-depth-0'),
			selector = parent.attr('data-id');

		if ( parent.hasClass('mega-menu-style') ) {
			parent.removeClass( 'mega-menu-style' );
			lawyerChildTitles( 'remove', selector ); 
		} else {
			lawyerChildTitles( 'add', selector ); 
			parent.addClass( 'mega-menu-style' );
		}
	});

	var menuItems = $('#menu-to-edit li');
	function lawyerShowOptions() {
		var add = false,
			remove = false,
			checked = false;

		menuItems.each( function(){
			var $li = $(this),
				checkbox = $li.find('.mega-menu');

			if( $li.hasClass('menu-item-depth-0') ) {
				if ( checkbox.is(':checked') ) {
					add = true;
					remove = false;
				} else {
					remove = true;
					add = false;
				}
			}

			if( $li.hasClass('menu-item-depth-1') && add ) {
				$li.addClass('sub-mega-item-wrapper');
			}
			if( $li.hasClass('menu-item-depth-1') && remove ) {
				$li.removeClass('sub-mega-item-wrapper');
			}
		});

	}

	menuItems.on('click', '.mega-menu', function(){
		lawyerShowOptions();
	});

	jQuery(document).ready(function() {
		if(typeof wpNavMenu != 'undefined'){
			var lawyerMenu = wpNavMenu;
		    if ( lawyerMenu.menuList ) {
		    	lawyerMenu.menuList.on( "sortstop", function( event, ui ) {
		    		setTimeout(function(){
		    			lawyerShowOptions();
		    		});
		    	});
		    }
	    }
	})

})(jQuery, window, document);