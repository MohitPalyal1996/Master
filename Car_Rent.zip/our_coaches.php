<?php include_once 'include/header.php'; ?>

<section class="inner-banner" style="margin-top: 65px;">
<div class="container text-center">
<h2><span>OUR COACHES </span></h2>
</div>
</section>



<section class="vehicle-sorter-area section-padding" >
<div class="container">

<div class="vehicle-sorter-wrapper mix-it-gallery">
<ul class="gallery-filter list-inline">
<li class="filter" data-filter="all"><span>ALL</span></li>
<li class="filter" data-filter=".excoaches"><span>Executive Coaches</span></li>
<li class="filter" data-filter=".lxcoaches"><span>Luxury Coaches</span></li>
<li class="filter" data-filter=".tmpcoaches"><span>tempo Traveller</span></li>


</ul>
<div class="row ">
<br>
<br>
<div class="col-md-6 col-sm-6 mix lxcoaches">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="#"><img src="img/7.png" alt=""></a>
</div>
<a href="#"><h3>Mercedes Coach</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 44+ Driver</li>
<li><span>Fuel:</span> Diesel</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Doors:</span> 2</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Mercedes Coach" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a></div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix excoaches">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="#"><img src="img/volvo.png" alt=""></a>
</div>
<a href="#"><h3>38 Volvo with Washroom</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 38+ Driver</li>
<li><span>Fuel:</span> Diesel</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Doors:</span> 2</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=38 Volvo with Washroom" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix excoaches">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="#"><img src="img/volvo (2).jpg" alt=""></a>
</div>
<a href="#"><h3>44 Volvo </h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 44+ Driver</li>
<li><span>Fuel:</span> Diesel</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Doors:</span> 2</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=44 Volvo " class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix excoaches">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="#"><img src="img/rosa.png" alt=""></a>
</div>
<a href="#"><h3>Mitsubishi Rosa</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 18/21 Seater</li>
<li><span>Fuel:</span> Diesel</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Doors:</span> 2</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Mitsubishi Rosa" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix excoaches">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="#"><img src="img/commuter.png" alt=""></a>
</div>
<a href="#"><h3>Toyota Commuter</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span>8+ Driver</li>
<li><span>Fuel:</span> Diesel</li>

</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Air Conditioning:</span> Yes</li>
<li><span>Music Player:</span> Yes</li>

</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Toyota Commuter" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix excoaches">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="#"><img src="img/5.png" alt=""></a>
</div>
<a href="#"><h3>Toyota Coaster</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 13/17 Seater</li>
<li><span>Fuel:</span> Diesel</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>

</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Toyota Coaster" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix excoaches">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="#"><img src="img/6.png" alt=""></a>
</div>
<a href="#"><h3>Flat Ducato</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 12+ Driver</li>
<li><span>Fuel:</span> Diesel</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>

</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Flat Ducato" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix excoaches">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="#"><img src="img/Volkswagen-Crafter-panel-van-5.png" alt=""></a>
</div>
<a href="#"><h3>Volkswagen Crafter</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 12/15 Seater</li>
<li><span>Fuel:</span> Diesel</li>

</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Air Conditioning:</span> Yes</li>
<li><span>Music Player:</span> Yes</li>

</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Volkswagen Crafter" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix tmpcoaches">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="#"><img src="img/tempo-traveller-hire-in-pune-500x500.png" alt=""></a>
</div>
<a href="#"><h3>Tempo Traveller 27 Seater</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 27+ Driver</li>
<li><span> Pushback Seates:</span> Yes</li>

</ul>
</div>
<div class="middle-box">
<ul>

<li><span>Air Conditioning:</span> Yes</li>

</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Tempo Traveller 27 Seater" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>

<div class="col-md-6 col-sm-6 mix tmpcoaches">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="#"><img src="img/Tempo-Traveller-17-Seater.png" alt=""></a>
</div>
<a href="#"><h3>Tempo Traveller 18 Seater</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 18+ Driver</li>
<li><span> Pushback Seates:</span> Yes</li>

</ul>
</div>
<div class="middle-box">
<ul>

<li><span>Air Conditioning:</span> Yes</li>

</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Tempo Traveller 18 Seater" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>















</div>

</div>
</div>
</section>	




<?php include_once 'include/footer.php'; ?>