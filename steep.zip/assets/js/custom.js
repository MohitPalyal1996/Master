/*  //SEND ENQUIRY   */
var _url = window.location.origin+'/';

$(document).ready(function(){
	$("#enquiryform").submit(function(event){
		event.preventDefault();
    $.ajax({
				type: "POST",
				url: base_url+"Lawyer/enquiry_form",
				data: {
						lawyer_id: $("#lawyer_id").val(),
						help_name: $("#help_name").val(),
						help_phone: $("#help_phone").val(),
						help_email: $("#help_email").val(),
						help_city: $("#help_city").val(),
						legal_issues: $("#legal_issues").val()
        }, 
        success:function(data){
				    if(data == 'loggedIn'){
							var error = '<div class="messageadv"><h2>Successfully Sent<h2> </div>';
							$('.messageadv').html(error);
							$('html, body').animate({scrollTop:$('.messageadv').offset().top}, 'slow');
						}else if(data == 'No'){
							var error = '<div class="messageadv"><h2>Sorry you have entered wrong information <h2></div>';
							$('.messageadv').html(error);
							$('html, body').animate({scrollTop:$('.messageadv').offset().top}, 'slow');
						}else{
							var error = '<div class="messageadv">Sorry you have entered wrong information </div>';
							$('.messageadv').html(error);
							$('html, body').animate({scrollTop:$('.messageadv').offset().top}, 'slow');
						}               									
				}						
    });
  });
	
	/*	//Forget Form   */
	$("#fgtForm").submit(function(event){
		event.preventDefault();	
		var modal = $("#sign-earth");		
		var ltype = modal.find('#ltype').val();
		
    $.ajax({
        type: "POST",
        url: base_url+"Login/Forget_Password",
			  data: {
            email: $("#femail").val(),
						ltype: ltype
        }, 
        success:function(data){
            console.log(data);
						if($.trim(data) == 'yes'){
							var error = '<div class="errormsgdown">Successfully Sent </div>';
							$('.errormsgdown').html(error);
							$('html, body').animate({scrollTop:$('.modal-dialog.gc-sign-modal-dialog').offset().top}, 'slow');
							document.location.reload();
						}else{
							var error = '<div class="errormsgdown">Sorry you have entered wrong information </div>';
							$('.errormsgdown').html(error);
							$('html, body').animate({scrollTop:$('.modal-dialog.gc-sign-modal-dialog').offset().top}, 'slow');
						}
				}						
    });
  });
   
	/*  // Customer login  //  Signin   */
	$("#form_login").submit(function(event){
		event.preventDefault();	
		var modal = $("#sign-earth");		
		var ltype = modal.find('#ltype').val();
		console.log('ltype');
		$.ajax({
				type: "POST",
				url: base_url+"Login/signin",
				data: {
					username: $("#username").val(),
					password: $("#password").val(),
					ltype: ltype
				}, 
				success:function(data){
					if($.trim(data) == 'Yes'){ 
						if(ltype == 'customer'){
							window.location.href= _url+'Customer/Profile_View';
						}else if(ltype == 'lawyer'){
							window.location.href= _url+'Lawyer/View_Profile';
						}
					}else if($.trim(data) == 'No'){
						var error = '<div class="errormsg">Sorry you have entered wrong information </div>';
						$('.errormsg').html(error);
						$('html, body').animate({scrollTop:$('.modal-dialog.gc-sign-modal-dialog').offset().top}, 'slow');
					}else{
						/* window.location.reload();  */
						/* var error = '<div class="errormsg">Sorry you have entered wrong information </div>'; */
						var error = '<div class="errormsg">Sorry, Some error occured. </div>';
						$('.errormsg').html(error);
						$('html, body').animate({scrollTop:$('.modal-dialog.gc-sign-modal-dialog').offset().top}, 'slow');
						window.location.href= _url+'Logout';
					}													
				}						
    });
  });

	$("#sendotp").click(function(e){
		var buttonp = $(this);
		buttonp.addClass('disabled');
		buttonp.html('working...');
		var firstname = $("#firstname").val();
		var lastname = $("#lastname").val();
		var email = $("#email").val();
		var password = $("#uppassword").val();
		var confirm_password = $("#confirm_password").val();
		var mobile = $("#mobile").val();
		var check = $("#check1").val();
		var ltype = $("#type").val();
		
		if(ltype=='lawyer'){
			var barcouncil_number = "";
			var council_idphoto = "";
			barcouncil_number = $("#barcouncil_number").val();
			council_idphoto = $('#council_idphoto').prop('files')[0];
			if ($('#form_logenroll').parsley().validate()) {
				var form = $('#form_logenroll')[0]; 
				var formData = new FormData(form);
				$.ajax({
					url: base_url+"Login/send_otp",
					data: formData,
					type: 'POST',
					contentType: false, 
					processData: false, 				
					success:function(data){
						buttonp.removeClass('disabled');
						buttonp.html('SIGN UP');
						if($.trim(data)!='NO'){
							$('#signup').html(data);	
						}else if($.trim(data)=='NO'){
							var error = '<div class="errormsgup">Email or Mobile is already Exist. </div>';
							$('.errormsgup').html(error);
							$('html, body').animate({scrollTop:$('.modal-dialog.gc-sign-modal-dialog').offset().top}, 'slow');
							
						}						
					},
					error: function(data) {				                 
						var error = '<div class="errormsgup">Sorry you have entered wrong information. </div>';
						$('.errormsgup').html(error);
						$('html, body').animate({scrollTop:$('.modal-dialog.gc-sign-modal-dialog').offset().top}, 'slow');
					}
				});
			}
		}
		
		if(ltype=='customer'){
			if ($('#form_logenroll').parsley().validate()) {
				if(password != confirm_password){
					var error = '<div class="errormsgup">Password and Confirm Password must be same. </div>';
					$('.errormsgup').html(error);
					$('html, body').animate({scrollTop:$('.modal-dialog.gc-sign-modal-dialog').offset().top},'slow');
				}else{
					$.ajax({
						type: "POST",
						url: base_url+"Login/send_otp",
						data: {
								firstname: firstname,
								lastname: lastname,
								email: email,
								password: password,
								confirm_password: confirm_password,
								mobile: mobile,
								type: ltype
						}, 
						success:function(data){
							buttonp.removeClass('disabled');
							buttonp.html('SIGN UP');
							if($.trim(data)!='NO'){
								$('#signup').html(data);	
							}else if($.trim(data)=='NO'){
								var error = '<div class="errormsgup">Email or Mobile is already Exist. </div>';
								$('.errormsgup').html(error);
								$('html, body').animate({scrollTop:$('.modal-dialog.gc-sign-modal-dialog').offset().top}, 'slow');
							}						
						},
						error: function(data) {				                 
							var error = '<div class="errormsgup">Sorry you have entered wrong information. </div>';
							$('.errormsgup').html(error);
							$('html, body').animate({scrollTop:$('.modal-dialog.gc-sign-modal-dialog').offset().top}, 'slow');
						}
						
					});	
				}
			}	
		}
	});

	/*	//CONULT NOW SUBMIT BUTTON ACTION  */
	$("#actionform").submit(function(event){
	  event.preventDefault();						   					  
		$('html, body').animate({scrollTop:$('.gc-hw-it.action-form').offset().top}, 'slow');					  		
	});
		
	if($('.gc-filter-wrap').length > 0) {
		$("body, html").animate({ scrollTop: $('.gc-filter-wrap').offset().top - 50 }, "slow");
	}
	
	$('body').on('change','#state',function(){
		$.ajax({ 
			type: 'POST', 
			url: base_url+"State/get_cities_by_stateid",
			data: {
				state : $("#state").val()
			},  
			dataType: 'html',
			success: function (data) {	
				$('#city').html(data);
			}
		});			   
	});
	$('body').on('change','#city',function(){
		$.ajax({ 
			type: 'POST', 
			url: base_url+"State/get_locality_by_cityid",
			data: {
				city : $("#city").val()
			},  
			dataType: 'html',
			success: function (data) {	
				$('#locality').html(data);
			}
		});			   
	});
	
	
});	