
jQuery(document).ready(function ($) {   
/*-------------------Load predefined functions-----------------*/	

/*------------------- Filter Function--------------------*/
	$('.form_advice').submit(function(event) {
		event.preventDefault();
	});
	$('.form_advice .filter-advicefield').on("change", function(event) {
		event.preventDefault();
		$('#current_pageadvice').val(1);
		filter_advice();
	});
	
	$('.filter-adv-url').on("change", function(event) {	
		urlchange1();
	});
	
	
	
});
/*-------------------------- Filter Results -----------------------------*/
function filter_advice() {
	var value = $('.form_advice').serialize();
	$.ajax({
			type: "POST",
			url: base_url+"Free_Advice/filterquestion",
			data: value,
			success: function(data) {
				data = JSON.parse(data);
				if(data['total'] == 0) {					
					$(".gc-settings-btn-bay.load-mores-button").hide();
				}
				else{															
				$('html, body').animate({scrollTop:$('.gc-question-bay.advicefilter').offset().top}, 'slow');									
				if(data['total'] >= 4) {	
				
					$(".gc-settings-btn-bay.load-mores-button").show();
					$('.moresbox').show();
					$('.moresbox').attr('id','mores'+data['last_id']);
					$('.adviceloadmore').attr('id',data['last_id']);
				} else {
					$(".gc-settings-btn-bay.load-mores-button").hide();
				}					
				}
				$('.gc-advocate1 ul').html(data['temp']);
			}
	});
}

function urlchange1() {
	event.preventDefault();
	var result = "/Free-Advice/";
	window.history.pushState("", "", result);
	var state_t = ($('#state :selected').text()=="State") ? "" : $('#state :selected').text()+"/" ;
	var state_text = state_t.replace(/\s+/g, '-');
	if(state_text != ''){
		result = result + state_text ;
	}
	
	var city_t  = ($('#city :selected').text()=="City" || $('#city :selected').text()=="Select City") ? "" : $('#city :selected').text()+"/";
	var city_text  = city_t.replace(/\s+/g, '-');
	if(city_text != ''){
		result = result + city_text ;
	}
	
	var locality_t = ($('#locality :selected').text()=="Select Locality") ? "" : $('#locality :selected').text()+"/";
	var locality_text = locality_t.replace(/\s+/g, '-');
	if(locality_text != ''){
		result = result + locality_text ;
	}
	
	var practice_t = ($('#practice :selected').text()=="Practice Area") ? "" : $('#practice :selected').text()+"/";
	var practice_text = practice_t.replace(/\s+/g, '-');
	if(practice_text != ''){
		result = result + practice_text ;
	}
	
	window.history.pushState("", "", result);
}

