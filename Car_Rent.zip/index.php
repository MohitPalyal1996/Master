<?php include_once 'include/header.php'; ?>
<script src="js/country.js"></script>
<section class="rev_slider_wrapper" style="margin-top: 65px;">
		<div id="slider1" class="rev_slider"  data-version="5.0">
			<ul>
				<li data-transition="">
		<img src="img/slider1.png"  alt=""  width="1920" height="705" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="2" >
			 <div class="tp-caption sfl tp-resizeme caption-label" 
				        data-x="left" data-hoffset="0" 
				        data-y="top" data-voffset="180" 
				        data-whitespace="nowrap"
				        data-transform_idle="o:1;" 
				        data-transform_in="o:0" 
				        data-transform_out="o:0" 
				        data-start="500">

						luxury car rental
				    </div>
					<!-- <div class="tp-caption sfl tp-resizeme caption-label" 
				        data-x="left" data-hoffset="0" 
				        data-y="top" data-voffset="180" 
				        data-whitespace="nowrap"
				        data-transform_idle="o:1;" 
				        data-transform_in="o:0" 
				        data-transform_out="o:0" 
				        data-start="500">

						luxury car rental
				    </div>
					<div class="tp-caption sfr tp-resizeme caption-h1" 
				        data-x="left" data-hoffset="0" 
				        data-y="top" data-voffset="225" 
				        data-whitespace="nowrap"
				        data-transform_idle="o:1;" 
				        data-transform_in="o:0" 
				        data-transform_out="o:0" 
				        data-start="1000">
						Mercedes E 220 
				    </div>
					<div class="tp-caption sfr tp-resizeme caption-p" 
				        data-x="left" data-hoffset="0" 
				        data-y="top" data-voffset="280" 
				        data-whitespace="nowrap"
				        data-transform_idle="o:1;" 
				        data-transform_in="o:0;t:1000" 
				        data-transform_out="o:0" 
				        data-start="1500">
						4 Seater 
				    </div>
					<div class="tp-caption sfr tp-resizeme " 
				        data-x="left" data-hoffset="0" 
				        data-y="top" data-voffset="340" 
				        data-whitespace="nowrap"
				        data-transform_idle="o:1;" 
				        data-transform_in="o:0;t:1000" 
				        data-transform_out="o:0" 
				        data-start="2000">
						 -->
				    </div>
				</li>
				<!-- <li data-transition="slidingoverlayleft">
					<img src="img/slider2.png"  alt="" width="1920" height="705" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" >
					<div class="tp-caption sfl tp-resizeme caption-label" 
				        data-x="left" data-hoffset="0" 
				        data-y="top" data-voffset="180" 
				        data-whitespace="nowrap"
				        data-transform_idle="o:1;" 
				        data-transform_in="o:0" 
				        data-transform_out="o:0" 
				        data-start="500">
						luxury coach rental
				    </div>
					<div class="tp-caption sfr tp-resizeme caption-h1" 
				        data-x="left" data-hoffset="0" 
				        data-y="top" data-voffset="225" 
				        data-whitespace="nowrap"
				        data-transform_idle="o:1;" 
				        data-transform_in="o:0" 
				        data-transform_out="o:0" 
				        data-start="1000">
						Mercedes coaches
				    </div>
					<div class="tp-caption sfr tp-resizeme caption-p" 
				        data-x="left" data-hoffset="0" 
				        data-y="top" data-voffset="280" 
				        data-whitespace="nowrap"
				        data-transform_idle="o:1;" 
				        data-transform_in="o:0;t:1000" 
				        data-transform_out="o:0" 
				        data-start="1500">
						44 Seater 
				    </div>
					<div class="tp-caption sfr tp-resizeme " 
				        data-x="left" data-hoffset="0" 
				        data-y="top" data-voffset="340" 
				        data-whitespace="nowrap"
				        data-transform_idle="o:1;" 
				        data-transform_in="o:0;t:1000" 
				        data-transform_out="o:0" 
				        data-start="2000">
						
				    </div>
				</li> -->
			</ul>
		</div>
	</section>

	<section class="search-form-box">
		<div class="container">
			<div class="form-box">
			<!-- 	<label>Select Country</label> -->

				<select class="form-control" id="country" name="country" placeholder="counetr" required="">
					<option></option>
				</select>
			</div>
			<div class="form-box">
			<!-- 	<label>Select State</label> -->
				<select class="form-control" name="state" id="state" required="">
					<option>Select State</option>
</select>
			</div>
			<script language="javascript">
populateCountries("India", "state");
populateStates("state");
</script>

			<div class="form-box">
				<!-- <label>Select Car</label> -->
				<select class="form-control" >
						<option >Select Car</option>
					<option value="#"><a href="car.html">Suv</option>
					<option value="#">- select a brand -</option>
					<option value="#">- select a brand -</option>
					<option value="#">- select a brand -</option>
					<option value="#">- select a brand -</option>
					<option value="#">- select a brand -</option>
					<option value="#">- select a brand -</option>
				</select>
			</div>
			<!-- <div class="form-box price-ranger">
				<p>Price (Lt)  <span class="ranger-min-max-block"> <span class="min"></span> - <span class="max"></span></span></p>
				<div id="slider-range"></div>
			</div> -->
			<div class="form-box submit-handler pull-right">
				<button type="submit" class="thm-btn" > search <i class="fa fa-search"></i></button>
			</div>
		</div>
	</section>

 <section class="welcome-section section-padding">
		<div class="container">
			<div class="section-title text-center">
				<h2>
					<span>welcome to  hire Luxury car</span>
				</h2>
				
		    </div>
			<div class="row">
				<div class="col-md-12 col-sm-12">
					<div class="single-welcome">
						<div class="top-box">
							<div class="icon-box">
								<img src="img/icon/1.png" alt="">
							</div>
							<div class="content-box">
								<h3>Car dealer number one world wide</h3>
							</div>
						</div>
						<p>Adrenture  having a solid experience of more than 17 years in the field of tourism & hospitality industry who have in-depth knowledge of India to prepare any sort of itineraries which give you unlimited opportunity to organize, select and book the type of Car that is attractive to you and your clients. Above all, these are itineraries with utmost respect for your money and can also be modified to suit the individual requirements.</p>
						<br>
						<p>Adrenture, was founded in XXXX as a Luxury Tourist Transport Operator. Adrenture owned and operated the largest fleet of imported luxury cars and coaches in the country. our all vehicles are immaculately maintained & driven by experienced, courteous and well mannered uniformed chauffeurs having operational mobile phone with them.</p>
					</div>
				</div>
				<div class="clearfix"></div>
				<!-- <br>
				<br>
				<div class="col-md-12 col-sm-12">
					<div class="single-welcome">
						<div class="top-box">
							<div class="icon-box">
								<img src="img/icon/2.png" alt="">
							</div>
							<div class="content text-center-box">
								<h3>We are about your sercurity in our cars</h3>
							</div>
						</div>
						
					</div>
				</div> -->
			</div>
		</div>
	</section>
	<section class="call-to-action">
		<div class="container">
			<div class="row">
				<div class="col-md-5">
					<h2>Our Most Important <span>Prices & Awards</span></h2>
				</div>
				<div class="col-md-7">
					<div class="icon-box pull-left">
						<div class="box">
							<img src="img/icon/3.png" alt="Awesome Image"/>
						</div>
						<h3>First Class Cars</h3>
					</div>
					<div class="icon-box pull-left">
						<div class="box">
							<img src="img/icon/4.png" alt="Awesome Image"/>
						</div>
						<h3>Number One Dealer</h3>
					</div>
					<div class="icon-box pull-left">
						<div class="box">
							<img src="img/icon/5.png" alt="Awesome Image"/>
						</div>
						<h3>Rated with 5 stars</h3>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="search-result text-center gray-bg">
		<div class="container">
		<div class="section-title text-center">
				<h2>
					<span>our car &amp; coaches</span>
				</h2>
				
		    </div>
			<div class="col-md-3 col-sm-6">
				<div class="single-search-result">
					<div class="img-box">
						<a href="our_cars.php"><img src="img/car1.png" alt="Awesome Image"/></a>
					</div>
					<a href="our_cars.php"><h3>Excutive Cars</h3>
					<span class="price">View </span></a>
				</div>
			</div>
			<div class="col-md-3 col-sm-6">
				<div class="single-search-result">
					<div class="img-box">
						<a href="our_cars.php"><img src="img/3.png" alt="Awesome Image"/></a>
					</div>
					<a href="our_cars.php"><h3>Luxury Cars</h3>
					<span class="price">View</span></a>
				</div>
			</div>
			<div class="col-md-3 col-sm-6">
				<div class="single-search-result">
					<div class="img-box">
						<a href="our_coaches.php"><img src="img/6.png" alt="Awesome Image"/></a>
					</div>
					<a href="our_coaches.php"><h3>Executive Coaches</h3>
					<span class="price">View</span></a>
				</div>
			</div>
			<div class="col-md-3 col-sm-6">
				<div class="single-search-result">
					<div class="img-box">
						<a href="our_coaches.php"><img src="img/7.png" alt="Awesome Image"/></a>
					</div>
					<a href="our_coaches.php"><h3>Luxury Coaches</h3>
					<span class="price">View</span></a>
				</div>
			</div>
		</div>
	</section>

	
	

   

	<!-- <section class="why-choose-us section-padding">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-4">
					<div class="single-why-choose-us clearfix">
						<div class="img-box">
							<img src="img/why-choose-us/1.jpg" alt="">
						</div>					
						<h3>Car dealer number one world wide</h3>
						<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
						<a href="#" class="pull-right">Read More</a>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="single-why-choose-us clearfix">
						<div class="img-box">
							<img src="img/why-choose-us/2.jpg" alt="">
						</div>					
						<h3>Why you should choose us</h3>
						<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
						<a href="#" class="pull-right">Read More</a>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="single-why-choose-us clearfix">
						<div class="img-box">
							<img src="img/why-choose-us/3.jpg" alt="">
						</div>					
						<h3>We provide security and quality cars</h3>
						<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
						<a href="#" class="pull-right">Read More</a>
					</div>
				</div>
			</div>
		</div>
	</section> -->

	
		
	<!-- <section class="what-we-offer">
		<div class="container">
			<div class="top-box">
				<div class="clearfix">
					<div class="col-md-5">
						<div class="left-text">
							<h2>We offer clean cars <br>for everyone</h2>
							<span>fast. cheap. quality. security</span>
						</div>
					</div>
					<div class="col-md-7">
						<div class="right-text">
							<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section> -->

<!-- 		<section class="vehicle-sorter-area section-padding">
		<div class="container">
			<div class="section-title text-center">
				<h2>
					<span>OUR Luxury VEHICLES</span>
				</h2>
			</div>
			<div class="vehicle-sorter-wrapper mix-it-gallery">
				<ul class="gallery-filter list-inline">
					<li class="filter" data-filter="all"><span>ALL</span></li>
					<li class="filter" data-filter=".excars"><span>Executive cars</span></li>
					<li class="filter" data-filter=".lxcars"><span>Luxury cars</span></li>
					<li class="filter" data-filter=".excoaches"><span>Executive coaches</span></li>
					<li class="filter" data-filter=".lxcoaches"><span>Luxury coaches</span></li>
					
				</ul>
				<div class="row">
					<br>
					<br>
					<div class="col-md-6 col-sm-6 mix excars">
						<div class="single-vehicle-sorter">
							<div class="img-box">
								<a href="#"><img src="img/1.png" alt=""></a>
							</div>
							<a href="#"><h3>Swift Dzire</h3></a>
							<div class="middle-box-wrapper clearfix">
								<div class="middle-box">
									<ul>
										<li><span>Seating Capacity:</span> 4 +Driver</li>
										<li><span>Luggage Capacity:</span> 2 Bags</li>
										<li><span>Air Conditioning:</span> Yes</li>
									</ul>
								</div>
								<div class="middle-box">
									<ul>
										<li><span>Music Player:</span> Yes</li>
										<li><span>Seat Belts:</span> Yes</li>
									</ul>
								</div>
								<div class="middle-box">
									<a  href="booknow.php?message=Swift Dzire" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
								</div>
							</div>
							
						</div>
					</div>
					<div class="col-md-6 col-sm-6 mix excars">
						<div class="single-vehicle-sorter">
							<div class="img-box">
								<a href="#"><img src="img/2.png" alt=""></a>
							</div>
							<a href="#"><h3>Toyota Etios</h3></a>
							<div class="middle-box-wrapper clearfix">
							<div class="middle-box">
							<ul>
								<li><span>Seating Capacity:</span> 4 +Driver</li>
								<li><span>Luggage Capacity:</span> 2 Bags</li>
								<li><span>Air Conditioning:</span> Yes</li>
							</ul>
						</div>
						<div class="middle-box">
							<ul>
								<li><span>Music Player:</span> Yes</li>
								<li><span>Seat Belts:</span> Yes</li>
							</ul>
						</div>
						<div class="middle-box">
							<a  href="booknow.php?message=Toyota Etios" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
						</div>
							</div>	
						</div>
					</div>
					<div class="col-md-6 col-sm-6 mix lxcars">
						<div class="single-vehicle-sorter">
							<div class="img-box">
								<a href="#"><img src="img/3.png" alt=""></a>
							</div>
							<a href="#"><h3>Audi A6</h3></a>
							<div class="middle-box-wrapper clearfix">
							<div class="middle-box">
							<ul>
								<li><span>Seating Capacity:</span> 4 +Driver</li>
								<li><span>Luggage Capacity:</span> 4 Bags</li>
								<li><span>Air Conditioning:</span> Yes</li>
							</ul>
						</div>
						<div class="middle-box">
							<ul>
								<li><span>Music Player:</span> Yes</li>
								<li><span>Seat Belts:</span> Yes</li>
							</ul>
						</div>
						<div class="middle-box">
							<a  href="booknow.php?message=Audi A6" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
						</div>
							</div>
							
						</div>
					</div>
					<div class="col-md-6 col-sm-6 mix lxcars">
						<div class="single-vehicle-sorter">
							<div class="img-box">
								<a href="#"><img src="img/4.png" alt=""></a>
							</div>
							<a href="#"><h3>Audi Q7</h3></a>
							<div class="middle-box-wrapper clearfix">
							<div class="middle-box">
							<ul>
								<li><span>Seating Capacity:</span> 4 +Driver</li>
								<li><span>Luggage Capacity:</span> 4 Bags</li>
								<li><span>Air Conditioning:</span> Yes</li>
							</ul>
						</div>
						<div class="middle-box">
							<ul>
								<li><span>Music Player:</span> Yes</li>
								<li><span>Seat Belts:</span> Yes</li>
							</ul>
						</div>
						<div class="middle-box">
							<a  href="booknow.php?message=Audi Q7" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
						</div>
							</div>
							
						</div>
					</div>
					<div class="col-md-6 col-sm-6 mix excoaches">
						<div class="single-vehicle-sorter">
							<div class="img-box">
								<a href="#"><img src="img/5.png" alt=""></a>
							</div>
							<a href="#"><h3>Toyota Coaster</h3></a>
							<div class="middle-box-wrapper clearfix">
							<div class="middle-box">
							<ul>
								<li><span>Seating Capacity:</span> 13/17 Seater</li>
								<li><span>Fuel:</span> Diesel</li>
								
							</ul>
						</div>
						<div class="middle-box">
							<ul>
								<li><span>Music Player:</span> Yes</li>
								<li><span>Air Conditioning:</span> Yes</li>
							</ul>
						</div>
						<div class="middle-box">
							<a  href="booknow.php?message=Toyota Coaster" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
						</div>
							</div>
							
						</div>
					</div>
					<div class="col-md-6 col-sm-6 mix excoaches">
						<div class="single-vehicle-sorter">
							<div class="img-box">
								<a href="#"><img src="img/6.png" alt=""></a>
							</div>
							<a href="#"><h3>Fiat Ducato</h3></a>
							<div class="middle-box-wrapper clearfix">
							<div class="middle-box">
							<ul>
								<li><span>Seating Capacity:</span> 12+ Driver</li>
								<li><span>Fuel:</span> Diesel</li>
								
							</ul>
						</div>
						<div class="middle-box">
							<ul>
								<li><span>Music Player:</span> Yes</li>
								<li><span>Air Conditioning:</span> Yes</li>
							</ul>
						</div>
						<div class="middle-box">
							<a  href="booknow.php?message=Fiat Ducato" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
						</div>
							</div>
							
						</div>
					</div>
					<div class="col-md-6 col-sm-6 mix lxcoaches">
						<div class="single-vehicle-sorter">
							<div class="img-box">
								<a href="#"><img src="img/7.png" alt=""></a>
							</div>
							<a href="#"><h3>Mercedes Coach</h3></a>
							<div class="middle-box-wrapper clearfix">
							<div class="middle-box">
							<ul>
								<li><span>Seating Capacity:</span> 44+ Driver</li>
								<li><span>Fuel:</span> Diesel</li>
								<li><span>Air Conditioning:</span> Yes</li>
							</ul>
						</div>
						<div class="middle-box">
							<ul>
								<li><span>Music Player:</span> Yes</li>
								<li><span>Doors:</span> 2</li>
							</ul>
						</div>
						<div class="middle-box">
							<a  href="booknow.php?message=Mercedes Coach" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
						</div>
							</div>
							
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</section>
 -->

	<section class="testimonials section-padding testimonials-carousel">
		<div class="container">
			<div class="section-title text-center">
				<h2>
					<span>what did our clients say</span>
				</h2>
			</div>
			<div class="owl-carousel owl-theme">
				<div class="item">
					<div class="single-testimonials">
						<p>“ Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed. ”</p>
						<div class="box">
							<div class="img-box">
								<img src="img/testimonials/1.png" alt="Awesome Image"/>
							</div>
							<div class="content">
								<h3>Lisa Meyers</h3>
								<p>Marketing Agency Ltd.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="single-testimonials">
						<p>“ Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed. ”</p>
						<div class="box">
							<div class="img-box">
								<img src="img/testimonials/2.png" alt="Awesome Image"/>
							</div>
							<div class="content">
								<h3>Lisa Meyers</h3>
								<p>Marketing Agency Ltd.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="single-testimonials">
						<p>“ Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed. ”</p>
						<div class="box">
							<div class="img-box">
								<img src="img/testimonials/3.png" alt="Awesome Image"/>
							</div>
							<div class="content">
								<h3>Lisa Meyers</h3>
								<p>Marketing Agency Ltd.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="single-testimonials">
						<p>“ Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed. ”</p>
						<div class="box">
							<div class="img-box">
								<img src="img/testimonials/1.png" alt="Awesome Image"/>
							</div>
							<div class="content">
								<h3>Lisa Meyers</h3>
								<p>Marketing Agency Ltd.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="single-testimonials">
						<p>“ Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed. ”</p>
						<div class="box">
							<div class="img-box">
								<img src="img/testimonials/2.png" alt="Awesome Image"/>
							</div>
							<div class="content">
								<h3>Lisa Meyers</h3>
								<p>Marketing Agency Ltd.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="single-testimonials">
						<p>“ Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed. ”</p>
						<div class="box">
							<div class="img-box">
								<img src="img/testimonials/3.png" alt="Awesome Image"/>
							</div>
							<div class="content">
								<h3>Lisa Meyers</h3>
								<p>Marketing Agency Ltd.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="single-testimonials">
						<p>“ Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed. ”</p>
						<div class="box">
							<div class="img-box">
								<img src="img/testimonials/1.png" alt="Awesome Image"/>
							</div>
							<div class="content">
								<h3>Lisa Meyers</h3>
								<p>Marketing Agency Ltd.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="single-testimonials">
						<p>“ Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed. ”</p>
						<div class="box">
							<div class="img-box">
								<img src="img/testimonials/2.png" alt="Awesome Image"/>
							</div>
							<div class="content">
								<h3>Lisa Meyers</h3>
								<p>Marketing Agency Ltd.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="single-testimonials">
						<p>“ Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed. ”</p>
						<div class="box">
							<div class="img-box">
								<img src="img/testimonials/3.png" alt="Awesome Image"/>
							</div>
							<div class="content">
								<h3>Lisa Meyers</h3>
								<p>Marketing Agency Ltd.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	

	<!-- <section class="gallery-wrapper section-paddings pb0">
		<div class="container-fulid">
			<div class="section-title text-center">
				<h2><span>customize your tour</span></h2>
			</div>
			
			<div class="owl-carousel owl-theme">
				<div class="item">
					<div class="single-gallery-item">
						<div class="img-box">
							<img src="img/gallery/1.jpg" alt="Awesome Image"/>
							<div class="overlay">
								<div class="box">
									<div class="content">
										<a href="img/gallery/big/1.jpg" class="fancybox" ><span>Rajasthan Tour</span></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="single-gallery-item">
						<div class="img-box">
							<img src="img/gallery/2.jpg" alt="Awesome Image"/>
							<div class="overlay">
								<div class="box">
									<div class="content">
										<a href="https://www.youtube.com/watch?v=KssOT2QVg-M" class="video-fancybox" data-fancybox-group="service-gallery"><i class="fa fa-play"></i></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="single-gallery-item">
						<div class="img-box">
							<img src="img/gallery/3.jpg" alt="Awesome Image"/>
							<div class="overlay">
								<div class="box">
									<div class="content">
										<a href="img/gallery/big/3.jpg" class="fancybox" data-fancybox-group="service-gallery"><i class="fa fa-camera"></i></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="single-gallery-item">
						<div class="img-box">
							<img src="img/gallery/4.jpg" alt="Awesome Image"/>
							<div class="overlay">
								<div class="box">
									<div class="content">
										<a href="img/gallery/big/4.jpg" class="fancybox" data-fancybox-group="service-gallery"><i class="fa fa-camera"></i></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>


		</div>
	</section> -->
	<!-- <section class="latest-news section-padding">
		<div class="container">
			<div class="section-title text-center">
				<h2>
					<span>latest news from the blog</span>
				</h2>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="single-blog-post">
						<div class="img-box">
							<img src="img/latest-blog/1.png" alt="">
							<div class="overlay clearfix">
								<div class="inner-box">
									<div class="box">
										<h3>Our passion is your passion</h3>
										<p class="meta">posted by John Doe on <span>04/06/2016</span></p>
										<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore...</p>
										<a href="#" class="read-more">READ MORE</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="single-blog-post">
						<div class="img-box">
							<img src="img/latest-blog/2.png" alt="">
							<div class="overlay clearfix">
								<div class="inner-box">
									<div class="box">
										<h3>Our passion is your passion</h3>
										<p class="meta">posted by John Doe on <span>04/06/2016</span></p>
										<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore...</p>
										<a href="#" class="read-more">READ MORE</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section> -->
	
<!-- 	<section class="client-carousel">
		<div class="container">
			<div class="owl-carousel owl-theme">
				<div class="item">
					<img src="img/client-carousel/1.jpg" alt="Awesome Image"/>
				</div>
				<div class="item">
					<img src="img/client-carousel/2.jpg" alt="Awesome Image"/>
				</div>
				<div class="item">
					<img src="img/client-carousel/3.jpg" alt="Awesome Image"/>
				</div>
				<div class="item">
					<img src="img/client-carousel/4.jpg" alt="Awesome Image"/>
				</div>
				<div class="item">
					<img src="img/client-carousel/5.jpg" alt="Awesome Image"/>
				</div>
				<div class="item">
					<img src="img/client-carousel/6.jpg" alt="Awesome Image"/>
				</div>
			</div>
		</div>
	</section> -->

	

<?php include_once 'include/footer.php'; ?>
<!-- <style>
		#body >.rev_slider_wrapper {
   width: 100%;
  height: 500px !important;
  overflow: hidden !important;
}
	</style> -->
