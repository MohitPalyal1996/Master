<!-- GET A QUOTE -->

<link rel="stylesheet" type="text/css" href="css/fontawesome-all.css" media="all">
<link rel='stylesheet' id='lawyer-fonts-css'  href='//fonts.googleapis.com/css?family=Gudea%3A400%2C400i%2C700%7CPT+Serif%3A400%2C400i%2C700%2C700i%7CCabin%3A600%7CSlabo+27px%7CGudea%7CCabin&#038;subset=cyrillic%2Ccyrillic-ext%2Clatin%2Clatin-ext&#038;ver=4.8.5' type='text/css' media='all' />

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
 
.half-map{
    height: 360px;
    /*width: 100%;*/
    overflow: hidden;
}



    @media screen and (max-width: 360px) {
  .half-map{
   width: 360px;
   
   

  }
}


*{
    margin:0;
    padding:0;
}

#det{
    margin-right:400px;
    
}
@media screen and (max-width: 360px) {
  #det{
    margin-right:0px;
    margin-top:5px;
   
   

  }
}
@media screen and (max-width: 780px) {
  #det{
    
    margin-top:7px;
   margin-right:10px;
   

  }
}
</style>

<div class="get-a-quote" >
<div class="row align-center">
<div class="column small-12 medium-expand">
<h3 class="get-a-quote__text">Do you need Professional Market Research assistance?</h3>
</div>
<div class="column small-12 shrink">
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="background-color: #171919;border:white;color:white;box-shadow: none;">Get a Quote</button>
</div>

  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
        <form class="contact-form" action="index.php" method="post" onsubmit="return validation()">
         	    <div class="form-group">
         	         <label for="fname">First Name:</label>
                          <input type="text" placeholder="First Name" name="fname" id="firstname" class="form-control" required>
                <span id="firstnameerror" class="text-danger font-weight-bold"></span>
            </div>
            <div class="form-group">
         	         <label for="lname">Last Name:</label>
                          <input type="text" placeholder="Last Name" name="lname" id="lastname" class="form-control" required>
                <span id="lastnameerror" class="text-danger font-weight-bold"></span>
            </div>
        <div class="form-group">
              <label >Email:</label>
                          <input type="text" placeholder="Email" name="email" id="eMAIL" class="form-control" required>
                <span id="emailerror" class="text-danger font-weight-bold"></span>
                        </div>
 
      <div class="form-group">
            <label >Mobile No.:</label>
                           <input type="text" placeholder="Mobile" name="MobileNo" id="mob" class="form-control" required >
                <span id="mobileerror" class="text-danger font-weight-bold"></span>
                        </div>
    

    
     <div class="form-group">
         <label for="name">Add Your Message.:</label>
                            <textarea class="form-control" placeholder="message" id="message" name="message1" required></textarea>
                        </div>
    
   
   <input type="submit" name="submit" class="btn btn-primary">
  </form>
        </div>
       
      

<script type="text/javascript">
    function validation(){

    var firstname = document.getElementById('firstname').value;
     var lastname = document.getElementById('lastname').value;
    // var password = document.getElementById('password').value;
    // var cONFIRMpASSWORD = document.getElementById('cONFIRMpASSWORD').value;
    var eMAIL = document.getElementById('eMAIL').value;
    var mob = document.getElementById('mob').value;

    var firstuser = /^[A-Za-z. ]{3,14}$/ ;
    // var lastuser = /^[A-Za-z. ]{3,14}$/ ;
// var passcheck = /^(?=.*[0-9])(?=.*[!@#$%^*])[a-zA-Z0-9!@#$%^&*]{8,15}$/;
var emailcheck = /^[A-Za-z_.]{3,15}@[A-Za-z]{3,}[.]{1}[A-Za-z.]{2,6}$/;
var mobilecheck = /^[6789][0-9]{9}$/;

if(firstuser.test(firstname)){
    document.getElementById('firstnameerror').innerHTML = " ";
}else{
    document.getElementById('firstnameerror').innerHTML ="**firstnameerror is NOT right";
    return false;
}

if(lastuser.test(lastname)){
    document.getElementById('firstnameerror').innerHTML = " ";
}else{
    document.getElementById('lastnameerror').innerHTML ="**lastnameerror is NOT right";
    return false;
}
// if(passcheck.test(password)){
//     document.getElementById('passerror').innerHTML =" ";
// }else{
//     document.getElementById('passerror').innerHTML ="**PASSWORD is NOT Correct";
//     return false;
// }
//  if(cONFIRMpASSWORD.match(password)){
//     document.getElementById('conpasserror').innerHTML =" ";
// }else{
//     document.getElementById('conpasserror').innerHTML ="**PASSWORD is NOT Match";
//     return false;
// }
 if (emailcheck.test(eMAIL)){
    document.getElementById('emailerror').innerHTML =" ";
}else{
    document.getElementById('emailerror').innerHTML ="**Email is NOT Correct";
    return false;
    
}
if (mobilecheck.test(mob)){
    document.getElementById('mobileerror').innerHTML =" ";
}else{
    document.getElementById('mobileerror').innerHTML ="**MOBILE-NUMBER is NOT Correct";
    return false;
}
}
</script>
   
   
       
       
<?php


date_default_timezone_set('Asia/Kolkata');
$date_added=date("Y-m-d");
$date_time_added=date("Y-m-d H:i:s");



if(isset($_POST['submit']))
{


$firstname=$_POST['fname'];
$lastname=$_POST['lname'];
$MobileNo=$_POST['MobileNo'];
$email=$_POST['email'];
$message1=$_POST['message1'];

$touser  = $email; // note the comma
$subject = "Acknowledgment of your Query- " . $date_time_added;

// $subject = "Acknowledgment of your  Query ";
// $query="INSERT INTO `contact_detail`(`name`, `email`, `contact`, `message`, `date_added`, `date_time_added`, `status`) VALUES ('$post_contact_name','$post_contact_email','$post_contact_phone','$post_contact_comments','$date_added','$date_time_added','$status')";
// $crud->execute($query); 

$message = '<html>
					<head>
						<style>
							@media screen and (max-width:550px){
								.exam-detail-wrap-mailer-right{ width:100% !important; }
							}
							@media screen and (max-width:400px){
								.logo-wrap{ width:100% !important; }
								.social-wrap{ width:100% !important; }
								.social-wrap img{ width:30px !important; float:left !important; margin-top:10px; margin-bottom:10px; }
								.social-wrap img:first-child{ margin-left:30%; }
							}
							.exam-detail-wrap-mailer:last-child{ border-bottom:0px solid #ffffff !important; }
							
						</style>
					</head>
					<body style="margin:0; padding:0;">

						<div style="width:90%; margin-left:5%; margin-top:20px;">
							<div style="background:#e5e5e5; float:left; width:90%; padding:10px 5%; border:1px solid #e5e5e5;">
								<h5> STEEPBRAIN <h5>
								
							</div><br/><br/><div style="width:100%; margin-left:0%;">
							<div style="width:100%;border: 1px solid rgba(51, 51, 51, 0.16);">
							<div style="background:#005387; float:left; width:100%;">
							
							</div>
							<div style="clear:both;"></div>
							<div style="background:#f9f9f9; padding:20px 5%; border-bottom:1px solid #9a9a9a;">
		<h2> Dear <span style="color:#017fb9;"> '.$firstname.'&nbsp;' .$lastname.' </span> </h2>
							<table>
							
							</tr>
										
							<br>
				            <tr><td><p> <b>Thank you for showing Interest in STEEPBRAIN, We will contact you soon.</b></p></td></tr>
							</table>
							
						   </div>
						  </div>
						 </div>
						 <div style="background:#e5e5e5; float:left; width:90%; padding:10px 5%; border:1px solid #e5e5e5;">
								<p style="margin:0; text-align:right; font-family:arial; font-size:12px;"> Copyright &copy; 2020 | Powered by <a style="color:#c1272d; text-decoration:none;" href="http://SteepBrain.com" target="_blank">SteepBrain.com </a></p>
							</div>
						</div>
					</body>
				</html>';
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers .= 'From: SteepBrain <info@steepbrain.com>' . "\r\n";
				mail($touser, $subject, $message, $headers);

        
        // mail to admin using SMTP
				
	$toadmin="info@steepbrain.com";
        
        $from = "info@steepbrain.com";
        // $subject = "A New Package Inquiry Received - " . $date_time_added;
        $subject = "A New  Inquiry Received ";
		
		$message = '<html>
					<head>
						<style>
							@media screen and (max-width:550px){
								.exam-detail-wrap-mailer-right{ width:100% !important; }
							}
							@media screen and (max-width:400px){
								.logo-wrap{ width:100% !important; }
								.social-wrap{ width:100% !important; }
								.social-wrap img{ width:30px !important; float:left !important; margin-top:10px; margin-bottom:10px; }
								.social-wrap img:first-child{ margin-left:30%; }
							}
							.exam-detail-wrap-mailer:last-child{ border-bottom:0px solid #ffffff !important; }
							
						</style>
					</head>
					<body style="margin:0; padding:0;">

						<div style="width:90%; margin-left:5%; margin-top:20px;">
							<div style="background:#e5e5e5; float:left; width:90%; padding:10px 5%; border:1px solid #e5e5e5;">
								<h5> SteepBrain <h5>
								
							</div><br/><br/><div style="width:100%; margin-left:0%;">
							<div style="width:100%;border: 1px solid rgba(51, 51, 51, 0.16);">
							<div style="background:#005387; float:left; width:100%;">
							
							</div>
							<div style="clear:both;"></div>
							<div style="background:#f9f9f9; padding:20px 5%; border-bottom:1px solid #9a9a9a;">
							<h3> Dear admin, A New Query Received<span style="color:#017fb9;"></span> </h3>
							
							<p><b>first Name: </b>'.$firstname.'</p>
							<p><b>last Name: </b>'.$lastname.'</p>
							<p><b>User Email: </b>'.$email.'</p>
							<p><b>User Contact: </b>'.$MobileNo.'</p>
							<p><b>User Message: </b>'.$message1.'</p>
							<p><b>Date Contacted: </b>'.$date_time_added.'</p>
                            
							<table>
				            <tr><td><p>A new Applicant contacted you. Thanks.</p></td></tr>
							</table>
						   </div>
						  </div>
						 </div>
						 <div style="background:#e5e5e5; float:left; width:90%; padding:10px 5%; border:1px solid #e5e5e5;">
								<p style="margin:0; text-align:right; font-family:arial; font-size:12px;"> Copyright &copy; 2020 | Powered by <a style="color:#c1272d; text-decoration:none;" href="http://SteepBrain.com" target="_blank">SteepBrain.com </a></p>
							</div>
						</div>
					</body>
				</html>';
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers .= 'From: STEEPBRAIN <info@steepbrain.com>' . "\r\n";
				$result=mail($toadmin, $subject, $message, $headers);
			if($result) 
			{
			$completeurl=$_SERVER['HTTP_REFERER'];			
			$_SESSION['success_msg']="Your query sent successfully, We will contact you soon.";
			echo "<script>window.location='".$completeurl."';</script>";
			}
}













// if (isset($_POST['submit'])) 
// {
  
// $firstname=$_POST['fname'];
// $lasttname=$_POST['lname'];
// $MobileNo=$_POST['MobileNo'];
// $email=$_POST['email'];
// $message=$_POST['message'];

// $password=$_POST['password'];

// $con=mysqli_connect('localhost','root','','decisive_online');
// $query="insert into decisive_online_table (First_name,Last_name,Mobile_number,Email,Message) values ('$firstname','$lasttname',$MobileNo,'$email','$message')";

// $run=mysqli_query($con,$query);
// if($run)
// {

// echo "<h3>Thank you for contacting us</h3>";
// }

//   else
//   {
//     echo "error".mysqli_error($connect);
//   }
// }
  
 ?>

       
       
      </div>
      
    </div>
  </div>


</div>
</div>

<!-- FOOTER -->
<footer class="main-footer dark-section ">

<!-- Footer sidebar -->

<div class="row row-widgets" style="width: 100%;">
<div class="columns small-12 medium-6 large-3">
<div class="widget lawyer_contacts widget-address"><h3 class="widget-title">Contacts</h3>
  <p>C-404,Saffron Block,Niho Scottish Garden, Ahinsa Khand-11, Indirapuram, Ghaziabad(U.P) Pin 201014</p>
  <p class="widget-address__info icon-mobile"><i class="icon-phone-3"></i>Call | 01207961544</p>
<p class="widget-address__info " >
     <i  class="fa fa-whatsapp" aria-hidden="true"></i><a class="whatsapp-text-hvr" href="https://wa.me/9999164802">  WhatsApp | 919999164802</a></p></div>
  <div class="widget widget-subscribe">
    <h2 class="widget-title">Keep in touch with us</h2>
    <p>Information about current events related to our company</p>
 
                
<form  method="post" data-name="Subscription form" >
    <div><input type="text" name="EMAIL" id="EMAIL" placeholder="Enter your e-mail" required />
    <span id="emailerror" class="text-danger font-weight-bold"></span>
<!--<button class="widget-subscribe__submit icon-paper-plane" type="Subsubmit" name="Subsubmit" id="Subsubmit" ></button>-->
<button class="widget-subscribe__submit icon-paper-plane"  type="SEND" name="SEND" ></button>


</div>
<div class="mc4wp-response">
    
</div>
</form>

<script type="text/javascript">
    function validation(){

    
var Emailcheck = /^[A-Za-z_.]{3,15}@[A-Za-z]{3,}[.]{1}[A-Za-z.]{2,6}$/;

}

 if (Emailcheck.test(EMAIL)){
    document.getElementById('Emailerror').innerHTML =" ";
}else{
    document.getElementById('Emailerror').innerHTML ="**Email is NOT Correct";
    return false;

</script>

   
<?php


date_default_timezone_set('Asia/Kolkata');
$date_added=date("Y-m-d");
$date_time_added=date("Y-m-d H:i:s");



if(isset($_POST['SEND']))
{



$EMAIL=$_POST['EMAIL'];


$touser  = $EMAIL; // note the comma
$subject = "Acknowledgment of your Query- " . $date_time_added;

// $subject = "Acknowledgment of your  Query ";
// $query="INSERT INTO `contact_detail`(`name`, `email`, `contact`, `message`, `date_added`, `date_time_added`, `status`) VALUES ('$post_contact_name','$post_contact_email','$post_contact_phone','$post_contact_comments','$date_added','$date_time_added','$status')";
// $crud->execute($query); 

$message = '<html>
					<head>
						<style>
							@media screen and (max-width:550px){
								.exam-detail-wrap-mailer-right{ width:100% !important; }
							}
							@media screen and (max-width:400px){
								.logo-wrap{ width:100% !important; }
								.social-wrap{ width:100% !important; }
								.social-wrap img{ width:30px !important; float:left !important; margin-top:10px; margin-bottom:10px; }
								.social-wrap img:first-child{ margin-left:30%; }
							}
							.exam-detail-wrap-mailer:last-child{ border-bottom:0px solid #ffffff !important; }
							
						</style>
					</head>
					<body style="margin:0; padding:0;">

						<div style="width:90%; margin-left:5%; margin-top:20px;">
							<div style="background:#e5e5e5; float:left; width:90%; padding:10px 5%; border:1px solid #e5e5e5;">
								<h5> STEEPBRAIN <h5>
								
							</div><br/><br/><div style="width:100%; margin-left:0%;">
							<div style="width:100%;border: 1px solid rgba(51, 51, 51, 0.16);">
							<div style="background:#005387; float:left; width:100%;">
							
							</div>
							<div style="clear:both;"></div>
							<div style="background:#f9f9f9; padding:20px 5%; border-bottom:1px solid #9a9a9a;">
		<h2> Dear User <span style="color:#017fb9;">ThankYou For Subscribe </span> </h2>
							<table>
							
							</tr>
										
							<br>
				            <tr><td><p> <b>Thank you for showing Interest in STEEPBRAIN, We will contact you soon.</b></p></td></tr>
							</table>
							
						   </div>
						  </div>
						 </div>
						 <div style="background:#e5e5e5; float:left; width:90%; padding:10px 5%; border:1px solid #e5e5e5;">
								<p style="margin:0; text-align:right; font-family:arial; font-size:12px;"> Copyright &copy; 2020 | Powered by <a style="color:#c1272d; text-decoration:none;" href="http://info@steepbrain.com" target="_blank">info@steepbrain.com </a></p>
							</div>
						</div>
					</body>
				</html>';
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers .= 'From: SteepBrain <info@steepbrain.com>' . "\r\n";
				mail($touser, $subject, $message, $headers);

        
        // mail to admin using SMTP
				
	$toadmin="info@steepbrain.com";
        
        $from = "info@steepbrain.com";
        // $subject = "A New Package Inquiry Received - " . $date_time_added;
        $subject = "A New  Inquiry Received ";
		
		$message = '<html>
					<head>
						<style>
							@media screen and (max-width:550px){
								.exam-detail-wrap-mailer-right{ width:100% !important; }
							}
							@media screen and (max-width:400px){
								.logo-wrap{ width:100% !important; }
								.social-wrap{ width:100% !important; }
								.social-wrap img{ width:30px !important; float:left !important; margin-top:10px; margin-bottom:10px; }
								.social-wrap img:first-child{ margin-left:30%; }
							}
							.exam-detail-wrap-mailer:last-child{ border-bottom:0px solid #ffffff !important; }
							
						</style>
					</head>
					<body style="margin:0; padding:0;">

						<div style="width:90%; margin-left:5%; margin-top:20px;">
							<div style="background:#e5e5e5; float:left; width:90%; padding:10px 5%; border:1px solid #e5e5e5;">
								<h5> SteepBrain <h5>
								
							</div><br/><br/><div style="width:100%; margin-left:0%;">
							<div style="width:100%;border: 1px solid rgba(51, 51, 51, 0.16);">
							<div style="background:#005387; float:left; width:100%;">
							
							</div>
							<div style="clear:both;"></div>
							<div style="background:#f9f9f9; padding:20px 5%; border-bottom:1px solid #9a9a9a;">
							<h3> Dear admin, A New Query Received<span style="color:#017fb9;"></span> </h3>
							
							
							<p><b>User Email: </b>'.$EMAIL.'</p>
						
                            
							<table>
				            <tr><td><p>A new Applicant contacted you. Thanks.</p></td></tr>
							</table>
						   </div>
						  </div>
						 </div>
						 <div style="background:#e5e5e5; float:left; width:90%; padding:10px 5%; border:1px solid #e5e5e5;">
								<p style="margin:0; text-align:right; font-family:arial; font-size:12px;"> Copyright &copy; 2020 | Powered by <a style="color:#c1272d; text-decoration:none;" href="http://steepbrain.com" target="_blank">steepbrain.com</a></p>
							</div>
						</div>
					</body>
				</html>';
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers .= 'From: STEEPBRAIN <info@steepbrain.com>' . "\r\n";
				$result=mail($toadmin, $subject, $message, $headers);
			if($result) 
			{
			$completeurl=$_SERVER['HTTP_REFERER'];			
			$_SESSION['success_msg']="Your query sent successfully, We will contact you soon.";
			echo "<script>window.location='".$completeurl."';</script>";
			}
}

?>

</div>					
</div>

<div class="columns small-12 medium-6 large-3" >
<div class="widget widget_nav_menu"><h3 class="widget-title">Explore Our Site</h3><div class="menu-footer-nav-container"><ul id="menu-footer-nav" class="menu"><li id="menu-item-155" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-155"><a href="index.php">Home</a></li>
<li id="menu-item-156" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-156">
	<a href="about.php">About Us</a></li>
<!--<li id="menu-item-157" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-157">-->
<!--	<a href="#">Our Team</a></li>-->
<li id="menu-item-158" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-158">
	<a href="ourwork.php">Our Services</a></li>
<!--<li id="menu-item-159" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-159">-->
<!--	<a href="#">Publications</a></li>-->
<!--<li id="menu-item-160" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-160">-->
<!--	<a href="#">News</a></li>-->
<li id="menu-item-161" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-161">
	<a href="contact.php">Contact Us</a></li>
</ul></div></div>					</div>


<div id="map" class="half-map" >
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.547006505413!2d77.38049581418859!3d28.643335782413512!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cf1c5d3bd59c9%3A0xf6dd495a69c98c4f!2sSteepBrain%20Research%20%26%20Consultancy!5e0!3m2!1sen!2sin!4v1600936758442!5m2!1sen!2sin" width="590" height="320" frameborder="0" style="border:0;" allowfullscreen=""></iframe>

                    </div>

</div>

<div class="row">
<div class="columns small-12">
<div class="row align-justify align-middle logo-socials-footer small-collapse">
<div class="columns small-12 medium-expand">
<!-- Footer logo -->
<div class="logo">
<a href="#">
<img src="img/logoi.png" >
</a>
</div>
</div>

    <span id="det">Copyright © 2020 Decisive Online</span>

<div class="columns small-12 shrink">
<!-- Footer socials -->
<div class="socials">
<a href="https://www.linkedin.com/in/steepbrain-research-and-consultancy"><i class="icon-twitter"></i></a>
<a href="#"><i class="fa fa-facebook"></i></a>
<a href="#"><i class="icon-rss-1"></i></a>
<a href="#"><i class="icon-linkedin"></i></a>
<a href="#"><i class="icon-pinterest-4"></i></a>
<a href="#"><i class="icon-gplus-1"></i></a>
<a href="#"><i class="icon-instagram"></i></a>
</div>
</div>
</div>
</div>
</div>

</footer>


<link rel='stylesheet' id='custom-menu-styles-css' href='css/custom-menu.css' type='text/css' media='all' />

<script type='text/javascript' src='js/scripts.js'></script>

<script type='text/javascript' src='js/swiper.jquery.min.js'></script>
<script type='text/javascript' src='js/isotope.pkgd.min.js'></script>
<script type='text/javascript' src='js/jquery.matchHeight.js'></script>
<script type='text/javascript' src='js/jquery.magnific-popup.min.js'></script>
<script type='text/javascript' src='js/imagesloaded.min.js'></script>

<script type='text/javascript' src='js/main.js'></script>
<script type='text/javascript' src='js/comment-reply.min.js'></script>
<script type='text/javascript' src='js/wp-embed.min.js'></script>
<script type='text/javascript' src='js/custom-menu.js'></script>
<script type='text/javascript' src='js/meisterbox.js'></script>
<script type='text/javascript' src='js/loader.js'></script>
<script type='text/javascript' src='https://www.google.com/jsapi?ver=2.0'></script>

</script>
<script type='text/javascript' src='js/generator.js'></script>
<script type='text/javascript' src='js/js_composer_front.min.js?ver=5.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mc4wp_forms_config = [];
/* ]]> */
</script>
<script type='text/javascript' src='js/forms-api.min.js'></script>

<!--[if lte IE 9]>
<script type='text/javascript' src='http://lawyer.webtemplatemasters.com/wp-content/plugins/mailchimp-for-wp/assets/js/third-party/placeholders.min.js?ver=4.1.9'></script>
<![endif]-->
</body>

</html>