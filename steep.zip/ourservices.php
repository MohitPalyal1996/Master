<style type="text/css">
	
@media screen and (max-width: 400px;) {
.b-breadcrumbs{
margin-left: 0;
}
}


#sliding-middle-out {
    display: inline-block;
    position: relative;
    margin-left: 17px;
    margin-top:4px
 
}
#sliding-middle-out:after {
    content: '';
    display: block;
     margin-top: 4px;
    height: 2px;
    width: 0px;
    background: transparent;
    transition: width .7s ease, background-color .7s ease;
    
}
#sliding-middle-out:hover:after {
    width: 100%;
     background: -webkit-gradient(linear, 99% 0%, 0% 100%, from(#cc2a2e03), to(#cc2a2e));
} 


#ff{
    
    text-align:center;
}


.slideanim {visibility:hidden;}


 .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    }
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    }
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }


</style>

<?php include 'include/header.php'; ?>


<div class="row">
<div class="column">
<div class="b-breadcrumbs">
<!--<a href="#" class="b-breadcrumbs__link"><b>Home</b></a>-->

<!--<span class="b-breadcrumbs__link"><b>Our Services</b></span>-->
</div>
</div>
</div>

<div class="page-heading overlay" style="width: 100%;height:300px;margin-top: -25px;">
<img style="background-size: cover;" class="s-img-switch" src="img/Technology.jpg" alt="Technology" />
<h2 class="page-heading__title"><hr style="color:white">Our services<hr></h2>
</div>



 


<!-- <div class="row">
<div class="column "> -->
<!-- <b id="linee" style="margin-left: 275px;">
<a href="imdex.php" class="b-breadcrumbs__link"><b>Home</a><b></a>
<span class="">Our Work</span>
</b> -->
<!-- <div class="b-breadcrumbs" style="margin-left: 270px;">
<a href="#" class="b-breadcrumbs__link"><b>Home</b></a>
<span class="b-breadcrumbs__link"><b>About Us</b></span>
</div> -->

<hr style="">

<div class="row slideanim" style="padding-top: 30px;">

<div class="small-12 medium-6 large-4  columns tile-col tile-col--style-2" >
<section class="tile tile--style-2" >
<div class="effect-apollo" style="border-radius:50%;">
<img src="img/Focus.jpg" alt="" style="height: 300px;background-color:transparent;border-radius:50%;"> 
<div class="effect-apollo__overlay"></div>
<a href="Q&QResearch.php" class="tile__link"></a>
</div>
<h3 id="sliding-middle-out" class="tile__title" style="margin-top:14px;margin-left:20px;">Qualitative &amp; Quantitative Research </h3>
<p class="tile__description" id="ff">Qualitative Research provides an understanding of how and why customers take the decisions they make..</p>
</section>
</div>


<div class="small-12 medium-6 large-4  columns tile-col tile-col--style-2">
<section class="tile tile--style-2">
<div class="effect-apollo" style="border-radius:50%;">
<img src="img/program.jpg" alt="" style="height: 310px;background-color:transparent;border-radius:50%;" >
<div class="effect-apollo__overlay"></div>
<a href="Programming.php" class="tile__link"></a>
</div>
<h3 id="sliding-middle-out" class="tile__title" style="margin-top:14px;margin-left:106px;">Programming</h3>
<p class="tile__description" id="ff" id="ff">We are a team of energetic members, experts in Programming complex and customized surveys.</p>
</section>
</div>


<div class="small-12 medium-6 large-4  columns tile-col tile-col--style-2" >
<section class="tile tile--style-2" >
<div class="effect-apollo" style="border-radius:50%;">
<img src="img/cont.jpg" alt="" style="height: 310px;background-color:transparent;border-radius:50%;" >
<div class="effect-apollo__overlay"></div>
<a href="Conjoint.php" class="tile__link"></a>
</div>
<h3 id="sliding-middle-out" class="tile__title" style="margin-left:65px;margin-top:14px;" >Conjoint Data & Simulators</h3>
<p class="tile__description" id="ff">Experimental design principles are used to build different choice sets for testing in the survey..</p>
</section>
</div>


<div class="small-12 medium-6 large-4  columns tile-col tile-col--style-2">
<section class="tile tile--style-2">
<div class="effect-apollo" style="border-radius:50%;">
<img src="img/data1.jpg" alt="" style="height: 310px; background-color:transparent;border-radius:50%;" >
<div class="effect-apollo__overlay"></div>
<a href="DataCollect.php" class="tile__link">
</div>
<h3 id="sliding-middle-out" class="tile__title" style="margin-left:102px;margin-top:14px;"> </a>Data Collection</h3>
<p class="tile__description" id="ff">We at STEEPBRAIN Research have Consumer Panel which gives you access to deeply profiled consumers for your market research..</p>
</section>
</div>


<div class="small-12 medium-6 large-4  columns tile-col tile-col--style-2">
<section class="tile tile--style-2">
<div class="effect-apollo" style="border-radius:50%;">
<img src="img/aa.jpg" alt="" style="height: 310px;background-color:transparent;border-radius:50%;" >
<div class="effect-apollo__overlay"></div>
<a href="DataPro.php" class="tile__link"></a>
</div>
<h3 id="sliding-middle-out" class="tile__title" style="margin-left:60px;margin-top:14px;">Data Processing & Analysis</h3>
<p class="tile__description" id="ff">To bring your research to a point where qualitative and quantitative data is brought together and evaluated to extract conclusion.</p>
</section>
</div>


<div class="small-12 medium-6 large-4  columns tile-col tile-col--style-2">
<section class="tile tile--style-2" >
<div class="effect-apollo" style="border-radius:50%;">
<img src="img/translate.jpg" alt="" style="height: 310px;background-color:transparent;border-radius:50%;" >
<div class="effect-apollo__overlay"></div>
<a href="Translation.php" class="tile__link"></a>
</div>
<h3 id="sliding-middle-out" class="tile__title" style="margin-top:14px;margin-left:120px;">Translation</h3>
<p class="tile__description" id="ff">Being a Market Research company we have natives as translators because we understand for multi-language surveys..</p>
</section>
</div>

<div class="small-12 medium-6 large-4  columns tile-col tile-col--style-2">
<section class="tile tile--style-2" >
<div class="effect-apollo" style="border-radius:50%;">
<img src="img/Digital.jpg" alt="" style="height: 310px;background-color:transparent;border-radius:50%;" >
<div class="effect-apollo__overlay"></div>
<a href="Translation.php" class="tile__link"></a>
</div>
<h3 id="sliding-middle-out" class="tile__title" style="margin-top:14px;margin-left:107px;">Website Design</h3>
<p class="tile__description" id="ff">Any Website is lost if it is not promoted in the Digital World. We have designed specialized training programs through which we undertake extensive training covering Basic Website designing through Wordpress, Basic Graphic Design Using Free Tools Like Canva, SEO , Content Writing, PPC, Facebook Ads, Google Analytic, Linkedin optimization, Instagram..</p>
</section>
</div>

<div class="small-12 medium-6 large-4  columns tile-col tile-col--style-2">
<section class="tile tile--style-2" >
<div class="effect-apollo" style="border-radius:50%;">
<img src="img/Programming.jpg" alt="" style="height: 310px;background-color:transparent;border-radius:50%;" >
<div class="effect-apollo__overlay"></div>
<a href="Translation.php" class="tile__link"></a>
</div>
<h3 id="sliding-middle-out" class="tile__title" style="margin-top:14px;margin-left:107px;">Digital Media</h3>
<p class="tile__description" id="ff">As a leading Website Design and Development Agency we constantly look out for new cutting edge technologies. These new technologies are added to our specialized training programs...</p>
</section>
</div>


<!--<div class="small-12 medium-6 large-4  columns tile-col tile-col--style-2">-->
<!--<section class="tile tile--style-2">-->
<!--<div class="effect-apollo">-->
<!--<img src="img/Digital.jpg" alt="" style="height: 400px;" >-->
<!--<div class="effect-apollo__overlay"></div>-->
<!--<a href="#" class="tile__link"></a>-->
<!--</div>-->
<!--<h3 class="tile__title">Conjoint</h3>-->
<!--<p class="tile__description">Experimental design principles are used to build different choice sets for testing in the survey. The number of conjoint choice sets .</p>-->
<!--</section>-->
<!--</div>-->


<!--<div class="small-12 medium-6 large-4  columns tile-col tile-col--style-2">-->
<!--<section class="tile tile--style-2">-->
<!--<div class="effect-apollo">-->
<!--<img src="img/Programming.jpg" alt="" style="height: 400px;" >-->
<!--<div class="effect-apollo__overlay"></div>-->
<!--<a href="#" class="tile__link"></a>-->
<!--</div>-->
<!--<h3 class="tile__title">Environment</h3>-->
<!--<p class="tile__description">We provide legal assistance on matters referring to the natural environment protection.</p>-->
<!--</section>-->
<!--</div>-->


<!--<div class="small-12 medium-6 large-4  columns tile-col tile-col--style-2">-->
<!--<section class="tile tile--style-2">-->
<!--<div class="effect-apollo">-->
<!--<img src="img/People-Exp.jpg" alt="" style="height: 400px;" >-->
<!--<div class="effect-apollo__overlay"></div>-->
<!--<a href="#" class="tile__link"></a>-->
<!--</div>-->
<!--<h3 class="tile__title">Life sciences &amp; Healthcare</h3>-->
<!--<p class="tile__description">Quisque consectetur lacinia posusa fermentum metus nibh, tincidunt luctus hendrerit, suspendise potent praesent sit amet rhoncus tristique velit felis ultrices pulvinar</p>-->
<!--</section>-->
<!--</div>-->

</div>
<script>
$(document).ready(function(){
    $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>

<!-- </div></div></div></div>
</div>
</div> -->

<?php include 'include/footer.php'; ?>