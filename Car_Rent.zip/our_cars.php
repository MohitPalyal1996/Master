<?php include_once 'include/header.php'; ?>
<section class="inner-banner" style="margin-top: 65px;">
<div class="container text-center">
<h2><span>OUR CARS </span></h2>
</div>
</section>

<section class="vehicle-sorter-area section-padding">
<div class="container">
<div class="vehicle-sorter-wrapper mix-it-gallery">
<ul class="gallery-filter list-inline">
<li class="filter" data-filter="all"><span>ALL</span></li>
<li class="filter" data-filter=".excars"><span>Executive cars</span></li>
<li class="filter" data-filter=".lxcars"><span>Luxury cars</span></li>
<li class="filter" data-filter=".suvcars"><span>MUV/SUV Cars</span></li>
</ul>
<div class="row ">
<br>
<br>
	<div class="col-md-6 col-sm-6 mix party sport">
						<div class="single-vehicle-sorter">
							<div class="img-box">
								<a href="car.php"><<img src="img/vehicle-sorter/1.png" alt=""></a>
							</div>
							<h3>Mercedes </h3>
							<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 7 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Mercedes" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

						
						</div>
					</div>
<div class="col-md-6 col-sm-6 mix suvcars ">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="car.html"><img src="img/car1.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Innova</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 7 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Innova" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix suvcars ">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="car.html"><img src="img/Prado_GXL_Sfx_B0_DSL_040_Glacier_White_033.png" alt=""></a>
</div>
<a href="single-car.html"><h3> Toyota Prado</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 6 +Driver</li>
<li><span>Luggage Capacity:</span> 4 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Toyota prado" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix suvcars ">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="car.html"><img src="img/2017-08_Fortuner_4x4_Wagon_6AT_DSL_GXL_DU_1Y17120DUFN411D6_e360_003.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Toyota Fortuner</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 7 +Driver</li>
<li><span>Luggage Capacity:</span> 4 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Toyota fortuner" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix suvcars ">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/Urvan - 3Quarter View - 1536x864.png.ximg.l_12_m.smart.png" alt=""></a>
</div>
<a href="single-car.html"><h3> Nissan Urvan</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 7 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=nissan Urvan" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix suvcars ">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/Oshawa-airport-limo-service.png" alt=""></a>
</div>
<a href="single-car.html"><h3> Limousine</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>

<li><span>Air Conditioning:</span> Yes</li>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>

</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Limousine" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>








<div class="col-md-6 col-sm-6 mix lxcars ">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/3.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Audi A6</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 4 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Audi A6" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix lxcars ">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/4.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Audi Q7</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 4 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Audi Q7" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix lxcars ">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/Black_BMW_M5_2013_Car_PNG_Clipart-101.png" alt=""></a>
</div>
<a href="single-car.html"><h3>BMW</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 4 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=BMW" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix lxcars ">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/mercedes_PNG1853.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Mercedes E 220 </h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Mercedes E 220" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix lxcars ">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/s-class.png" alt=""></a>
</div>
<a href="single-car.html"><h3> Mercedes S 350 </h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Mercedes S 350" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix lxcars ">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/avi_lux_mercedes_benz_viano2.png" alt=""></a>
</div>
<a href="single-car.html"><h3> Mercedes Viano</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 7 +Driver</li>
<li><span>Luggage Capacity:</span> 8 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Mercedes Viano" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>








<div class="col-md-6 col-sm-6 mix excars item">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/1.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Swift Dzire</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Swift Dzire" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix excars item" >
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/2.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Toyota Etios</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Toyota Etios" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>	
</div>
</div>
<div class="col-md-6 col-sm-6 mix excars item">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/tata_indigo_13.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Indigo</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Indigo" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix excars item" >
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/honda-city-E-limited.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Honda City</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Honda City" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>	
</div>
</div>
<div class="col-md-6 col-sm-6 mix excars item">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/2017_nissan-sunny.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Nissan Sunny</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Nissan Sunny" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix excars item" >
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/2014-Honda-Accord-Sedan-LX-4dr-Sedan-Photo.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Honda Accord</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Honda Accord" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>	
</div>
</div>
<div class="col-md-6 col-sm-6 mix excars item">
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/2007-toyota-camry-hybrid-sedan-angular-front.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Toyota Camry</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Toyota Camry" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>

</div>
</div>
<div class="col-md-6 col-sm-6 mix excars item" >
<div class="single-vehicle-sorter">
<div class="img-box">
<a href="single-car.html"><img src="img/toyota_PNG1949.png" alt=""></a>
</div>
<a href="single-car.html"><h3>Toyota Corolla</h3></a>
<div class="middle-box-wrapper clearfix">
<div class="middle-box">
<ul>
<li><span>Seating Capacity:</span> 4 +Driver</li>
<li><span>Luggage Capacity:</span> 2 Bags</li>
<li><span>Air Conditioning:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<ul>
<li><span>Music Player:</span> Yes</li>
<li><span>Seat Belts:</span> Yes</li>
</ul>
</div>
<div class="middle-box">
<a  href="booknow.php?message=Toyota Corolla" class="thm-btn"><i class="fa fa-angle-right"></i>BOOK NOW</a>
</div>
</div>	
</div>
</div>



</div>

</div>
</div>
</section>	



<?php include_once 'include/footer.php'; ?>

