<?php include 'include/header.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
<style>
    
.container h2 {
    display: inline-block;
    position: relative;
    /*margin-left: 10px;*/
    margin-top:4px
 
}
.container h2:after {
    content: '';
    display: block;
     margin-top: 4px;
    height: 2px;
    width: 0px;
    background: transparent;
    transition: width .7s ease, background-color .7s ease;
    
}
.container h2:hover:after {
    width: 100%;
     background: -webkit-gradient(linear, 99% 0%, 0% 100%, from(#cc2a2e03), to(#cc2a2e));
} 


#med{
    margin-left:310px;
    word-spacing:5px;
     text-transform: uppercase; 
     letter-spacing:2px;
     text-align:center;
     font-family:bold;
     
}



@media screen and (max-width: 1000px) {
  #med{
    margin-left: 0px;
    font-size:27px;
    font-family:serif;
    
  }
}


body{
    margin:0;
    padding:0;
}


#ff{
    font-family:serif;
    /*text-align:center;*/
}


.slideanim {visibility:hidden;}


 .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    }
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    }
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }


</style>

</head>
<body>
   

    <a href="index.php" class="b-breadcrumbs__link"><b>Home</b></a>
    <span class="b-breadcrumbs__link"><b >Our Services</b></span>
    <span class=""><b>DATA PROCESSING & ANALYSIS</b></span>

<div class="Container-fluid" >
				
					<img src="img/dp.jpg" style="width:100%;" >
				    
				</div>
				<div class="row">

</div>
		 <div class="container slideanim"> <br> 
<hr><h2 class="page-title" id="med" style="color:black;">Data Processing & Analytics</h2><hr><br>
<h2 style="color:#b1001e;" class="page-title margin-0">
   Discover options that can give great results</h2>
   <p id="ff" class=" slideanim">To bring your research to a point where qualitative and quantitative data is brought together and evaluated to extract conclusion, We at Decisive Research offer complete data processing and analysis service. It covers both functionalities – standalone data processing or a full-scale process to cover a research project end-to-end.</p>
<br>   
<h2 style=" background: linear-gradient(to right, #33ccff 6%, #ff99cc 100%);border-radius:9%;text-transform:uppercase" ><strong>Data Processing</strong></h2>             
 <p>Services include</p>
           
           <ul class="list-dot  slideanim" style="font-family:italic">
              <li>Tables with multiple banners</li>
              <li>Standard tables with significance testing, moving averages</li>
              <li>Data in Quanvert, SPSS etc</li>
              <li>Trend Charts</li>
              <li>Trend Charts on rolling data</li>
              <li>Continuous tracks, database building</li>
              <li>Recommend weighting models</li>
              <li>Coding of Open ended responses</li>
           </ul>
           
           <p>We can deliver data in multiple formats depending upon your requirement.</p>
           
            
           <ul class="list-dot slideanim" style="font-family:italic">
              <li>SPSS</li>
              <li>Excel</li>
              <li>CSV</li>
              <li>Single or Multi Card ASCII</li>

           </ul>
           
           <h4 style="color:#b1001e;font-family:Bold;">Tools Used</h4>
                      
           <ul class="list-dot slideanim" style="font-family:italic">
              <li>Data Management- Quantum, SPSS & Foxpro</li>
              <li>Data Cleaning & Validation- Quantum & Foxpro</li>
              <li>Data Analytics & Data Processing- Quantum & SPSS</li>
              <li>Advance Analytics- SPSS & other customized tools</li>
            </ul>
           
           <h3 style="color:#b1001e;font-family:Bold;">Advance Analytics</h3>
          
           <ul class="list-dot" style="font-family:italic">
              <li>Factor Analysis</li>
              <li>Regression (Multiple Linear and Logistic)</li>
              <li>Conjoint Analysis</li>
              <li>Discriminate Analysis</li>
              <li>Data Weighting / Data Balancing</li>
              <li>Statistical Test (Significant Tests / Hypothesis Test)</li>
              <li>Need based Segmentation using Latent Class</li>
            </ul>
                         <h3 style="color:#b1001e;font-family:Bold;">Dash Boards</h3>
          
              <p style="font-family:serif" class=" slideanim">We provide customizable dashboards catering to your unique data and reporting needs. This service covers visual representation of your information that is sophisticated and powerful enough to handle your unique requirements. These visualizations are made using Tableau, which can easily become an extension of your thought process.  Made in the form of charts, maps, pies and other graphical representations, it enables better understanding of data and its use to achieve tactical and strategic objectives.</p>
            
           <h3 style="color:#b1001e;font-family:Bold;">Report Writing: Report creation in visual forms.</h3>
           <p style="font-family:serif" class=" slideanim">We offer report writing service for the clients that presents research results, our recommendations, or predictions. Our service also covers report creation in visual forms that makes it easy for your business to shift towards more analytic, data-driven decisions and reduce the time spent in detailing all information manually.</p>

<h3 style="color:#b1001e;font-family:Bold;">Suggesting Corrective Measures Based Upon Research Findings</h3>
<p style="font-family:serif" class=" slideanim">A research has a value only when it is used. We can help you uncover conclusions, generate new ideas, study recommendations, and discover corrective measures to improve your business’s performance. All our services are available as standalone or as a part of any kind of research project taken by us on behalf of our clients.</p>

<h3 style="color:#b1001e;font-family:Bold;">Tools Used</h3>

<h4 style="font-family:Bold;">Tableau</h4>
<p style="font-family:serif" class=" slideanim">Data has no limit. You can collect as much of it, but without knowing how to use it correctly and reinforce its strength to accelerate the growth of business, it is useless. Leveraging the strength of visualization, Tableau lets you analyze data in a way that it becomes easy to decide marketing initiatives and run effective campaigns. It is a powerful, yet flexible medium to deliver research results in a concise way. 

We can help you to implement Tableau and use its features to gain experience in business intelligence. With it, you can also improve the results of ad-hoc analysis on huge data in a fast, flexible way. It can connect to your already created databases and spreadsheets and perform queries by combining multiple views into interactive dashboards.
Our experience-led approach gives you the benefit of creating quick reports and sharing it with the relevant teams for prompt follow-up actions. 

Our expertise in both the desktop and server version also gives you the advantage of sharing insights on the go, allowing your team to interact with visualizations using web browsers or mobile devices. To know more about how working with us can produce consistent approaches to market research, please contact us today.</p>
</div> 
<div class="clearfix"></div>
<script>
$(document).ready(function(){
    $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>
<?php include 'include/footer.php'; ?>
</body>
</html>








