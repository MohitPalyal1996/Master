;(function($, window, document, undefined) {
  "use strict";
  /*===============*/
  /* COMMON VARS */
  /*==============*/
  var $window = $( window );
  function setWindowWidth() {
    $windowWidth = $( window ).width();
    return $windowWidth;
  }
  var $windowWidth = setWindowWidth();

  // At least Safari 3+: "[object HTMLElementConstructor]"
  var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
  var isChrome = !!window.chrome && !!window.chrome.webstore;
  var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0 || !isChrome && !isOpera && window.webkitAudioContext !== undefined;

  var standalone = window.navigator.standalone,
  userAgent = window.navigator.userAgent.toLowerCase(),
  safari = /safari/.test( userAgent ),
  ios = /iphone|ipod|ipad/.test( userAgent );

  if( ios ||  isSafari) {
    $('.team-person').matchHeight();
    $('.tile').matchHeight();
  }

  /*------------------*/
  /* BACKGROUND IMAGE */
  /*------------------*/
  function addImgBg( img_sel, parent_sel){

    if (!img_sel) {
      console.info('no img selector');
      return false;
    }

    var $parent, _this;

    $(img_sel).each(function(){
      _this = $(this);
      $parent = _this.closest( parent_sel );
      $parent = $parent.length ? $parent : _this.parent().addClass('s-back-switch');
      $parent.css( 'background-image' , 'url(' + this.src + ')' );
      _this.hide()
    });
  }

  addImgBg('.s-img-switch', '.s-back-switch');

  /*---------------*/
  /* SWIPER SLIDER */
  /*---------------*/
  var swipers = {};
  var attrsToSize = {
    'data-md-slides' : '1023',
    'data-sm-slides' : '768',
    'data-xs-slides' : '599'
  };

  function parseSlidesAttrValue(value) {
    var parts = value.split(',');
    return {
      slidesPerView: parseInt(parts[0],10),
      spaceBetween: parseInt(parts[1],10)
    }
  }

  function createBreakpoints(container, attrsToSize) {
    var breakpointsObj = {};
    $.each(attrsToSize, function(key ,value) {
      if (container.attr(key)) {
        breakpointsObj[value] = parseSlidesAttrValue(container.attr(key));
      }
    });

    return breakpointsObj;
  }

  $('.swiper-container').each(function(index){
    var $t = $(this);
    var sliderIndex = 'swiper-unique-id-'+ index;
    $t.addClass(sliderIndex + ' initialized').attr('id', sliderIndex);
    $t.find('.swiper-pagination').addClass('pagination-'+ sliderIndex);

    var autoPlayVar = $t.attr('data-autoplay');
    var mode = $t.attr('data-mode');

    var loopVar = $t.attr('data-loop');
    var speedVar = parseInt($t.attr('data-speed'),10);
    var centerVar = $t.attr('data-center');
    var spaceBetweenVar = parseInt($t.attr('data-space-between'),10);
    var slideEffect = $t.attr('data-slide-effect');


    var slidesPerViewVar = parseInt($t.attr('data-slides-per-view'),10);
    if (isNaN(slidesPerViewVar)) {
      slidesPerViewVar = 'auto';
    }

    swipers[sliderIndex] = new Swiper('.' + sliderIndex,{
      loop: loopVar || false,
      autoplay: autoPlayVar || false,
      autoplayDisableOnInteraction: false,
      speed: speedVar || 300,
      slidesPerView: slidesPerViewVar || 1,
      spaceBetween: spaceBetweenVar,
      pagination: '.pagination-' + sliderIndex,
      paginationClickable: true,
      centeredSlides: centerVar || false,
      mode: mode || 'horizontal',
      grabCursor: true,
      keyboardControl: true,
      breakpoints: createBreakpoints($t, attrsToSize),
      setWrapperSize: true,
      effect: slideEffect || 'slide',
      fade: {
        crossFade: true
      }
    });
  });

  /* Toggle menu search form */
  $(".btn-search").on('click', function(event){
    var $searchForm = $(this).parent().parent().find(".menu-search-col");
    var ANIMATION_DURATION = 400;

    if ($searchForm.hasClass('menu-search-col--active')) {
      $searchForm.fadeToggle(ANIMATION_DURATION);

      setTimeout(function () {
        $searchForm.removeClass('menu-search-col--active');
      }, ANIMATION_DURATION);

    } else {
      $searchForm.fadeToggle(ANIMATION_DURATION).addClass('menu-search-col--active');
    }
    event.stopPropagation();
  });

  /* Close search form when click outside it */
  $("body").on('click', function(){
    var $searchForm = $(".btn-search").parent().parent().find(".menu-search-col");

    if ($searchForm.hasClass('menu-search-col--active')) {
      $searchForm.fadeToggle(400);

      setTimeout(function () {
        $searchForm.removeClass('menu-search-col--active');
      }, 400);
    }
  });

  $(".menu-search-col .search-form").on('click', function(event){
    event.stopPropagation();
  });

  /*-----------*/
  /* ACCORDION */
  /*-----------*/
  var accordRemoveClass = function( el, _class ){
    if ( el.classList ) {
      el.classList.remove( _class ? _class : 'active' );
    } else {
      el.className = panel.className.replace(new RegExp('(^|\\b)' + className.split(' ').join('|') + '(\\b|$)', 'gi'), ' ');
    }
  };
  $('.accordion').on('click', '.accordion-title', function() {

    var panel_parent = this.parentNode,
    panel_container = panel_parent.parentNode,
    panels_wrap = panel_container.querySelectorAll('.accordion-item');

    if ( $(this).closest('.accordion').hasClass( 'toggle' ) ) {
      Array.prototype.forEach.call(panels_wrap, function(panel, i) {
        if(panel !== panel_parent) {
          accordRemoveClass(panel);
        }
      });
    }

    if ( -1 !== this.parentNode.className.indexOf( 'active' ) ) {
      accordRemoveClass(panel_parent);
    } else {
      panel_parent.className += ' active';
    }
  });

  /*------*/
  /* TABS */
  /*------*/
  $('.tabs-header').on('click', 'li', function(e) {
    e.preventDefault();
    if (!$(this).hasClass('active')) {
      var index_el = $(this).index();
      $(this).addClass('active').siblings().removeClass('active');
      $(this).closest('.tabs').find('.tabs-item').removeClass('active').eq(index_el).addClass('active');
    }
  });

  /*-----------*/
  /* MAIN MENU */
  /*-----------*/
  var $stickyElement, stickyTopOffset, stickyHeight, $stickyContainer;

  if ($('.js-sticky').length) {
    setTimeout(function () {
      $stickyElement = $('.js-sticky');
      stickyTopOffset = $stickyElement.offset().top;
      $stickyElement.before('<div class="sticky-plug"></div>');
      stickyHeight = $stickyElement.height();
      $stickyContainer = $('.sticky-container').height(stickyHeight + 1);
    }, 200);
  }

  $('.nav-menu-icon').click(function(e) {
    $(this).toggleClass('active');
    $('.main-navigation').toggleClass('active');
    if ($('.js-sticky').length) {
      $stickyElement.toggleClass('sticky-menu').toggleClass('sticky-menu--active');
      $('body').toggleClass('no-scroll');
    }
  });

  // sticky menu
  $window.on('resize', function() {
    if ($('.js-sticky').length) {
      stickyHeight = $stickyElement.height();
      $stickyContainer = $('.sticky-container').height(stickyHeight + 1);
      setWindowWidth();
    }
  });

  $window.on('scroll', function() {
    if ($('.js-sticky').length) {
      $stickyElement = $('.js-sticky');
      if ($(this).scrollTop() >= stickyTopOffset) {
        $stickyElement.addClass('sticky-menu').addClass('scrolling');
      } else {
        $stickyElement.removeClass('sticky-menu').removeClass('scrolling');
      }
    }
  });

  // add button to open submenu

  $('.menu-item-has-children > a').append('<span class="icon-left-open-3 toggle-menu-item"></span>');

  $('.toggle-menu-item').on('click', function(e) {
    e.preventDefault();
    var $menuItem = $(this).closest('.menu-item-has-children');

    if ($menuItem.hasClass('menu-item--active')) {
      $menuItem.removeClass('menu-item--active').children('.sub-menu, .mega-sub-menu').slideUp();
    } else {
      $menuItem.addClass('menu-item--active').children('.sub-menu, .mega-sub-menu').slideDown();
    }
  });

  // $(".menu-item:not(.mega-menu-item)").hover(
  $(".main-menu").on('mouseover', '.menu-item:not(.mega-menu-item)', function() {
    if ($windowWidth >= 1024) {
      clearTimeout($.data(this, 'timer'));
      $(this).children('.sub-menu, .mega-sub-menu').stop(true, true).slideDown(200);
    }
  });
  $(".main-menu").on('mouseout', '.menu-item:not(.mega-menu-item)', function() {
    if ($windowWidth >= 1024) {
      $.data(this, 'timer', setTimeout($.proxy(function() {
        $(this).children('.sub-menu, .mega-sub-menu').stop(true, true).slideUp(200);
      },this), 200));
    }
  });

  /*-------------------*/
  /* ISOTOPE PORTFOLIO */
  /*-------------------*/
  var $grid = $('.isotope-container').isotope({
    itemSelector: '.gallery-item',
    percentPosition: true,
    masonry: {
      columnWidth: '.grid-sizer',
      gutter: '.gutter-sizer'
    }
  });

  $grid.imagesLoaded().progress( function() {
    $grid.isotope('layout');
  });

  $('.filter-wrap').on( 'click', 'button', function() {
    $(this).siblings().removeClass('active');
    $(this).addClass('active');
    var $thisIsotope = $(this).parent().siblings('.isotope-container');
    var filterValue = $(this).attr('data-filter');
    $thisIsotope.isotope({ filter: filterValue });
  });

  /*--------------*/
  /* VIDEO BANNER */
  /*--------------*/
  $('.video-banner').each(function(){
    var videoWrap = $(this),
    videoPopUp = videoWrap.find('.video-popup'),
    buttonPlay = videoWrap.find('.play-btn'),
    videoIframe = videoPopUp.find('iframe'),
    iframeSrc = videoIframe.attr('src'),
    iframeDataSrc = videoIframe.attr('data-src'),
    closePlayButton = videoPopUp.find('.close-btn');
    
    videoWrap.closest('.wpb_wrapper').css('height', '100%');

    buttonPlay.on('click', function(e){
      e.preventDefault();
      videoPopUp.addClass('active');
      videoIframe.attr('src', iframeDataSrc);
    })

    closePlayButton.on('click', function(){
      videoPopUp.removeClass('active');
      videoIframe.attr('src', iframeSrc);
    });
  });

  /*------------*/
  /* GOOGLE MAP */
  /*------------*/
  function initMap(element, locations) {
    if ( locations.length ) {
      var myLatLng = {lat: locations[0].lat, lng: locations[0].lng};

      var map = new google.maps.Map(element, {
        zoom: parseInt( $(element).attr('data-zoom') ),
        center: myLatLng,
        mapTypeId: $(element).attr('data-map_type'),
        draggable: $(element).attr('data-draggable') == 'show' ? true : false,
        scrollwheel: $(element).attr('data-enable_scroll') == 'show' ? true : false,
      });

      var marker;

      var contentString = $(element).attr('data-content');

      if ( $(element).attr('data-popup') == 'show' ) {
        marker = new google.maps.Marker({
          position: myLatLng,
          map: map
        });

        if ( contentString !== undefined ) {
          
          var infowindow = new google.maps.InfoWindow({
                content: contentString
              });

              marker.addListener('click', function() {
                infowindow.open(map, marker);
              });
        }
      }
    }

  }

  if ( $('div').is('.single-location__map') ) {

    var locations = [];
    $('.single-location__map').each(function(){
      var $this = $(this),
        address = $(this).attr('data-address');
      if ( $this.attr('data-location') == 'coordinates' ) {
        locations.push({
          'lng': parseFloat( $this.attr('data-lng') ),
          'lat': parseFloat( $this.attr('data-lat') )
        });
      } else {

        var coordinatesRequest = 'http://maps.google.com/maps/api/geocode/json?address=' + address.replace(/\s/ig, '+') + '&sensor=false';
        $.ajax({
          async: false,
          url: coordinatesRequest,
          dataType: "json",
          success: function(data) {
            console.log(data);
            if ( data.status != 'ZERO_RESULTS' ) {
              locations.push(data.results[0].geometry.location);
            }
            // console.log(data.results[0].geometry.location);
          },
        });
      }
      initMap(this, locations);
    });
  }

  $( ".gallery-container" ).last().addClass( "last-child" );

  /*---------------*/
  /* POPUP GALLERY */
  /*---------------*/
  $('.isotope-container').each(function() { // the containers for all your galleries
    $(this).magnificPopup({
      delegate: '.gallery-item a',
      type: 'image',
      gallery: {
        enabled: true
      },
      mainClass: 'mfp-fade',
      fixedContentPos: false
    });
  });

  /*---------------*/
  /* POST LIKES    */
  /*---------------*/
  $('.post__likes').on('click', function() {
    var $this = $(this),
      post_id = $this.attr('data-id');

    $.ajax({
      type: "POST",
      url: js_data.ajaxurl,
      data: ({
        action: 'lawyer_like_post',
        post_id: post_id
      }),
      success: function(msg) {
        $this.find('.count').text(msg);
      }
    });
    return false;
  });


  /*-----------------------------------------*/
  /* fitVids - responsive video in blog post */
  /*-----------------------------------------*/
  if ( $('body').hasClass( 'single' ) ) {
    $(".post__content.single-content").fitVids();
  }

})(jQuery, window, document);
