jQuery(document).ready(function ($) {
	 var pageURL = $(location).attr("href");
   if(pageURL == 'https://www.lawtendo.com/Navigation/Findalawyer'){
		var state_t = $('#state :selected').text()+"/";
		var state_text = state_t.replace(/\s+/g, '-');
		var city_t  = ($('#city :selected').text()=="City") ? "" : $('#city :selected').text()+"/";
		var city_text  = city_t.replace(/\s+/g, '-');
		
		var court_t = ($('#court :selected').text()=="Court") ? "" : $('#court :selected').text()+"/";
		var court_text = court_t.replace(/\s+/g, '-');
		
		var practice_t = ($('#practice :selected').text()=="Practice Area") ? "" : $('#practice :selected').text()+"/";
		var practice_text = practice_t.replace(/\s+/g, '-');
		
		var experience_t = ($('#experience :selected').text()=="Exp") ? "" : $('#experience :selected').text()+"/";
		var experience_text = experience_t.replace(/\s+/g, '-');
		window.history.pushState("", "", "/find-lawyer/"+state_text+city_text+court_text+practice_text+experience_text);
	 }

/*-------------------Load predefined functions-----------------*/	
/*------------------- Filter Function--------------------*/
	filter_results();
	$('.form_home').submit(function(event) {
		event.preventDefault();
	});
	$('.filter-field').on("change", function(event) {	
		urlchange();
	});
	$('.reset-filter').on("click", function(event) {
		window.history.pushState("", "", "/find-lawyer/State");
	});
	$('.form_home .gc-filter-btn.reset-filter').on("click", function(event) {	
		document.getElementById("form_home").reset();
		filter_results();
		event.preventDefault();
	});		
	
	$('#lawyerfilter').on("click", function(event) {	
		filter_results();
		event.preventDefault();
	});		
});
/*-------------------------- Filter Results -----------------------------*/
function filter_results() {
	var value = $('.form_home').serialize();
	$.ajax({
			type: "POST",
			url: base_url+"Navigation/filterlawyer",
			data: value,				
			success: function(data) {
				data = JSON.parse(data);
				if(data['total'] == 0) {						
					$(".gc-settings-btn-bay.load-more-button").hide();
				}
				else{													
					$('html, body').animate({scrollTop:$('.gc-hw-it.align-left').offset(),top}, 'slow');					
					if(data['total'] >= 4) {	
						$(".gc-settings-btn-bay.load-more-button").show();
						$('.morebox').show();
						$('.morebox').attr('id','more'+data['last_id']);
						$('.filterloadmore').attr('id',data['last_id']);
					} else {
						$(".gc-settings-btn-bay.load-more-button").hide();
					}					
				}
				$('.gc-filter-list ul').html(data['temp']);
			},
			error: function(data) {				                 
				var error = '<div class="message"><div class="error"><h1>Sorry, No records found.  </h1></div></div>';
				$('.gc-filter-list ul').html(error);
				$('html, body').animate({scrollTop:$('.gc-hw-it.align-left').offset().top}, 'slow');
			}
	});
}
/*--------------------- End Filter Results--------------------- */

/* List Lawyer locality Based */
function list_lawyer_locality() {
	var city = $('#city').val();
	$.ajax({
			type: "POST",
			url: base_url+"Navigation/locality",
			data: city,				
			success: function(data) {
				data = JSON.parse(data);
				if(data['total'] == 0) {						
					$(".gc-settings-btn-bay.load-more-button").hide();
				}
				else{													
					$('html, body').animate({scrollTop:$('.gc-hw-it.align-left').offset(),top}, 'slow');					
					if(data['total'] >= 4) {	
						$(".gc-settings-btn-bay.load-more-button").show();
						$('.morebox').show();
						$('.morebox').attr('id','more'+data['last_id']);
						$('.filterloadmore').attr('id',data['last_id']);
					} else {
						$(".gc-settings-btn-bay.load-more-button").hide();
					}					
				}
				$('.gc-filter-list ul').html(data['temp']);
			},
			error: function(data) {				                 
				var error = '<div class="message"><div class="error"><h1>Sorry, No records found.  </h1></div></div>';
				$('.gc-filter-list ul').html(error);
				$('html, body').animate({scrollTop:$('.gc-hw-it.align-left').offset().top}, 'slow');
			}
	});
}

	function urlchange() {
		event.preventDefault();
		var result = "/find-lawyer/";
		window.history.pushState("", "", result);
		var state_t = $('#state :selected').text()+"/";
		var state_text = state_t.replace(/\s+/g, '-');
		if(state_text != ''){
			result = result + state_text ;
		}
		
		var city_t  = ($('#city :selected').text()=="City") ? "" : $('#city :selected').text()+"/";
		var city_text  = city_t.replace(/\s+/g, '-');
		if(city_text != ''){
			result = result + city_text ;
		}
		console.log(city_text);
		
		var court_t = ($('#court :selected').text()=="Court") ? "" : $('#court :selected').text()+"/";
		var court_text = court_t.replace(/\s+/g, '-');
		if(court_text != ''){
			result = result + court_text ;
		}
		
		var practice_t = ($('#practice :selected').text()=="Practice Area") ? "" : $('#practice :selected').text()+"/";
		var practice_text = practice_t.replace(/\s+/g, '-');
		if(practice_text != ''){
			result = result + practice_text ;
		}
		
		var experience_t = ($('#experience :selected').text()=="Exp") ? "" : $('#experience :selected').text()+"/";
		var experience_text = experience_t.replace(/\s+/g, '-');
		if(experience_text != ''){
			result = result + experience_text ;
		}
		
		filter_results();
		
		window.history.pushState("", "", result);
	}