<?php include 'include/header.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
<style>
    
.container h3 {
    display: inline-block;
    position: relative;
    /*margin-left: 10px;*/
    margin-top:4px
 
}
.container h3:after {
    content: '';
    display: block;
     margin-top: 4px;
    height: 2px;
    width: 0px;
    background: transparent;
    transition: width .7s ease, background-color .7s ease;
    
}
.container h3:hover:after {
    width: 100%;
     background: -webkit-gradient(linear, 99% 0%, 0% 100%, from(#cc2a2e03), to(#cc2a2e));
} 


#med{
    
    word-spacing:5px;
     text-transform: uppercase; 
     letter-spacing:3px;
     font-family:bold;
     text-align:center;
     
}



@media screen and (max-width: 1000px) {
  #med{
    margin-left: 0px;
    
    font-family:serif;
    
  }
}


body{
    margin:0;
    padding:0;
}


#ff{
    font-family:serif;
    /*text-align:center;*/
}

.slideanim {visibility:hidden;}


 .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    }
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    }
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }


</style>

</head>
<body>
   

    <a href="index.php" class="b-breadcrumbs__link"><b>Home</b></a>
    <span class="b-breadcrumbs__link"><b >Our Services</b></span>
    <span class=""><b>Translation</b></span>

<div class="Container-fluid" >
				
					<img src="img/bigimg.jpg" style="width:100%;" >
				    
				</div>
				
				 <div class="container slideanim">
                   
          <hr>  <h2 id="med"  class=" title-heding ">Translation</h2><hr>
<h3 style="color:#b1001e">Seamless Transition from one language to another</h3>
<p id="ff" class=" slideanim">Being a Market Research company we have natives as translators because we understand for multi-language surveys it is very important that the sense of the questionnaire is not lost while translation.</p>
<p id="ff">While conducting research in different countries it is imperative that the research carries the same meaning and impact in each language.There is where our native translators fill the gap. They help in translations without losing the impact. </p>
<p id="ff"> Our capabilities specific to market research translation are:</p>
<ul>
<li>  Questionnaires both Online and offline</li>
<li>  Telephonic interview</li>
<li>  Open-ended responses</li>
<li>  Research Briefings</li>
<li>  Telephone scripts</li>
<li>  Technical Surveys</li>

</ul>
</div>
				
				
				<div class="clearfix"></div>
<script>
$(document).ready(function(){
    $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>
<?php include 'include/footer.php'; ?>
</body>
</html>