<?php include_once 'include/header.php'; ?>
<section class="inner-banner" style="margin-top: 65px;">
<div class="container text-center">
<h2><span>Our Profile</span></h2>

</div>
</section>
<section class="faq-wrapper">
<div class="container">

<div class="row">

<div class="col-lg-12 col-md-12">
<div class="accrodion-grps" >
<div class="accrodion ">
</div>
<div class="accrodion ">
<div class="accrodion-title">
<h4>Why Adrenture</h4>
</div>
<div class="accrodion-content">
<p>Adrenture, caters to luxury travel in South Asia, including India. Our talent lies in making Tours, trips or holidays in India; educational and fun. Our strength lies in our knowledge, our love of the destination and our passion for travel. Japmeet Holidays offers the perfect blend of comfort and luxury in the true spirit of travel – learning and sharing experiences. Accommodation is arranged at a blend of unique boutique, luxury, heritage and contemporary hotels. They have all been personally recommended by our quality control team and have been carefully selected, not just for the quality of services offered but the quality of experience. Some itineraries take you away from the well-trodden tourist track and luxury accommodation. But, whether they are camps or small hotels, your comfort is always our priority. </p>
</div>
</div>

<div class="accrodion">
<div class="accrodion-title">
<h4>Adrenture Proprietor</h4>
</div>
<div class="accrodion-content">
<p>With span of 17 years working experience in travel Industry & having depth knowledge of handling Foreign Individuals, Groups, Incentives, Charters and Leisure markets. He has extensively traveled to India which has given him a first hand experience and knowledge of the destinations & also traveled to Malaysia, Singapore, Thailand, Australia & Europe.
</p>
</div>
</div>
<div class="accrodion">
<div class="accrodion-title">
<h4>Recognition</h4>
</div>
<div class="accrodion-content">
<p>We are member of the following trade bodies :<br>
Applied For Member of the Indian Association of Tour Operators ( IATO )
Thank you for taking the time to look around our web site, and we look forward to providing you with a very memorable holiday.


</p>
</div>
<div class="accrodion">
<div class="accrodion-title">
<h4>Incoming Tours</h4>
</div>
<div class="accrodion-content">
<p>As one of the leading operators, Adrenture India offers host of travel services to the foreign tourists visiting India.</p>
<p>Our itineraries combine history, culture, opportunities for social interaction, leisure time that allows you to explore on your own. They are creative and comprehensive, and have been specially designed to bring you a complete experience. Most tours have options and extensions that can be added on. Moreover any number of tours can be combined to suit your particular requirement and if you tell us your special interests we will make sure your itinerary accommodates them. Direct fax, e-mail and internet links with all its Indian & overseas associates also help us to maintain a rapid two-way communication, very essential in the travel industry. </p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>




<?php include_once 'include/footer.php'; ?>