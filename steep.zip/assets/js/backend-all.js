$(function(){
	 $('.show-ratingreview').on("click", function(){   
	var lawyermainid = $(this).attr("data-id");
	//alert (lawyermainid);
	$("#rateit").modal({show:true});	
	$("#finder-for-lawyer").val(lawyermainid);
	//$("p").append(" <b>Appended text</b>.");
	
	
	//alert var lawyermainid ;
});	
});	 