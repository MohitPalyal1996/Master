<?php 

if(isset($_POST['submit'])||empty($_POST))
{
	
	$captcha=$_POST['g-recaptcha-response'];
	$secret="6LeFZE4UAAAAALGvOgEFY7DiOFHL8xcUPOeQFX_2";
	
	$action= file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$captcha");
	$result= json_decode($action, TRUE);

	if($result['success'])
	{
		if($_POST){
		$name=$_POST['name'];
$email=$_POST['email'];
$mobile=$_POST['mob'];
$country=$_POST['country'];
$state=$_POST['state'];
$city=$_POST['city'];
$datea=$_POST['datea'];
$dated=$_POST['dated'];
$adult=$_POST['adult'];
$child=$_POST['child'];
$acc=$_POST['acc'];	
$msg=$_POST['comment'];	

$mailto= "mikeymohit@gmail.com";
//  $mailto= "Sikhtours@gmail.com";  
$subject = "Adrenture";

$from= $email;          //Your valid email address here

$message_body ="
<table border='1'>
	<caption>Adrenture Tour Contact Form</caption>
	<thead>
		<tr>
			<th>Name</th>
			<th>Mobile Number</th>
			<th>Country</th>
			<th>State</th>
			<th>City</th>
			<th>Date of Arrival</th>
			<th>Date of Departure</th>
			<th>Person(Adult)</th>
			<th>Person(Child)</th>
			<th>Accommodation</th>
			<th>Message</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>".$name."</td>
			<td>".$mobile."</td>
			<td>".$country."</td>
			<td>".$state."</td>
			<td>".$city."</td>
			<td>".$datea."</td>
			<td>".$dated."</td>
			<td>".$adult."</td>
			<td>".$child."</td>
			<td>".$acc."</td>
			<td>".$msg."</td>
		</tr>
	</tbody>
</table>
";

$headers = "From: " . $from . "\r\n";
$headers .= 'Bcc: mikeymohit@gmail.com' . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
if(mail($mailto,$subject,$message_body,$headers))
{
//header('location:booknow.php'); 
echo '<div class="col-xs-12 col-sm-8">
		<h1 class="site-header_title" >THANK YOU !</h1>
		<p class="para">Your submision is recieved and we will contact you soon.</p>
    
	</div>';

}else{
echo "Something wrong";
}
}

	}else
	{
		header('Location:booknow.php');
	}

}


 ?>
 
 <style type="text/css" media="screen">
.site-header_title{
    font-size: 3em;
    color:rgb(70,92,152);
    font-weight: 600;
}
	.para{
	line-height: 1.5em;
	letter-spacing: 2px;
	font-size: 1.5em;
	font-weight: 500;
}
</style>