<?php include 'include/header.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    
    <style>
       
       #det{
    margin-right:400px;
    
    
}
@media screen and (max-width: 360px) {
  #det{
    margin-right:0px;
    margin-top:5px;
   
   

  }
}
@media screen and (max-width: 780px) {
  #det{
    
    margin-top:7px;
   margin-right:10px;
   

  }
}
       
       .half-map{
    /*height: 360px;*/
    /*width: 100%;*/
    overflow: hidden;
}



    @media screen and (max-width: 360px) {
  .half-map{
   width: 358px;
 
   
   

  }
}
@media screen and (max-width: 980px) {
  .half-map{
   
   margin-top:15px;
   
   

  }
}
       
        .mgl{
            margin-left:5px;
        }
       

        
   @media screen and (max-width: 980px) {
  .mgl{
margin-left: -28px;
}
}

#mtop{
    margin-top:-45px;
}

 @media screen and (max-width: 450px) {
  #mtop{
margin-top: -24px;
}
}

body{
    margin:0;
    padding:0;
}

/*.title-heding{*/
/*    font-family:bold;*/
/*}*/

/*@media and screen(max-width: 400px){*/
/*    .title-heding{*/
/*        font-family:serif;*/
        
/*    }*/
/*}*/




.slideanim {visibility:hidden;}


 .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    }
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    }
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }





   </style>
</head>
<body>
 
		<section style="overflow: hidden; width=100% ">
			
					<img src="img/contact.jpg" alt="dfw" style="overflow: hidden; width=100% ">
		
			</section>
			<div class="container slideanim" id="mtop" style="">
		
			<h2 class="text-center title-heding" style="letter-spacing:2px;">Contact Us</h2><hr>
			<div class="col-md-12 mgl">

				<div class="col-md-4">
					<h3 ><strong><i class="fa fa-building" aria-hidden="true"></i> India </strong></h3>
					<h2 style="color:#b1001e">STEEPBRAIN</h2>
					<p><strong style="color:black">Address :</strong> C-404,Saffron Block,Niho Scottish Garden, Ahinsa Khand-11, Indirapuram, Ghaziabad(U.P) Uttar Pradesh,India</p>
			<p>	<strong style="color:black">Pincode :</strong>	Ghaziabad 201014</p>
			
					<p ><i style="color:#b1001e" class="fa fa-envelope" ></i> Mail : info@steepbrain.com  </p>
					<i class="icon-phone-3"></i><span><span style="color:red;"> Consultation</span> <a href="tel:01207961544" style="color:black;"> : 01207961544 |</a> </span></li> 
 <i style="color:green;"  class="fa fa-whatsapp" aria-hidden="true">  WhatsApp :  
 <a style="color:black;" class="whatsapp-text-hvr" href="https://wa.me/9999164802">  9999164802</a></i>
				
			</div>
		
			<div  id="map" class="half-map" >
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.547006505413!2d77.38049581418859!3d28.643335782413512!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cf1c5d3bd59c9%3A0xf6dd495a69c98c4f!2sSteepBrain%20Research%20%26%20Consultancy!5e0!3m2!1sen!2sin!4v1600936758442!5m2!1sen!2sin" width="810" height="360" frameborder="0" style="border:0;" allowfullscreen=""></iframe>

                    </div>
				
			</div>
			<div class="clearfix"></div>
				<br>
			<hr style="border:1px solid black;">
<div class="container-fluid">
            <!--Heading-->
            <div class="row">
                <div class="col-lg-12 ">
                    <div class="title d-inline-block">
                        
                        <h2 class="text-center title-heding " style="letter-spacing:1px;color:#b1001e">Let's Get In Touch</h2>
                    </div>
                </div>
            </div>

            <!--contact us-->
            
            <form  action="contact.php" method="post" onsubmit="return validation()">
                <div class="row">

                    <!--<div class="col-sm-12" id="result"></div>-->

                    <div class="col-md-6">
                        <div class="form-group">
                            <label><h3>First Name</h3></label>
                          <input type="text" placeholder="Enter Firstname" name="fname" id="firstname" class="form-control" required>
                <span id="firstnameerror" class="text-danger font-weight-bold"></span>
            </div>
                        </div>
                   
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><h3>Last Name</h3></label>
    <input type="text" placeholder="Enter Lastname" name="lname" id="lastname" class="form-control" required>
                <span id="lastnameerror" class="text-danger font-weight-bold"></span>
            </div>
                        </div>
                    
                    <div class="col-md-6 ">
                        <div class="form-group">
                             <label><h3>Email</h3></label>
                          <input type="text" placeholder="Enter Email" name="email" id="eMAIL" class="form-control" required>
                <span id="emailerror" class="text-danger font-weight-bold"></span>
                        </div>
                    </div>
                    <div class="col-md-6 ">
                        <div class="form-group">
                             <label><h3> Mobile No.</h3></label>
    <input type="text" placeholder="Enter MobileNo" name="MobileNo" id="mob" class="form-control" required >
                <span id="mobileerror" class="text-danger font-weight-bold"></span>
                        </div>
                    </div>
                    <div class="col-md-12 ">
                        <div class="form-group">
                            <label><h3>Your Query</h3></label>
        <textarea class="form-control" placeholder="message" id="message" name="message1"  required></textarea>
                        </div>
                    </div>
                    <div class="col-md-12" >
                        <!-- <button type="submit" class="btn btn-large btn-gradient btn-rounded mt-4" id="submit_btn"><i class="fa fa-spinner fa-spin mr-2 d-none" aria-hidden="true"></i> <span>Contact Now</span></button> -->
                        <input type="Submit" name="Submit" class="btn btn-primary">
                        
                    </div>
                </div>
            </form>
        </div>
        
        <script type="text/javascript">
    function validation(){

    var firstname = document.getElementById('firstname').value;
     var lastname = document.getElementById('lastname').value;
    // var password = document.getElementById('password').value;
    // var cONFIRMpASSWORD = document.getElementById('cONFIRMpASSWORD').value;
    var eMAIL = document.getElementById('eMAIL').value;
    var mob = document.getElementById('mob').value;

    var firstuser = /^[A-Za-z. ]{3,14}$/ ;
    // var lastuser = /^[A-Za-z. ]{3,14}$/ ;
// var passcheck = /^(?=.*[0-9])(?=.*[!@#$%^*])[a-zA-Z0-9!@#$%^&*]{8,15}$/;
var emailcheck = /^[A-Za-z_.]{3,15}@[A-Za-z]{3,}[.]{1}[A-Za-z.]{2,6}$/;
var mobilecheck = /^[6789][0-9]{9}$/;

if(firstuser.test(firstname)){
    document.getElementById('firstnameerror').innerHTML = " ";
}else{
    document.getElementById('firstnameerror').innerHTML ="**firstnameerror is NOT right";
    return false;
}

if(lastuser.test(lastname)){
    document.getElementById('firstnameerror').innerHTML = " ";
}else{
    document.getElementById('lastnameerror').innerHTML ="**lastnameerror is NOT right";
    return false;
}

 if (emailcheck.test(eMAIL)){
    document.getElementById('emailerror').innerHTML =" ";
}else{
    document.getElementById('emailerror').innerHTML ="**Email is NOT Correct";
    return false;
    
}
if (mobilecheck.test(mob)){
    document.getElementById('mobileerror').innerHTML =" ";
}else{
    document.getElementById('mobileerror').innerHTML ="**MOBILE-NUMBER is NOT Correct";
    return false;
}
}
</script>

       
<?php


date_default_timezone_set('Asia/Kolkata');
$date_added=date("Y-m-d");
$date_time_added=date("Y-m-d H:i:s");



if(isset($_POST['Submit']))
{


$firstname=$_POST['fname'];
$lastname=$_POST['lname'];
$MobileNo=$_POST['MobileNo'];
$email=$_POST['email'];
$message1=$_POST['message1'];

$touser  = $email; // note the comma
$subject = "Acknowledgment of your Query- " . $date_time_added;

// $subject = "Acknowledgment of your  Query ";
// $query="INSERT INTO `contact_detail`(`name`, `email`, `contact`, `message`, `date_added`, `date_time_added`, `status`) VALUES ('$post_contact_name','$post_contact_email','$post_contact_phone','$post_contact_comments','$date_added','$date_time_added','$status')";
// $crud->execute($query); 

$message = '<html>
					<head>
						<style>
							@media screen and (max-width:550px){
								.exam-detail-wrap-mailer-right{ width:100% !important; }
							}
							@media screen and (max-width:400px){
								.logo-wrap{ width:100% !important; }
								.social-wrap{ width:100% !important; }
								.social-wrap img{ width:30px !important; float:left !important; margin-top:10px; margin-bottom:10px; }
								.social-wrap img:first-child{ margin-left:30%; }
							}
							.exam-detail-wrap-mailer:last-child{ border-bottom:0px solid #ffffff !important; }
							
						</style>
					</head>
					<body style="margin:0; padding:0;">

						<div style="width:90%; margin-left:5%; margin-top:20px;">
							<div style="background:#e5e5e5; float:left; width:90%; padding:10px 5%; border:1px solid #e5e5e5;">
								<h5> STEEPBRAIN <h5>
								
							</div><br/><br/><div style="width:100%; margin-left:0%;">
							<div style="width:100%;border: 1px solid rgba(51, 51, 51, 0.16);">
							<div style="background:#005387; float:left; width:100%;">
							
							</div>
							<div style="clear:both;"></div>
							<div style="background:#f9f9f9; padding:20px 5%; border-bottom:1px solid #9a9a9a;">
		<h2> Dear <span style="color:#017fb9;"> '.$firstname.'&nbsp;' .$lastname.' </span> </h2>
							<table>
							
							</tr>
										
							<br>
				            <tr><td><p> <b>Thank you for showing Interest in STEEPBRAIN, We will contact you soon.</b></p></td></tr>
							</table>
							
						   </div>
						  </div>
						 </div>
						 <div style="background:#e5e5e5; float:left; width:90%; padding:10px 5%; border:1px solid #e5e5e5;">
								<p style="margin:0; text-align:right; font-family:arial; font-size:12px;"> Copyright &copy; 2020 | Powered by <a style="color:#c1272d; text-decoration:none;" href="http://SteepBrain.com" target="_blank">SteepBrain.com </a></p>
							</div>
						</div>
					</body>
				</html>';
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers .= 'From: SteepBrain <info@steepbrain.com>' . "\r\n";
				mail($touser, $subject, $message, $headers);

        
        // mail to admin using SMTP
				
	$toadmin="info@steepbrain.com";
        
        $from = "info@steepbrain.com";
        // $subject = "A New Package Inquiry Received - " . $date_time_added;
        $subject = "A New  Inquiry Received ";
		
		$message = '<html>
					<head>
						<style>
							@media screen and (max-width:550px){
								.exam-detail-wrap-mailer-right{ width:100% !important; }
							}
							@media screen and (max-width:400px){
								.logo-wrap{ width:100% !important; }
								.social-wrap{ width:100% !important; }
								.social-wrap img{ width:30px !important; float:left !important; margin-top:10px; margin-bottom:10px; }
								.social-wrap img:first-child{ margin-left:30%; }
							}
							.exam-detail-wrap-mailer:last-child{ border-bottom:0px solid #ffffff !important; }
							
						</style>
					</head>
					<body style="margin:0; padding:0;">

						<div style="width:90%; margin-left:5%; margin-top:20px;">
							<div style="background:#e5e5e5; float:left; width:90%; padding:10px 5%; border:1px solid #e5e5e5;">
								<h5> SteepBrain <h5>
								
							</div><br/><br/><div style="width:100%; margin-left:0%;">
							<div style="width:100%;border: 1px solid rgba(51, 51, 51, 0.16);">
							<div style="background:#005387; float:left; width:100%;">
							
							</div>
							<div style="clear:both;"></div>
							<div style="background:#f9f9f9; padding:20px 5%; border-bottom:1px solid #9a9a9a;">
							<h3> Dear admin, A New Query Received<span style="color:#017fb9;"></span> </h3>
							
							<p><b>first Name: </b>'.$firstname.'</p>
							<p><b>last Name: </b>'.$lastname.'</p>
							<p><b>User Email: </b>'.$email.'</p>
							<p><b>User Contact: </b>'.$MobileNo.'</p>
							<p><b>User Message: </b>'.$message1.'</p>
							<p><b>Date Contacted: </b>'.$date_time_added.'</p>
                            
							<table>
				            <tr><td><p>A new Applicant contacted you. Thanks.</p></td></tr>
							</table>
						   </div>
						  </div>
						 </div>
						 <div style="background:#e5e5e5; float:left; width:90%; padding:10px 5%; border:1px solid #e5e5e5;">
								<p style="margin:0; text-align:right; font-family:arial; font-size:12px;"> Copyright &copy; 2020 | Powered by <a style="color:#c1272d; text-decoration:none;" href="http://SteepBrain.com" target="_blank">SteepBrain.com </a></p>
							</div>
						</div>
					</body>
				</html>';
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers .= 'From: STEEPBRAIN <info@steepbrain.com>' . "\r\n";
				$result=mail($toadmin, $subject, $message, $headers);
			if($result) 
			{
			$completeurl=$_SERVER['HTTP_REFERER'];			
			$_SESSION['success_msg']="Your query sent successfully, We will contact you soon.";
			echo "<script>window.location='".$completeurl."';</script>";
			}
}













// if (isset($_POST['submit'])) 
// {
  
// $firstname=$_POST['fname'];
// $lasttname=$_POST['lname'];
// $MobileNo=$_POST['MobileNo'];
// $email=$_POST['email'];
// $message=$_POST['message'];

// $password=$_POST['password'];

// $con=mysqli_connect('localhost','root','','decisive_online');
// $query="insert into decisive_online_table (First_name,Last_name,Mobile_number,Email,Message) values ('$firstname','$lasttname',$MobileNo,'$email','$message')";

// $run=mysqli_query($con,$query);
// if($run)
// {

// echo "<h3>Thank you for contacting us</h3>";
// }

//   else
//   {
//     echo "error".mysqli_error($connect);
//   }
// }
  
 ?>


			</div>
			
	<br>

				<div class="clearfix"></div>

<!-- FOOTER -->
<footer class="main-footer dark-section ">

<!-- Footer sidebar -->
<div class="row">
<div class="columns small-12">
<div class="row align-justify align-middle logo-socials-footer small-collapse">
<div class="columns small-12 medium-expand">
<!-- Footer logo -->
<div class="logo">
<a href="#">
<img src="img/logoi.png" >
</a>
</div>
</div>
	

    <span id="det">Copyright © 2020 Decisive Online</span>

<div class="columns small-12 shrink">
<!-- Footer socials -->
<div class="socials">
<a href="#"><i class="icon-twitter"></i></a>
<a href="#"><i class="fa fa-facebook"></i></a>
<a href="#"><i class="icon-rss-1"></i></a>
<a href="#"><i class="icon-linkedin"></i></a>
<a href="#"><i class="icon-pinterest-4"></i></a>
<a href="#"><i class="icon-gplus-1"></i></a>
<a href="#"><i class="icon-instagram"></i></a>
</div>
</div>
</div>
</div>
</div>

</footer>
	<script>
$(document).ready(function(){
    $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>			
</body>
</html>