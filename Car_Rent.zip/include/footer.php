<footer class="footer">
		<div class="container">
			<div class="row">
				
				
				<div class="col-md-4 col-sm-6">
					<div class="footer-widget post-widget">
						<div class="title">
							<h2><span>Important links</span></h2>
						</div>
						<ul>
							<li><a href="index.php"><i class="fa fa-angle-right"></i>Home</a></li>
							<!-- <li><a href="testimonial.php"><i class="fa fa-angle-right"></i>Testimonial Page</a></li> -->
							<li><a href="services.php"><i class="fa fa-angle-right"></i>Profile</a></li>						
							<li><a href="terms&condition.php"><i class="fa fa-angle-right"></i>Terms & Condition</a></li>
							<li><a href="policy.php"><i class="fa fa-angle-right"></i>Privacy Policy</a></li>
							<li><a href="contact.php"><i class="fa fa-angle-right"></i>Contact Us</a></li>
						</ul>
					</div>									
				</div>
				
				<div class="col-md-4 col-sm-6">
					<div class="footer-widget contact-widget">
						<div class="title">
							<h2><span>contact info</span></h2>
						</div>
						<ul class="contact-infos">
							<br>
							<li>
								<div class="icon-box">
									<i class="fa fa-map-marker"></i>
								</div>
								<div class="info-text">
									<p>SRM Chennai (India)</p>
								</div>
							</li>
							<li>
								<div class="icon-box">
									<i class="fa fa-phone"></i>
								</div>
								<div class="info-text">
									<p>Office nos : 91-123456,7890122</p>
								</div>
							</li>
							<li>
								<div class="icon-box">
									<i class="fa fa-phone"></i>
								</div>
								<div class="info-text">
									<p>24 hours Mobile : +91-1234567890 </p>
								</div>
							</li>
							<li>
								<div class="icon-box">
									<i class="fa fa-phone"></i>
								</div>
								<div class="info-text">
									<p>24 hours Mobile : +91-12121223455</p>
								</div>
							</li>
							<li>
								<div class="icon-box">
									<i class="fa fa-envelope"></i>
								</div>
								<div class="info-text">
									<p>E Mail : Adrenture@gmail.com, Adrenture@Info.com</p>
								</div>
							</li>
							<br>
						
							<a href="#" class="logotext">ADRENTURE</a>
						</ul>
					</div>
				</div>



				<!-- <div class="col-md-3 col-sm-6">
					<div class="footer-widget post-widget">
					<iframe src="//www.google.com/maps/embed/v1/place?q=Japmeet Holidays,
      					&zoom=17
      					&key=AIzaSyDW9N4qIukHL_RvEYiXTpdkO40KwZBX7nE">
 					 </iframe>
					</div>									
				</div> -->
					<div class="col-md-4 col-sm-6">
					<div class="footer-widget post-widget">
						<div class="title" >
							<h2><span>Quick Support</span></h2>
						</div>
						<br>
						<!-- <div class="col-md-4">
							<h5>India Tour</h5>
						</div>
						<div class="col-md-4"> 
							<img src="img/members/iato.jpg">
						</div>
						<div class="col-md-4">
							<img src="img/members/itta.jpg">
						</div>
						<div class="clearfix"></div><br> -->
						
						<div class="members" style="margin-top: 2%;">
							
							<div class="col-md-12" class="txt"> 
								<i class="fa fa-whatsapp fa-2x" style="color: white; "></i> <p style="color: white;     display: inline-block;
    vertical-align: super;
    padding-left: 10px;">+91-9988998899</p><br>
							</div>
							<div class="clearfix"></div>

							
							<div class="col-md-12" class="txt"> 
							<i class="fa fa-mobile fa-2x" style="color: white;    "></i>	<p style="color: white;  display: inline-block;
    vertical-align: super;
    padding-left: 10px;">+91-9999999999</p>
							</div>
							<div class="clearfix"></div>
							
							<div class="col-md-12" class="txt"> 
								<i class="fa fa-phone fa-2x" style="color: white; "></i> <p style="color: white;  display: inline-block;
    vertical-align: super;
    padding-left: 10px;">011-9988998/40</p>
							</div>
							<div class="clearfix"></div><br>
							<div class="col-md-4">
								<p style="color: white;"><span>Email:Adrenture@Info.com <br>Adrenture@Info.com</span></p>
							</div>
						</div>
						
					</div>									
				</div>

				<div class="clearfix"></div>



			</div>
		</div>
	</footer>

	<section class="bottom-bar">
		<div class="container">
			<div class="text pull-left">
			<div id="google_translate_element"></div>	</div>
			<div class="social pull-right">
				<ul class="list-inline">
					<li><a href="#"><i class="fa fa-facebook"></i></a></li>
					<li><a href="#"><i class="fa fa-twitter"></i></a></li>
					<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
					<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
					<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
					<li><a href="#"><i class="fa fa-instagram"></i></a></li>
				</ul>
			</div>
		</div>
	</section>




	<!-- Modal -->
	<div class="modal contact-page fade booking-form" id="booking-form" tabindex="-1" role="dialog" aria-labelledby="booking-form">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-body">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h3>Send message for Booking: </h3>
					<div class="container-fluid">
            <div class="row">
            <div class="col-lg-12" id="form-content">

            <form class="contact-form js-contact-form" method="POST" id="book"> 
            <fieldset>

            <div class="form-group col-md-4">
            <label >Name <sup>*</sup></label>
            <input type="text" class="form-control" id="name" name="name" required="" placeholder="Enter the Name">
            </div>
            <div class="form-group col-md-4">
            <label >Email-ID <sup>*</sup></label>
            <input type="email" class="form-control" id="email" name="email" required="" placeholder="Enter the Email">
            </div>
            <div class="form-group col-md-4">
            <label >Mobile <sup>*</sup></label>
            <input type="tel" class="form-control" id="mob" name="mob" required="" placeholder="Enter the Mobile No." pattern="[789][0-9]{9}" required="">
            </div>
            <div class="clear-fix"></div>
            <div class="form-group col-lg-4" reqired="">
            <label >Country <sup>*</sup></label>
            <select class="form-control" id="country" name="country" required="">
            </select>
            </div>

            <div class="form-group col-lg-4">
            <label >State <sup>*</sup></label>
            <select class="form-control" name="state" id="state" required="">
            </select>
            </div>

            <script language="javascript">
            populateCountries("country", "state");
            populateStates("state");
            </script>

            <div class="form-group col-md-4">
            <label >City <sup>*</sup></label>
            <input type="text" class="form-control" id="city" name="city" required="" placeholder="Enter the City" required="">
            </div>
            <div class="clear-fix"></div>

            <div class="form-group col-md-4">
            <label >Date of Arrival <sup>*</sup></label>
            <input placeholder="Date of Arrival" class="textbox-n form-control" type="text" onfocus="(this.type='date')"  id="datea" name="datea" required="">
            </div>
            <div class="form-group col-md-4">
            <label >Date of Departure <sup>*</sup></label>
            <input placeholder="Date of Departure" class="textbox-n form-control" type="text" onfocus="(this.type='date')"  id="dated" name="dated" required="">
            </div>

            <div class="form-group col-md-4">
            <label >Travel City : <sup>*</sup></label>
            <input type="text" class="form-control" id="city" name="city" placeholder="Enter the City" required="">
            </div>
            <div class="clear-fix"></div>

                <!-- <div class="form-group col-md-4">
                  <label>Children (5-12 Yr)</label>
                  <select class="form-control" id="child" name="child">
                    <option>Children</option>
                    <option>0</option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                  </select>
                </div> -->

            <div class="form-group col-md-4">
                  <label>The Fleet :<sup>*</sup> </label>
                  <select class="form-control" id="acc" name="acc" required="">
                    <option><b>--Select Vehicle--</b></option>
                    <option>Audi Q6</option>
                    <option>Audi Q7</option>
                    <option>Swift Dzire</option>
                    <option>Toyota Etios</option>
                    <option>Indigo</option>
                    <option>Honda City</option>
                    <option>Nissan Sunny</option>
                    <option>Honda Accord</option>
                    <option>Toyota Camry</option>
                    <option>Toyota Corolla</option>
                    <option>Toyota Corolla</option>
                    <option>MBMW5</option>
                    <option>Mercedes E 220</option>
                    <option>Mercedes S 350</option>
                    <option>Mercedes Viano</option>
                    <option>Toyota Innova</option>
                    <option>Toyota Parado</option>
                    <option>Toyota Fortuner</option>
                    <option>Nissan Urvan</option>
                    <option>Limousine</option>
                    <option>38 Seater Volvo with Washroom </option>
                    <option>44 Seater Volvo </option>
                    <option>Mitsubishi Rosa</option>
                    <option>Toyota Commuter</option>
                    <option>Toyota Coaster</option>
                    <option>Fiat Ducato</option>
                    <option>Volkswagen Crafter</option>
                    <option>Mercedes Coach</option>
                    <option>Tempo Traveller 9 Seater</option>
                    <option>Tempo Traveller 10 Seater</option>
                    <option>Tempo Traveller 11 Seater</option>
                    <option>Tempo Traveller 12 Seater</option>
                    <option>Tempo Traveller 13 Seater</option>
                    <option>Tempo Traveller 14 Seater</option>
                    <option>Tempo Traveller 15 Seater</option>
                    <option>Tempo Traveller 16 Seater</option>
                  </select>
                </div>

                <div class="form-group col-md-4">
            <label>Address <sup>*</sup></label>
            <!-- <input type="text" class="form-control" id="mob" name="add" required="" placeholder="Enter your Address" -->
            <textarea class="form-control" id="mob" name="add" required="" placeholder="Enter your Address"></textarea>
            </div>

            <div class="form-group col-md-4">
            <label>Other Requirement : </label>
            <textarea class="form-control" rows="4" id="comment" name="comment" placeholder="Additional Information" style="height: 71px;"></textarea>
            </div>



            <div class="form-group col-md-12">

            <button type="submit" name="submit" id="submit" class="btn btn-warning btn-lg" >Submit</button>
            </div>
            </fieldset>
            </form>
				</div>
			</div>
		</div>
	</div>
		
	


	<script src="assets/jquery/jquery-1.11.3.min.js"></script>
	<!-- <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha384-xBuQ/xzmlsLoJpyjoggmTEz8OWUFM0/RC5BsqQBDX2v5cMvDHcMakNTNrHIW2I5f" crossorigin="anonymous"></script>
 -->
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>

	<script src="http://maps.google.com/maps/api/js"></script>
	<script src="assets/gmap.js"></script>
	<script src="assets/validate.js"></script>

	<!-- Revolution slider JS -->
	<script src="assets/revolution/js/jquery.themepunch.tools.min.js"></script> 
	<script src="assets/revolution/js/jquery.themepunch.revolution.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.actions.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.migration.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.video.min.js"></script>

	<script src="assets/owl.carousel-2/owl.carousel.min.js"></script>

	<!-- jQuery ui js -->
	<script src="assets/jquery-ui-1.11.4/jquery-ui.js"></script>


	<!-- mixit up -->
	<script src="assets/jquery.mixitup.min.js"></script>
	<!-- fancy box -->
	<script src="assets/fancyapps-fancyBox/source/jquery.fancybox.pack.js"></script>



	<!-- custom.js -->

	<script src="js/map-script.js"></script>
	<script src="js/default-map-script.js"></script>
	<script src="js/custom.js"></script>
	<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
	<!-- <script src="js/loadMoreResults.js"></script> -->


</body>

<!-- Mirrored from world5.commonsupport.com/html/genurent/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 16 Feb 2018 15:01:37 GMT -->
</html>