<?php include_once 'include/header.php' ?>
<section class="inner-banner" style="margin-top: 65px;">
		<div class="container text-center">
			<h2><span>Testimonial Page</span></h2>
		</div>
	</section>

	<section class="testimonials section-padding testimonials-page">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
				<div class="single-testimonials">
				<p>“ Japmeet holidays I would love to congratulate you for making our tour such a amazing experience..you are also one of best price tour agent that I know off,japmeet holidays we like to thank you with the bottom of our hearts and you will always be in our mind when we plan our next holiday to india. cheers ! ”</p>
				<div class="box">
					<div class="img-box">
						<!-- <img src="img/user.png" alt="Awesome Image"/> -->
					</div>
					<div class="content text-center">
						<h3>Manjit Samra</h3>
						<p>- Malaysia</p>
						<p> 13 April 2016</p>
					</div>
				</div>
			</div>
				</div>
				<div class="col-md-12">
				<div class="single-testimonials">
				<p>“ We travelled with Japmeet Holidays to Patna sahib and Hazoor Sahib in March. The trip was very well organized and all transfers were smooth. We received a telephone call from Japmeet Travels to ensure we had reached our destination safely. Excellent service throughout the trip. We would definitely recommend to our friends and family. All drivers were very knowledgable and courteous, with clean cars. We also travelled to Agra with Japmeet Travels and again we received superb service. Thank you. ”</p>
				<div class="box">
					<div class="img-box">
						<!-- <img src="img/user.png" alt="Awesome Image"/> -->
					</div>
					<div class="content text-center">
						<h3>Mr and Mrs thandi</h3>
						<p>- Canada</p>
						<p> 13 April 2016</p>
					</div>
				</div>
			</div>
				</div>
				<div class="col-md-12">
				<div class="single-testimonials">
				<p>“ Recently wife and I used the services provided by Japmeet Holidays to visit sacred Five Takhat Sahib in India. I had searched out Japmeet Holidays from internet myself without any prior referral from any body. Frankly at first, I was a bit skeptical in dealing with anyone from India, especially on the internet! Only link I had was a fancy website of Japmeet Holidays. However from the beginning I was bit pleasantly surprised by the prompt response to my email inquiries. I was quite impressed by Surjeet’s professionalism and flexibility in designing tour package and quoting price for it. As for the tour itself, Japmeet Holidays and Surjeet Singh did not only deliver what was promised to us in the tour package but went way beyond. Both of us being senior citizens comfort and security was of paramount importance to us. Surjeet Singh personally made sure that we were comfortable and secure at each and every location. “Meet & Greet” service and personal tracking provided by Surjeet Singh is priceless! We were accommodated in five star hotels, where possible, and our rooms were clean and comfortable by any standards. Personal Taxi service arranged and provided by Japmeet Holidays was excellent. Air conditioned cars were clean and comfortable. Drivers were very polite, cordial, honest and helpful. All the time we felt as if we were in our own car in Canada. We had wonderful time during the entire tour. In our opinion overall cost was also reasonable. Every service provided was of excellent value for the money! On the scale of One to Ten, I would certainly rate it Ten Plus! I would definitely recommend it to all my friends and family as its one of the best tours in my life at a very reasonable price. Our only suggestion would be to add a “Rest Day” after each stopover and your tired feet would love it! ”</p>
				<div class="box">
					<div class="img-box">
						<!-- <img src="img/user.png" alt="Awesome Image"/> -->
					</div>
					<div class="content text-center">
						<h3>Tejinderpal Singh</h3>
						<p>- Canada</p>
						<p> 13 March 2016</p>
					</div>
				</div>
			</div>
				</div>
				<div class="col-md-12">
				<div class="single-testimonials">
				<p>“ As from my experience on a tour with Japmeet Tours to Hyderabad, we were given a very reasonable price to experience the places; Hyderabad to Nanak Jera to Hazur Sahib and Ramoji city and back to Hyderabad. The tour guy provided us with a friendly and good service. I would definitely recommend it to all my friends and family as its one of the best tours in my life at a very reasonable price. ”</p>
				<div class="box">
					<div class="img-box">
						<!-- <img src="img/user.png" alt="Awesome Image"/> -->
					</div>
					<div class="content text-center">
						<h3>Jess Chahal</h3>
						<p>- Malaysia</p>
						<p>15 February 2016</p>
					</div>
				</div>
			</div>
				</div>
				<div class="col-md-12">
				<div class="single-testimonials">
				<p>“ Dear, Mr.Surjeet Singh @ Japmeet Holidays...What can I say, your tour was the best of best! I highly recommend all my friends to be on your tour for a very relaxing and tension free vacation. Firstly, your crews was so friendly – we got on really well and we made each other laugh so much. They showed us everything We wanted to see! They spoke very highly of India and made us so much more aware of Bollywood and what goes on there on sets. They spent so much time and even longer than necessary, just to make sure we was happy with everything! We will never forget them as our tour guide, and I am going to recommend your Tour Agency to all my friends back home. You guys were brilliant . Thank you and I hope to see you all really soon. ”</p>
				<div class="box">
					<div class="img-box">
						<!-- <img src="img/user.png" alt="Awesome Image"/> -->
					</div>
					<div class="content text-center">
						<h3>Pammy Dhillon</h3>
						<p>- Malaysia</p>
						<p>15 February 2016</p>
					</div>
				</div>
			</div>
				</div>
				<div class="col-md-12">
				<div class="single-testimonials">
				<p>“ I just come back from Spain with a group of 16 people, we booked with Japmeet Holidays all the transports for the group. never had a problem, in fact, they were always waiting for us with the bus, the spanish guides they gave us were also excelent. If I come back to India I will book again with them. Thanks for making our trip more confortable and easy. ”</p>
				<div class="box">
					<div class="img-box">
						<!-- <img src="img/user.png" alt="Awesome Image"/> -->
					</div>
					<div class="content text-center">
						<h3>Cristina Garcia</h3>
						<p>- Spain</p>
						<p>21 January</p>
					</div>
				</div>
			</div>
				</div>
				<div class="col-md-12">
				<div class="single-testimonials">
				<p>“ I have had a number of tours.but I will recommend japmeet holidays the best tour agency. Very reasonable. good hotels always waiting for us never late.reliable drivers Thumbs up JAPMEET HOLIDAYS!!! Would recommend everyone. ”</p>
				<div class="box">
					<div class="img-box">
						<!-- <img src="img/user.png"  alt="Awesome Image"/> -->
					</div>
					<div class="content text-center">
						<h3>Inderjit Dhanoa</h3>
						<p>- Malaysia</p>
						<p>14 February 2015</p>
					</div>
				</div>
			</div>
				</div>
				<div class="col-md-12">
				<div class="single-testimonials">
				<p>“ Keep up a genuine travel arrangements. Thanks , 31 Jan2016. ”</p>
				<div class="box">
					<div class="img-box">
						<!-- <img src="img/user.png"  alt="Awesome Image"/> -->
					</div>
					<div class="content text-center">
						<h3>Keshwar Sookdeo</h3>
						<p>- USA(New York)</p>
						<p> 31 January 2016</p>
					</div>
				</div>
			</div>
				</div>
				
			</div>
		</div>
	</section>

<?php include_once 'include/footer.php' ?>