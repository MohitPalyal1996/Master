<?php include 'include/header.php'; ?>
   <div class="vc_row-full-width vc_clearfix"></div>
<!DOCTYPE html>
<html>
<head>
    <title>STEEPBRAIN - The best vision is insight</title>
<style type="text/css">
    
.quick-menu {
    padding-top: 17px;
    padding-bottom: 17px;
    margin-bottom: 0;
    border-bottom: 1px solid #cecece;
}
.quick-menu .container>.row>div {
    padding-left: 35px;
    padding-right: 35px;
    border-right: 1px solid #cecece;
}
.media-object {
        width: 50px;
    display: block;
    margin-right: 49px;
}
.quick-menu .media .media-heading {
    color: #5e5e5e;
    font-weight: 700;
    font-size: 22px;
    line-height: 24px;
    margin-bottom: 5px;
    margin-top: 10px;
}
.quick-menu .media .media-body p {
    color: #333;
    font-weight: 300;
}
.media-body>p {
    line-height: 12px;
    margin-top: 4px;
}
.media-body, .media-left, .media-right {
    display: table-cell;
    vertical-align: top;
    padding-right: 0;
}
.quick-menu .container>.row>div:last-child {
    border-right: 0;
}


section.why-legal.module.parallax {
    padding-bottom: 100px;
}
section.why-legal .section-title h2 {
    color: #333;
    text-align: center;
}
.section-title h2 {
    color: #333;
    text-align: center;
    margin-top: 0;
}
.section-title h2 {
    position: relative;
}
section.module.parallax {
    background-position: 50% 50%;
    background-repeat: no-repeat;
    background-attachment: fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
}
.gc-whylegal {
    width: 100%;
    position: relative;
}
.gc-whylegal .gc-why-inner {
    margin: 0 auto;
    position: relative;
    top: 45px;
}
section.why-legal.module.parallax .section-title {
    margin-bottom: 32px;
}
section.why-legal .section-title h2 {
    color: #333;
    text-align: center;
}
.padding00 {
    padding: 0;
}
.text-center.facts h3 {
    color: #fff;
}
.gc-whylegal .gc-why-inner .text-center.facts {
    padding-top: 21px;
}
.whylegal-content .text-center.facts {
    height: 180px;
}
.text-center.facts {
    border: 1px solid #eee;
    padding: 10px;
    border-radius: 5px;
}
.text-center.facts p {
    color: #fff;
}
.facts.why-desc h3 {
    margin-top: 0px;
    padding-left: 15px;
    color: #333 !important;
}

.facts.why-desc ul li {
    list-style: none;
    padding-top: 10px;
}
section.why-legal.module.parallax .facts.why-desc ul li {
    font-size: 14px;
}
.facts.why-desc ul li i {
    padding-right: 15px;
}
.facts.why-desc {
    height: 380px;
    text-align: left;
}
.section-title h2:after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0px;
    top: 45%;
    width: 100%;
    height: 30px;
    background: url(https://lawtendo.com/assets/images/title-line-image.png) center bottom no-repeat;
}
.padding00 ul li:before {
    content: '\0';
    position: absolute;
    max-width: 0;
    max-height: 0;
    left: -19px;
    top: -7px;
    font-size: 24px;
    color: #b1001e;
    display: none;
}




section.module.parallax {
    background-position: 50% 50%;
    background-repeat: no-repeat;
    background-attachment: fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
}
.gc-categoryserv {
    width: 100%;
}
.gc-categoryserv .section-title h2 {
    color: #333;
    text-align: center;
    margin-top: 0;
}
.section-title h2 {
    color: #333;
    text-align: center;
    margin-top: 0;
}
.section-title h2 {
    position: relative;
}
.margin0 {
    margin: 0px !important;
}
.gc-categoryserv .col-md-2 {
    width: 20%;
}

.padding00 {
    padding: 0 !important;
}

section.categoryserv .gc-categoryserv-state {
    height: 125px;
}
.gc-categoryserv-state.gc-black {
    border: 1px solid #ccc;
}
.gc-categoryserv-state {
    text-align: center;
    font-size: 14px;
    padding-top: 8%;
    padding-bottom: 8%;
    text-transform: uppercase;
    /* position: relative; */
}
.gc-black {
    background: #f4f4f4;
    color: #282828;
    font-family: Montserrat;
}
section.categoryserv .gc-categoryserv-state.gc-white {
    border: 1px solid #c5c5c5;
}

.gc-categoryserv-state i.fa {
    font-size: 45px;
    margin-bottom: 15px;
}
.fa {
    display: inline-block;
    font: normal normal normal 14px/1 FontAwesome;
    font-size: inherit;
    text-rendering: auto;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
.gc-white {
    color: #000;
    font-family: Montserrat;
    background: #fff;
}
.blockquote, blockquote
{
    margin: 0px 0 27px;
}
.service-blockquote__text
{
    font-size: 24px;
}
body {
    overflow-x: hidden;
    margin:0;
    padding:0;
}
.service-blockquote__text:before {
    font-size: 75px;
    }

section.latest-answer.module.parallax.parallax-lt-ans {
    background: white;
    padding-bottom: 55px;
}
.gc-across {
    width: 100%;
    position: relative;
    background-position: center !important;
    background-repeat: no-repeat !important;
    background-size: cover !important;
}
section.latest-answer .gc-across-inner {
    top: 0;
    padding-top: 45px;
}
.gc-across-inner {
    max-width: none !important;
}
.gc-across-inner {
 
    margin: 0 auto;
    position: relative;
 }
 section.latest-answer .section-title h2 {
    color: #333;
    text-align: center;
}
.section-title h2 {
    margin-top: 0;
}
.section-title h2 {
    position: relative;
}
.padding00 {
    padding: 0 !important;
}
section.latest-answer .gc-advocate1 {
    padding-top: 20px;
}
.gc-advocate1 ul {
    width: 100%;
    padding: 0px;
    margin: 0px;
}
section.latest-answer .gc-advocate1 ul li:nth-child(1), section.latest-answer .gc-advocate1 ul li:nth-child(2) {
    border-right: none;
}
.gc-advocate1 ul li {
    /* width: 100%; */
    list-style: none;
    padding: 25px;
}
.latest_answers {
    box-shadow: 0px 2px 6px #dfdfdf;
    padding: 15px 5px 15px;
    background: #fff;
}
.gc-advocate-pic {
    width: 25%;
    float: left;
    text-align: -moz-center;
    text-align: -webkit-center;
    padding-top: 10px;
}
.gc-advocate-pic-circle1 {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    position: relative;
    background-color: #3bb6b5 !important;
    background: url(../images/q.png);
    background-repeat: no-repeat;
    background-position: center;
    background-size: 45px;
}
.gc-advocate-detail1 {
    width: 75%;
    float: left;
    padding-left: 30px;
    position: relative;
    /* min-height: 130px; */
    overflow: hidden;
    margin-top: 18px;
}
.gc-advocate-detail1 h4 {

    margin: 0px;
    color: #282828;
    font-weight: 700;
}
section.latest-answer .view-more-button a {
    background: #282828;
    padding: 13px 30px;
}
.view-more-button a {
    background: #40d4a1 !important;
    border-radius: 5px!important;
}
a:link, a:visited {
    color: white;
    text-decoration: none;
}
section.latest-answer .view-more-button {
    clear: both;
    padding-top: 50px;
    text-align: center;
}
.limit-text {
    width: 215px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
section.latest-answer.module.parallax.parallax-lt-ans .gc-advocate-detail1 .categ {
    text-transform: capitalize;
}
.gc-advocate-detail1 p {
 
    margin: 0px;
    color: #282828;
    /* font-size: 17px; */
    padding-bottom: 5px;
}
section.latest-answer.module.parallax.parallax-lt-ans .gc-advocate-detail1 .gc-view {
    position: relative !important;
}
.gc-view {
    color: #3bb3b8 !important;
    background: rgba(255, 255, 255, 0) !important;
    padding: 0;
    text-align: left !important;
}
.gc-view {
    border: none;
    bottom: 0px;
    width: 125px;
   
    /* font-size: 14px; */
}
.gc-advocate-pic-circle1 {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    position: relative;
    background-color: #3bb6b5 !important;
    background: url(assets/images/q.png);
    background-repeat: no-repeat;
    background-position: center;
    background-size: 45px;
}




.multi-item-carousel .carousel-inner > .item {
  transition: 500ms ease-in-out left;
}
.multi-item-carousel .carousel-inner .active.left {
  left: -33%;
}
.multi-item-carousel .carousel-inner .active.right {
  left: 33%;
}
.multi-item-carousel .carousel-inner .next {
  left: 33%;
}
.multi-item-carousel .carousel-inner .prev {
  left: -33%;
}
@media all and (transform-3d), (-webkit-transform-3d) {
  .multi-item-carousel .carousel-inner > .item {
    transition: 500ms ease-in-out left;
    transition: 500ms ease-in-out all;
    -webkit-backface-visibility: visible;
            backface-visibility: visible;
    -webkit-transform: none!important;
            transform: none!important;
  }
}
.multi-item-carousel .carouse-control.left,
.multi-item-carousel .carouse-control.right {
  background-image: none;
}
.media:first-child {
    margin-top: 0;
}
.media {
    margin-bottom: 20px;
}
.media, .media-body {
    overflow: hidden;
    zoom: 1;
}
.media-body, .media-left, .media-right {
    display: table-cell;
    vertical-align: top;
}
.media-left, .media>.pull-left {
    padding-right: 10px;
}
.slick-slide img {
    display: block;
}

.media-body {
    width: 10000px;
}
.media-heading {
    font-weight: 600;
    font-size: 16px;
    color: #2196f3;
    display: block;
    margin-bottom: 5px;
}
.media-heading {
    margin-top: 0;
    margin-bottom: 5px;
}
.media-body .rating {
    line-height: 22px;
    display: block;
    margin-bottom: 0;
}
.star-rating {
    position: relative;
    top: -3px;
}
.star-rating img {
    display: inline-block;
    vertical-align: middle;
}
.star-rating img+img {
    margin-left: -5px;
}
.top-rated .block-card {
    padding: 25px 30px;
}
.block-card {
    border: 1px solid #cdcdcd;
    padding: 12px 30px;
    font-weight: 300;
    line-height: 1;
    margin-bottom: 20px;
    text-align: left;
}
.category {
    font-weight: 600;
    font-size: 16px;
    color: #2196f3;
    margin-bottom: 18px;
}

.carousel-control.left {
    background-repeat:no-repeat;
    background-image: linear-gradient(to right,rgba(0,0,0,0) 0,rgba(0,0,0,0));
}
.carousel-control.right {
    right: 0;
    left: auto;
    background-repeat: no-repeat;
    background-image: linear-gradient(to right,rgba(0,0,0,0) 0,rgba(0,0,0,0));
}

.carousel-control .glyphicon-chevron-left, .carousel-control .icon-prev {
    margin-left: -113px;
    color: #b1001e;
}
.carousel-control .glyphicon-chevron-right, .carousel-control .icon-next {
    margin-right: -109px;
    color: #b1001e;
}
.btn {
    display: inline-block;
    position: relative;
    font-weight: 700;
    font-family: Gudea, sans-serif;
    font-size: 16px;
    padding: 14px 20px;
    color: #2196f3;
    background-color: white;
    border: #2196f3;
    z-index: 1;
    vertical-align: middle;
    
}
.btn-primary:focus {
    color: #2196f3;
    background-color:white;
    border: none;
}
.btn-primary:active{
 color: #2196f3;
    background-color:white;
    border:#2196f3;
}
.btn-primary:hover {
    color: #2196f3;
    background-color:white;
    border: none;
}
.btn {
    
    box-shadow: inset 0 0 0 1px #2196f3, 0 0 1px transparent;
}
.btn:active {
 
    box-shadow: inset 0 0 0 1px #2196f3, 0 0 1px transparent;
}
.btn:hover {
    color: #2196f3;
    background-color: white;
    text-decoration: none;
}
.btn:after {
    width: 0%;
    height: 100%;
    top: 0;
    left: 0;
    background:none;
    content: '';
    position: absolute;
    z-index: -1;
    transition: all 0.3s;
}
 .btn-primary.active.focus, .btn-primary.active:focus, .btn-primary.active:hover, .btn-primary:active.focus, .btn-primary:active:focus, .btn-primary:active:hover, .open>.dropdown-toggle.btn-primary.focus, .open>.dropdown-toggle.btn-primary:focus, .open>.dropdown-toggle.btn-primary:hover{
    color: #2196f3;
    background-color:white;
    border: none;
}

.carousel-control .glyphicon-chevron-left, .carousel-control .icon-prev {
    margin-left: -113px;
    color: white;
    background-color: #b1001e;
}
.carousel-control .glyphicon-chevron-right, .carousel-control .icon-next {
    margin-left: -113px;
    color: white;
    background-color: #b1001e;
}
.carousel-control .glyphicon-chevron-left:active{
    margin-right: -109px;
    color: white;
    background-color: #b1001e;
}




/*@media screen and (min-width: 360px;) {*/
/*  #upgrd {*/
/*   overflow: hidden;*/
   

/*  }*/
/*}*/

#sliding-middle-out {
    display: inline-block;
    position: relative;
    margin-left: 17px;
    margin-top:4px
 
}
#sliding-middle-out:after {
    content: '';
    display: block;
     margin-top: 4px;
    height: 2px;
    width: 0px;
    background: transparent;
    transition: width .7s ease, background-color .7s ease;
    
}
#sliding-middle-out:hover:after {
    width: 100%;
     background: -webkit-gradient(linear, 99% 0%, 0% 100%, from(#cc2a2e03), to(#cc2a2e));
} 


/*@media screen and (max-width: 900px) {*/
/*  #sliding-middle-out{*/
   
/*  }*/
/*}*/


.middle{height: 390px;
    overflow: hidden;
    position: relative;
    background: linear-gradient(rgba(0, 0, 0, 0.28), rgba(0, 0, 0, 0.37)), url(img/DataVisualization.jpg);
    background-size: cover;
    background-position: 0px;
    background-attachment: fixed;
    background-repeat: no-repeat;}
.hero-text{  position: absolute;
    color: white;
    text-align: center;
    width: 70%;
    left: 15%;
    top: 22%;
    
    text-transform: uppercase;}

.cst{
    color:#b1001e;
    font-family:bold;
    letter-spacing:4px;
    
}

@media screen and (max-width: 770px) {
 .cst{
   font-family: Serif;
  }
}

.ct{
    
    color:black;
    font-family:Bold;
    letter-spacing:4px;
    
}

@media screen and (max-width: 770px) {
 .ct{
   font-family: Serif;
  
  }
}


#cs{
    color:black;
    font-family:Bold;
    letter-spacing:3px;
}
@media screen and (max-width: 770px) {
 #cs{
   font-family: Serif;
  }
}

.slideanim {visibility:hidden;}


 .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    }
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    }
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }

 .whyspan{       background: #ccc;
    border-radius: 50px;
    font-size: 43px;
    display: block;
    margin: auto;
    width: 70px;
    height: 70px;}
    .whyspan i{ line-height: 70px }


.wrap-5{     background: url(img/patners.jpg);
    	background-attachment: fixed;
    background-size: cover;
    background-repeat: no-repeat;
    padding: 47px 0;
    background-position-y: -113px;
    position: relative; 
    color: white;
    
}
 .carousel-control{ background-image:none !important  }
 
 .aboutss{   
     background: rgba(248, 248, 248, 0.47);
    padding-bottom: 10px;
    border-radius: 4px;
    overflow: hidden;
    border: 1px solid #f0f8ff;
     
 }
    .aboutss p{ 
        padding:6px 7px
        
    }
    .aboutss{   
      
    text-align: center;
    line-height: 23px;
    background: transparent;
    border-radius: 6px;
    /*border: 1px solid rgb(226, 242, 255);*/
    box-shadow: 0px 0px 3px #f7f7f7 inset;
    color: gray;
        
    }
    
 .aboutss figure{   height: 233px;
    overflow: hidden;}
	
    .aboutss:hover img{ -webkit-transform:scale(1.1); transition:0.7s}    
    .aboutss h2, .aboutss h3, .aboutss h4, .aboutss h5, .aboutss p{text-align:center}
    
    
    
.head2 {
    color: #006bb3;
    font-weight: bold;
    text-align: center;
    margin-top: 0px;
    margin-bottom: 20px;
    margin-top: 60px;
    font-family: Montserrat-Bold;
    font-size: 35.98pt;
}

#quote-carousel {
    padding: 0 10px 30px 10px;
    margin-top: 60px;
}
#quote-carousel .carousel-control {
    background: none;
    color: #CACACA;
    font-size: 2.3em;
    text-shadow: none;
    margin-top: 30px;
}
#quote-carousel .carousel-indicators {
    position: relative;
    right: 50%;
    top: auto;
    bottom: 0px;
    margin-top: 20px;
    margin-right: -19px;
}
#quote-carousel .carousel-indicators li {
    width: 50px;
    height: 50px;
    cursor: pointer;
    border: 1px solid #ccc;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    border-radius: 50%;
    opacity: 0.4;
    overflow: hidden;
    transition: all .4s ease-in;
    vertical-align: middle;
}
#quote-carousel .carousel-indicators .active {
    width: 128px;
    height: 128px;
    opacity: 1;
    transition: all .2s;
}


    
    
</style>


</head>
<body>

    <div class="container-fluid" style="overflow:hidden;" > 
        <!--<div data-vc-full-width="true" data-vc-full-width-init="true" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding ">-->
            <div class="wpb_column vc_column_container vc_col-sm-12 ">
                <div class="vc_column-inner ">
                    <div class="wpb_wrapper">
                        <div class="wpb_layerslider_element wpb_content_element">
                            <script data-cfasync="false" type="text/javascript">var lsjQuery = jQuery;</script>
                            <script data-cfasync="false" type="text/javascript">
lsjQuery(document).ready(function() {
if(typeof lsjQuery.fn.layerSlider == "undefined") {
if( window._layerSlider && window._layerSlider.showNotice) { 
window._layerSlider.showNotice('layerslider_1','jquery');
}
} else {
lsjQuery("#layerslider_1").layerSlider({sliderVersion: '6.5.7', type: 'fullwidth', allowFullscreen: false, cycles: 3, skin: 'v6', globalBGSize: 'cover', navStartStop: false, navButtons: false, popupWidth: 640, popupHeight: 360, skinsPath: 'http://lawyer.webtemplatemasters.com/wp-content/plugins/LayerSlider/static/layerslider/skins/'});
}
});
</script>
<div id="layerslider_1" class="ls-wp-container fitvidsignore" style="width:1180px;height:700px;margin:0 auto;margin-bottom: 0;z-index:5;">

                            <!--<div id="layerslider_1" class="ls-wp-container fitvidsignore" style="width:1180px;height:700px;margin:0 auto;padding:0;margin-bottom:0;z-index:5;">-->
 <div class="ls-slide" data-ls="duration:10000;transition2d:70;timeshift:-3200;kenburnsscale:1.2;">
     <img width="2560" height="700" src="img/01_slide-01.jpg" class="ls-bg" alt="" srcset="img/01_slide-01.jpg 2560w, img/slidesmall.jpg 768w" sizes="(max-width: 2560px) 100vw, 2560px" />
     
<!--<img width="2560" height="700" src="img/01_slide-01.jpg" class="ls-bg" alt="" srcset="img/01_slide-01.jpg 2560w, img/01_slide-01-768x210.jpg 768w" sizes="(max-width: 2560px) 100vw, 2560px" />-->
<img width="1610" height="700" src="img/slider-overlay-02.png" class="ls-l" alt="" srcset="img/slider-overlay-02.png 1610w, img/slider-overlay-02-768x342.png768w" sizes="(max-width: 1610px) 100vw, 1610px" style="top:0px;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;delayin:200;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5100;easingout:easeInBack;fadeout:false;position:fixed;">
 <img width="1570" height="700" src="img/slider-overlay-02.png" class="ls-l" alt="" srcset="img/slider-overlay-02.png 1570w, img/slider-overlay-02-768x342.png 768w" sizes="(max-width: 1570px) 100vw, 1570px" style="top:0px;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5000;easingout:easeInBack;fadeout:false;position:fixed;">
  <h2 style="text-transform:uppercase;top:460px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;font-family:Gudea;font-size:36px;color:#ffffff;" class="ls-l" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1500;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4600;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">We are a team with combined experience of more than 20 years</h2>
 <h2 style="top:510px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;font-family:Gudea;font-size:22px;color:#ffffff;" class="ls-l ls-hide-phone" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1700;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4400;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">In Programming , Project Management and Operations</h2>
                                        </div>
 <div class="ls-slide" data-ls="duration:10000;transition2d:70;timeshift:-3200;kenburnsscale:1.2;">
<img width="2560" height="700" src="img/01_slide-02.jpg" class="ls-bg" alt="" srcset="img/01_slide-02.jpg 2560w, img/01_slide-02-768x210.jpg 768w" sizes="(max-width: 2560px) 100vw, 2560px" />
 <img width="1610" height="700" src="img/slider-overlay-02.png" class="ls-l" alt="" srcset="img/slider-overlay-02.png 1610w, img/slider-overlay-02-768x342.png 768w" sizes="(max-width: 1610px) 100vw, 1610px" style="top:0px;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;delayin:200;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5100;easingout:easeInBack;fadeout:false;position:fixed;">
  <img width="1570" height="700" src="img/slider-overlay-02.png" class="ls-l" alt="" srcset="img/slider-overlay-02.png 1570w, img/slider-overlay-02-768x342.png 768w" sizes="(max-width: 1570px) 100vw, 1570px" style="top:0px;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5000;easingout:easeInBack;fadeout:false;position:fixed;">
 <h2 style="text-transform:uppercase;top:425px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;font-family:Gudea;font-size:36px;color:#ffffff;" class="ls-l" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1500;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4600;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">We are experts in 
                                                        <br>
cutting edge technologies 
      </h2>
 <h2 style="top:515px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;font-family:Gudea;font-size:22px;color:#ffffff;" class="ls-l ls-hide-phone" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1700;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4400;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">Have more than 20 years’ experience in Market Research,
                                                            <br>
 Data Analytics and Custom Programming
                                                            </h2>
        </div>
      <div class="ls-slide" data-ls="duration:10000;transition2d:70;timeshift:-3200;kenburnsscale:1.2;">
<img width="2560" height="700" src="img/01_slide-03.jpg" class="ls-bg" alt="" srcset="img/01_slide-03.jpg 2560w, img/01_slide-03-768x210.jpg 768w" sizes="(max-width: 2560px) 100vw, 2560px" />
<img width="1610" height="700" src="img/slider-overlay-02.png" class="ls-l" alt="" srcset="img/slider-overlay-02.png 1610w, img/slider-overlay-02-768x342.png 768w" sizes="(max-width: 1610px) 100vw, 1610px" style="top:0px;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;delayin:200;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5100;easingout:easeInBack;fadeout:false;position:fixed;">
 <img width="1570" height="700" src="img/slider-overlay-02.png" class="ls-l" alt="" srcset="img/slider-overlay-02.png 1570w, /slider-overlay-02-768x342.png 768w" sizes="(max-width: 1570px) 100vw, 1570px" style="top:0px;left:-300px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;" data-ls="showinfo:1;offsetxin:-100lw;durationin:1500;easingin:easeInOutBack;fadein:false;clipin:0 100% 0 0;offsetxout:-100lw;durationout:1500;startatout:transitioninend + 5000;easingout:easeInBack;fadeout:false;position:fixed;">
  <h2 style="text-transform:uppercase;top:510px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;font-family:Gudea;font-size:36px;color:#ffffff;" class="ls-l" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1500;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4600;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;"></h2>
<h2 style="top:430px;left:90px;text-align:initial;font-weight:400;font-style:normal;text-decoration:none;wordwrap:false;opacity:1;font-family:Gudea;font-size:22px;color:#ffffff;" class="ls-l ls-hide-phone" data-ls="showinfo:1;offsetxin:-100lw;durationin:800;delayin:1700;easingin:easeInOutBack;offsetxout:-100lw;durationout:800;startatout:transitioninend + 4400;easingout:easeInBack;clipout:0 100% 0 0;position:fixed;">We are a team with more than 20 years of experience.
                                                                        <br>
We have rich expertise in technology, Analytics, project management and operations
                                                                        </h2>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--</div>-->
                                        </div>
                                        <div class="vc_row-full-width vc_clearfix"></div>


<br>
 <div class="market-reaching slideanim">
            <div class="container-fluid "><h2 class="ct"  id="sliding-middle-out" style="">About Us</h2>
                <div class="col-md-6 ">
                    
                    <figure>
                        <img src="img/services.png" alt="cds" class="width-100">
                    </figure>
                </div>
                  <!--<h2  id="sliding-middle-out" style="">About Us</h2>-->
                <div class="col-md-6 padding-0">
                  
                    <p style="margin-top:-5px;" >We at <img  src="img/logoi.png">offer critical market intelligence Information including demographic, business data, statistics, and inclinations of individuals who have been utilizing or wish to utilize your products or services. We cover a wide range of industries including FMCG, financial, IT and ITES. Our more than 20 years of collective experiance helps us in providing unique solution to our clients</p>
                    <p>With the help of our market research capabilities you can: Evaluate viability of an idea. Identify new opportunities .Designing the best fit after analyzing changing market trends. And above all – scrutinize your own capabilities to modify and run strategies that help you serve your clients.</p>
             
                </div>
   
                </div>
            </div>
            <br>
            
            <div class="middle">
		<div class="hero-text">
<h1 class="cst">STEEPBRAIN</h1>
<p style="color:white;font-family:cursive;letter-spacing:2px;word-spacing:5px;">SteepBrain offers well-defined market research that give business leaders insights to take advantage of constantly changing business dynamics.</p>
				</div>
				
			</div>
            <br>
            
<div class="section-title" style="overflow: hidden;"  >
<h2 id="cs" style="">OUR SERVICES</h2>
</div>
<br>
<div class="vc_row wpb_row vc_row-fluid slideanim" style="margin: 0;padding: 0;" >
<div class="wpb_column vc_column_container vc_col-sm-12 ">
<div class="vc_column-inner ">
<div class="wpb_wrapper" style="overflow: hidden;">
<div class="row" style="overflow: hidden;">
<div class="small-12 medium-6 large-4 columns tile-col" style="height: 300px;">
<section class="tile effect-bubba" style="overflow: hidden;">
 <div  style="margin-top: -16px;"  class="tile__icon icon-globe" ></div> 
<h3 class="tile__title" style="overflow: hidden;margin-top:7px;" >
Qualitative & Quantitative Research</h3>
<p class="tile__description" style="overflow: hidden;" >

With the help of our Service and Research Clients get an understanding of the logic.. 
 </p>
<i class="tile__arrow icon-right-4"><a href="ourservices.php" class="tile__link"></a></i>

</section>
</div>
<div class="small-12 medium-6 large-4 columns tile-col" style="height: 300px;">
<section class="tile effect-bubba" style="overflow: hidden;">
 <div  style="font-size:40px;"  class="tile__icon fa fa-github" style="margin-top:-10px;" ></div> 
<h3 class="tile__title" style="overflow: hidden;margin-top: 4px;">Programming</h3>
<p class="tile__description" style="overflow: hidden;margin-top:15px;">We hold the capability to create and run complex online as well as offline surveys.</p>

<i class="tile__arrow icon-right-4"><a href="ourservices.php" class="tile__link"></a></i>
</section>
</div>
<div class="small-12 medium-6 large-4 columns tile-col " style="height: 300px;">
<section class="tile effect-bubba" style="overflow: hidden;">
 <div  style="font-size:40px;" class="tile__icon fa fa-signal"></div> 
<h3 class="tile__title" style="overflow: hidden;margin-top: 4px;">Conjoint Data & Simulators</h3>
<p class="tile__description" style="overflow: hidden;margin-top:9px;">
Conjoint Simulator is used to convert raw conjoint data into meaningful and insightful.</p>

<i class="tile__arrow icon-right-4"><a href="ourservices.php" class="tile__link"></a></i>
</section>
</div>
<div class="small-12 medium-6 large-4 columns tile-col " style="height: 300px;">
<section class="tile effect-bubba" style="overflow: hidden;">
 <div style="font-size:40px;" class="tile__icon fa fa-database"></div> 
<h3 class="tile__title" style="overflow: hidden;margin-top: 5px;">Data Collection</h3>
<p class="tile__description" style="overflow: hidden;margin-top:9px;">
We have cultivated strong expertise in managing online and offline data collection .</p>
<i class="tile__arrow icon-right-4"><a href="ourservices.php" class="tile__link"></a></i>
</section>
</div>
<div class="small-12 medium-6 large-4 columns tile-col " style="height: 300px;">
<section class="tile effect-bubba" style="overflow: hidden;">
 <div  style=" font-size:40px;"  class="tile__icon  fa fa-line-chart"></div> 
<h3 class="tile__title" style="overflow: hidden;margin-top: 5px;">Data Processing & Analysis</h3>
<p class="tile__description" style="overflow: hidden;margin-top:10px;">To bring your research to a point where qualitative and quantitative data.
</p>

<i class="tile__arrow icon-right-4"><a href="ourservices.php" class="tile__link"></a></i>
</section>
</div>
<div class="small-12 medium-6 large-4 columns tile-col " style="height: 300px;">
<section class="tile effect-bubba" style="overflow: hidden;">
 <div  style="margin-top: -13px;"  class="tile__icon icon-rocket"></div> 
<h3 class="tile__title" style="overflow: hidden;margin-top: 4px;">
Translation</h3>
<p class="tile__description" style="overflow: hidden;margin-top:7px;">Seamless Transition from one language to another
Being a Market Research company we have natives as translators.
</p>

<i class="tile__arrow icon-right-4"><a href="ourservices.php" class="tile__link"></a></i>
</section>
</div>
</div>
<div class="text-center" style="overflow: hidden;">
<a  href="ourservices.php" class=" btn btn ghost" style="background-color: red;">View our Domain Expertise</a>
</div>
</div>
</div>
</div>
</div>

<br>
<br><br>
<br>    
<!--<div style="overflow: hidden;" id="upgrd">-->
<!--<h2 style="text-align: center;color: orange;" style="overflow: hidden;">-->
<!--    <img src="tools-solid.svg" style="height: 40px;width:40px;"> We are Upgrading our Website  <!-- <img src="k.png" style="height: 100px;width: 100px;"> -->
    <!--<img src="tools-solid.svg" style="height: 40px;width:40px;"></h2></div>                                   -->
<div class="container-fluid">
 
<h2 id="cs" style="text-align:center;letter-spacing:1px;">Why You Choose Us</h2>
</div>
	
<div class="container ">

<br>
<div class="col-md-4 slideanim" >
<div class="aboutss ">

<img style="height:300px;width:350px" src="img/Data_Processing1.jpg" alt="d" class="width-100">

<h2 style="color:#b1001e;">Custom Solutions 	</h2>
<p>From the analysis of the market trends with the help of demographic and business data to giving you meaningful insights, we analyze everything in a great detail keeping in mind your unique requirements.</p>
<!-- <a href="#" class="button-effect">Read More</a> -->
</div>
</div>

<div class="col-md-4 slideanim">
<div class="aboutss ">

<img style="height:300px;" src="img/Find_Your_Niche.jpg" alt="d" class="width-100">
<h2 style="color:#b1001e;">Analytics for you  </h2>
<p>Identifying new products or services, spotting warning signals in your own business, or gauging customers satisfaction, we give you reliable business insights that get right to the point..</p>
<!-- <a href="#" class="button-effect">Read More</a> -->
</div>
</div>

<div class="col-md-4 slideanim">
<div class="aboutss ">


<img style="height:300px;width:350px" src="img/Operation_Integration.jpg" alt="d" class="width-100">

<h2 style="color:#b1001e;">Operations Integration</h2>
<p> We’ll set up the framework of the entire
research and suggest ways to ensure it integrates well with your requirements.  We aim to be your one stop solution provider. </p>
<!--<a href="#" class="button-effect">Read More</a> -->
</div>

</div>
</div>

<div class="section-title slideanim" style="overflow: hidden;"  >
<h2  id="cs">OUR USER</h2>
</div>




                                     
  <div class="container-fluid slideanim">
        <div class="row">
              
                <div class="carousel slide" data-ride="carousel" id="quote-carousel">
                   
                                        <ol class="carousel-indicators" style="margin-top:-10px;">
                        <li data-target="#quote-carousel" data-slide-to="0" class="active"><img class="img-responsive" layout="responsive" width="136" height="136" src="img/userm.png" alt="">
                        </li>
                        <li data-target="#quote-carousel" data-slide-to="1"><img class="img-responsive" layout="responsive" src="img/userg.png" width="136" height="136" alt="">
                        </li>
                        <li data-target="#quote-carousel" data-slide-to="2"><img class="img-responsive" layout="responsive" src="img/fuser.png" width="136" height="136" alt="">
                        </li>
                    </ol>

                    <!-- Carousel Buttons Next/Prev -->
                    <a data-slide="prev" href="#quote-carousel" class="left carousel-control"><i class="fa fa-chevron-left"></i></a>
                    <a data-slide="next" href="#quote-carousel" class="right carousel-control"><i class="fa fa-chevron-right"></i></a>
                    
                    <!-- Carousel Slides / Quotes -->
                    <div class="carousel-inner text-center">
                     
                        <!-- Quote 1 -->
                        <div class="item active">
                        
                                <div class="row">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <b>With the help of our market research capabilities you can: Evaluate viability of an idea. Identify new opportunities .Designing the best fit after analyzing changing market trends. And above all – scrutinize
                                        your own capabilities to modify and run strategies that help you serve your clients.</b>
                                        <h5><b>Someone famous</b></h5>
                                    </div>
                                </div>
                    
                        </div>
                        <!-- Quote 2 -->
                        <div class="item">
                       
                                <div class="row">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <b>With the help of our market research capabilities you can: Evaluate viability of an idea. 
                                        Identify new opportunities .Designing the best fit after analyzing changing market trends. And above all – s
                                        crutinize your own capabilities to modify and run strategies that help you serve your clients.</b>
                                        <h5><b>Someone famous</b></h5>
                                    </div>
                                </div>
                           
                        </div>
                        <!-- Quote 3 -->
                        <div class="item">
                          
                                <div class="row">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <b>With the help of our market research capabilities you can: Evaluate viability of an idea. Identify new opportunities .Designing the best fit after 
                                        analyzing changing market trends. And above all – scrutinize your own capabilities to modify and run strategies that help you serve your clients.!</b>
                                      <h5><b>Someone famous</b></h5>
                                    </div>
                                </div>
                           
                        </div>
                    </div>
                    <!-- Bottom Carousel Indicators -->

                </div>
          
             </div>
            </div>
                <script>
$(document).ready(function(){
      $('.customer-logos').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1000,
        arrows: false,
        dots: false,
          pauseOnHover: false,
          responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 3
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 2
          }
        }]
      });
    });
</script>                 

<script>
$(document).ready(function(){
    // Activate Carousel
    $("#myCarousel").carousel();
    
    // Enable Carousel Indicators
    $(".item1").click(function(){
        $("#myCarousel").carousel(0);
    });
    $(".item2").click(function(){
        $("#myCarousel").carousel(1);
    });
    $(".item3").click(function(){
        $("#myCarousel").carousel(2);
    });
    $(".item4").click(function(){
        $("#myCarousel").carousel(3);
    });
    
    // Enable Carousel Controls
    $(".left").click(function(){
        $("#myCarousel").carousel("prev");
    });
    $(".right").click(function(){
        $("#myCarousel").carousel("next");
    });
});
</script>


 <script>
$(document).ready(function(){
    $(".nav-tabs a").click(function(){
        $(this).tab('show');
    });
});
</script>
			
		

                                        <script>
                // Instantiate the Bootstrap carousel
$('.multi-item-carousel').carousel({
  interval: false
});

// for every slide in carousel, copy the next slide's item in the slide.
// Do the same for the next, next item.
$('.multi-item-carousel .item').each(function(){
  var next = $(this).next();
  if (!next.length) {
    next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));
  
  if (next.next().length>0) {
    next.next().children(':first-child').clone().appendTo($(this));
  } else {
    $(this).siblings(':first').children(':first-child').clone().appendTo($(this));
  }
});
            </script> 
            
            <script>
$(document).ready(function(){
    $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>
            
                  <?php include 'include/footer.php'; ?>

</body>
</html>