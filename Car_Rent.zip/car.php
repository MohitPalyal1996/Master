<?php include_once 'include/header.php'; ?>
<script src="js/country.js"></script>


	<section class="inner-banner" style="margin-top: 65px;">
		<div class="container text-center">
			<h2><span>Single Car Page</span></h2>
		</div>
	</section>

	
	<div class="single-car-content section-padding pb0  single-blog-post-page">
		<div class="container">
			<div class="row">
				<div class="col-md-7">
					<div class="single-car-carousel-content-box owl-carousel owl-theme">
						<div class="item">
							<img src="img/single-car/1.jpg" alt="Awesome Image"/>
						</div>
						<div class="item">
							<img src="img/single-car/2.jpg" alt="Awesome Image"/>
						</div>
						<div class="item">
							<img src="img/single-car/3.jpg" alt="Awesome Image"/>
						</div>
						<div class="item">
							<img src="img/single-car/4.jpg" alt="Awesome Image"/>
						</div>
					</div>
					<div class="single-car-carousel-thumbnail-box owl-carousel owl-theme">
						<div class="item">
							<img src="img/single-car/1-thumb.jpg" alt="Awesome Image"/>
						</div>
						<div class="item">
							<img src="img/single-car/2-thumb.jpg" alt="Awesome Image"/>
						</div>
						<div class="item">
							<img src="img/single-car/3-thumb.jpg" alt="Awesome Image"/>
						</div>
						<div class="item">
							<img src="img/single-car/4-thumb.jpg" alt="Awesome Image"/>
						</div>
					</div>
				</div>
				<div class="col-md-5">
					<div class="single-vehicle-sorter">
						<div class="img-box">
							<img src="img/vehicle-sorter/1.png" alt="">
						</div>
						<h3>Beige BMW Sedan 5 2013</h3>
						<div class="middle-box-wrapper clearfix">
							<div class="middle-box">
								<ul>
									<li><span>Location:</span> Los Angels</li>
									<li><span>Engine:</span> 6.5L LP, petrol</li>
									<li><span>Mileage:</span> 30000 km</li>
									<li><span>Condition:</span> used</li>
								</ul>
							</div>
							<div class="middle-box">
								<ul>
									<li><span>Location:</span> Los Angels</li>
									<li><span>Engine:</span> 6.5L LP, petrol</li>
									<li><span>Mileage:</span> 30000 km</li>
									<li><span>Condition:</span> used</li>
								</ul>
							</div>
							<div class="middle-box">								
								<ul>
									<li><span>Location:</span> Los Angels</li>
									<li><span>Engine:</span> 6.5L LP, petrol</li>
									<li><span>Mileage:</span> 30000 km</li>
									<li><span>Condition:</span> used</li>
								</ul>
							</div>
						</div>
						<div class="bottom-box-wrapper clearfix">
							<p class="price-box hour pull-left">
								Price per hour: 
								<span><b>$</b>59.99</span>
							</p>
							<p class="price-box pull-left">
								Price per day: 
								<span><b>$</b>559.99</span>
							</p>
							<a  data-toggle="" data-target="" href="booknow.php?message=Innova" class="thm-btn"><i class="fa fa-angle-right"></i> RENT CAR</a>
						</div>
					</div>					
				</div>
			</div>
			<div class="single-car-tab-wrapper">
				<div class="tab-title">
					<ul role="tablist">
						<li class="active" data-tab-name="overview"><a href="#overview" aria-controls="overview" role="tab" data-toggle="tab">VEHICLE OVERVIEW</a></li>
						<li data-tab-name="review"><a href="#review" aria-controls="review" role="tab" data-toggle="tab"> CUSTOMER REVIEWS</a></li>
						<li data-tab-name="additional-info"><a href="#additional-info" aria-controls="additional-info" role="tab" data-toggle="tab"> ADDITIONAL INFORMATION</a></li>
					</ul>
				</div>
				<div class="tab-content">
					<div class="single-tab-content tab-pane fade in active" id="overview">
						<p>At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, At accusam aliquyam diam diam dolore dolores duo eirmod eos erat, et nonumy sed tempor et et invidunt justo labore Stet clita ea et gubergren, kasd magna no rebum. sanctus sea sed takimata ut vero voluptua. est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur.</p>
						<ul>
							<li>A tailored, modern cut with a roomier fit than our suit, for the guy with an athletic build</li>
							<li>Notch lapel</li>
							<li>Italian cotton.</li>
							<li>Two-button closure.</li>
							<li> Nonfunctional buttons at cuffs. </li>
							<li>Dry clean.</li>
							<li>Import.</li>
						</ul>
					</div>
					<div class="single-tab-content tab-pane fade " id="review">
						<!--Comments Area-->
	                    <div class="comments-area">
	                        <div class="group-title text-uppercase"><h2>2 Reviwes</h2></div>
	                        
	                        <div class="comment-box">
	                            <div class="comment">
	                                <div class="author-thumb"><img src="img/resources/testi-image-1.jpg" alt=""></div>
	                                <div class="comment-info">
	                                	<strong>Johnathan Doe</strong> 	                                	
	                                </div>
	                                <div class="text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, At accusam aliquyam diam diam dolore dolores duo eirmod eos erat, et nonumy sed tempor et et invidunt justo labore. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis.</div>
	                                <div class="reply-option text-left">Posted 4 hours ago &ensp; <a class="theme-btn radial-btn btn-theme-four" href="#"><span class="txt">Reply</span></a></div>
	                            </div>
	                            
	                            <div class="comment reply-comment">
	                                <div class="author-thumb"><img src="img/resources/testi-image-2.jpg" alt=""></div>
	                                <div class="comment-info"><strong>Jack Porter</strong></div>
	                                <div class="text">At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</div>
	                                <div class="reply-option text-left">Posted 5 hours ago &ensp; <a class="theme-btn radial-btn btn-theme-four" href="#"><span class="txt">Reply</span></a></div>
	                            </div>
	                            
	                            <div class="comment">
	                                <div class="author-thumb"><img src="img/resources/testi-image-3.jpg" alt=""></div>
	                                <div class="comment-info"><strong>Marc Terrenzi</strong></div>
	                                <div class="text">Whether you need to create a brand from scratch, including marketing materials and a beautiful and functional website or whether you are looking for a design.</div>
	                                <div class="reply-option text-left">Posted 7 hours ago &ensp; <a class="theme-btn btn-theme-four" href="#"><span class="txt">Reply</span></a></div>
	                            </div>
	                            
	                        </div>
	                    </div>
						<!-- Comment Form -->
	                    <div class="comment-form">
	                            
	                        <div class="group-title text-uppercase"><h2>Leave a Review</h2><div class="default-line-left"></div></div>
	                        
	                        <!--Comment Form-->
	                        <form method="post" action="#">
	                            <div class="row clearfix">
	                                <div class=" col-lg-4 col-md-6 col-sm-12 col-xs-12 form-group">
	                                    <input type="text" name="username" placeholder="Your Name">
	                                </div>
	                                
	                                <div class=" col-lg-4 col-md-6 col-sm-12 col-xs-12 form-group">
	                                    <input type="email" name="email" placeholder="Email">
	                                </div>
	                                
	                                <div class=" col-lg-4 col-md-12 col-sm-12 col-xs-12 form-group">
	                                    <input type="text" name="url" placeholder="Website">
	                                </div>
	                                
	                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 form-group">
	                                    <textarea name="message" placeholder="Your Message"></textarea>
	                                </div>
	                                
	                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 form-group text-right">
	                                    <button class="theme-btn btn-theme-four" type="submit" name="submit-form">Add Comment</button>
	                                </div>
	                                
	                            </div>
	                        </form>
	                            
	                    </div><!--End Comment Form -->						
					</div>
					<div class="single-tab-content tab-pane fade " id="additional-info">
						<p>At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, At accusam aliquyam diam diam dolore dolores duo eirmod eos erat, et nonumy sed tempor et et invidunt justo labore Stet clita ea et gubergren, kasd magna no rebum. sanctus sea sed takimata ut vero voluptua. est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur.</p>
						<ul>
							<li>A tailored, modern cut with a roomier fit than our suit, for the guy with an athletic build</li>
							<li>Notch lapel</li>
							<li>Italian cotton.</li>
							<li>Two-button closure.</li>
							<li> Nonfunctional buttons at cuffs. </li>
							<li>Dry clean.</li>
							<li>Import.</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>

		




<?php include_once 'include/footer.php'; ?>
