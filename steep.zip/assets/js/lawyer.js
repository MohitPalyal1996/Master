
jQuery(document).ready(function ($) {   
/*------------------- Filter Function--------------------*/
	$('#lawyer_practice_filter').on('change', function(){
		lawyer_filter_questions();
	});
	
	$('.lawquesloadmore').on("click",function() {	
		var value = $('.form_advice').serialize();
		var ID = $(this).attr("id");
		if(ID){
			$("#mores"+ID).html();
				$.ajax({
					type: "POST",
					url: base_url+"Lawyer/Filter_Question_Loadmore", 
					data: "lastmsgadvice="+ ID +"&"+value, 
					cache: false,
					success: function(html){
							$("ul#legaladvice").append(html);
							$("#mores"+ID).hide();
					}
				});
		} else {
				$(".moresbox").html('The End');
		}
		return false;
	});
	
	
});
	/* Update status of lawyer */
	function lawyer_status(cunsult_id,_this)
	{
		var status = _this.val();
	console.log(status);
		if(status){
			$("#mores"+status).html();
				$.ajax({
					type: "POST",
					url: base_url+"Lawyer/update_cunsultant_status", 
					data: "cunsult_id="+ cunsult_id +"&status="+status, 
					cache: false,
					success: function(data){
						console.log(data);
						if($.trim(data) !='false'){
							/* alert('Status Updated Successfully'); */
							document.location.reload(true);
							$("#mores"+status).hide();
						}else{
						/* 	alert('Unable to Updated,Try after some time!'); */
						document.location.reload(true);
						}
						
					}
				});
		} else {
				$(".moresbox").html('The End');
		}
		return false;
	}

/*-------------------------- Filter Results -----------------------------*/
function lawyer_filter_questions() {
	var value = $('#form_question_filter').serialize();
	$.ajax({
			type: "POST",
			url: base_url+"Lawyer/Filter_Question",
			data: value,
			success: function(data) {
				data = JSON.parse(data);
				if(data['total'] == 0) {					
					$(".gc-settings-btn-bay.load-mores-button").hide();
				}
				else{															
					$('html, body').animate({scrollTop:$('.gc-question-bay').offset().top}, 'slow');									
					if(data['total'] >= 4) {
						$(".gc-settings-btn-bay.load-mores-button").show();
						$('.moresbox').show();
						$('.moresbox').attr('id','mores'+data['last_id']);
						$('.adviceloadmore').attr('id',data['last_id']);
					} else {
						$(".gc-settings-btn-bay.load-mores-button").hide();
					}					
				}
				$('.gc-advocate1 ul').html(data['temp']);
			}
	});
}